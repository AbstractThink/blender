# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
# noinspection PyUnresolvedReferences
import bpy
from uuid import uuid4
# noinspection PyUnresolvedReferences
from bpy.types import Operator, PropertyGroup, Mesh, Panel, Object
from bpy.props import (
    FloatProperty, IntProperty, BoolProperty, BoolVectorProperty, IntVectorProperty,
    CollectionProperty, FloatVectorProperty, EnumProperty, StringProperty, PointerProperty
)
from mathutils import Vector, Matrix
import time
from random import uniform
from math import tan, sqrt, pi, sin, cos, floor
from .bmesh_utils import BmeshEdit as bmed
from .panel import Panel as WindowPanel
from .archipack_handle import ArchipackHandle
from .archipack_manipulator import Manipulable
from .archipack_preset import ArchipackPreset, PresetMenuOperator
from .archipack_gl import FeedbackPanel
from .archipack_abstraction import ensure_select_and_restore, context_override, Callbacks
from .archipack_i18n import Archipacki18n
from .archipack_object import (
    ArchipackPanel,
    ArchipackObject, 
    ArchipackCreateTool, 
    ArchipackDrawTool,
    ArchipackArrayTool,
    update_source
    )
from .archipack_segments2 import OpeningGenerator
from .archipack_keymaps import Keymaps
from .archipack_dimension import DimensionProvider
from .archipack_bendable import Bendable
from .archipack_material import build_mat_enum
from .archipack_iconmanager import icons
from .archipack_autoboolean import ArchipackBoolManager
from .archipack_custom import Customizable, update_user_object
from .archipack_snappable import Snappable
from .archipack_compound import Compound, CompoundPart
import logging
logger = logging.getLogger(__package__)

def update_parent(self, context):
    self.update_parent(context)

def update(self, context):
    self.update(context)


def update_auto_hole(self, context):
    self.update(context)
    self.update_auto_hole(context)


def update_childs(self, context):
    self.update(context, childs_only=True)


def set_cols(self, value):
    if self.n_cols != value:
        self.auto_update = False
        self._set_width(value)
        self.auto_update = True
        self.n_cols = value
    return None


def get_cols(self):
    return self.n_cols


# how much leaf is inside frame (ratio of frame thicnkess)
LEAF_OVERFLOW = 0.8


MAT_GLASS = 0
MAT_FRAME_INSIDE = 1
MAT_FRAME_OUTSIDE = 2
MAT_SILL_IN = 3
MAT_SILL_OUT = 4
MAT_SPOILER = 5
MAT_SHUTTER = 6
MAT_HANDLE = 7
MAT_HINGE = 8
MAT_GLASS_FRAME = 9
MAT_JOINT = 10
MAT_SILL_CURTAIN = 11
MAT_ROD_CURTAIN = 12
MAT_OUT_FRAME = 13

# keep a reference to material enums
material_enums = []
mat_enum, mat_index_getter, mat_index_setter = build_mat_enum(
    'idmat', material_enums)

'''


def find_bevel_profile_modifier(o, vgroup):
    for m in o.modifiers:
        if m.type == "BEVEL" and m.vertex_group == vgroup:
            return m
    m = o.modifiers.new(type="BEVEL", name="Bevel-{}".format(vgroup))
    m.profile_type = 'CUSTOM'
    m.limit_method = 'VGROUP'
    m.width_type = 'WIDTH'
    m.vertex_group = vgroup
    return m


def bevel_profile_modifier(o, vgroup, xy, width=0.01, segments=1, handle_type='VECTOR'):
    if vgroup not in o.vertex_groups:
        return
    m = find_bevel_profile_modifier(o, vgroup)
    m.segments = segments
    m.width = width
    profile = m.custom_profile
    points = profile.points
    for i in range(1, len(points) - 1, 1):
        points.remove(points[1])
    for x, y in xy:
        p = points.add(x, y)
    for i, p in enumerate(reversed(points[1:-1])):
        p.location = xy[i]
    for p in points[1:-1]:
        p.handle_type_1 = handle_type  # 'AUTO' 'FREE' 'ALIGN'
        p.handle_type_2 = handle_type
    profile.update()



o = C.object

xy = [(0.1, 0.8), (0.2, 0.3), (0.5, 0.8), (0.8, 0.1)]
vgroup = "outside_out"

bevel_profile_modifier(o, vgroup, xy, width=0.03, segments=12)

'''



class archipack_window_panel(ArchipackObject, CompoundPart, PropertyGroup):

    width: FloatProperty(
        name="Width",
        min=0.01, default=50,
        update=update_parent
    )
    fixed: BoolProperty(
        default=False,
        name="Fixed",
        update=update_parent
    )
    handle_side: EnumProperty(
        name="Side",
        items=(
            ('AUTO', "Auto", "Rely on automatic handle"),
            ('BOTH', "Both", "Inside and outside"),
            ('INSIDE', "Inside", "Inside only"),
            ('OUTSIDE', "Outside", "Outside only"),
            ('NONE', "None", "Disable handles")
        ),
        default="AUTO",
        update=update_parent
    )

    idmat: IntVectorProperty(
        default=[
            2,
            1, 0,
            1, 4,
            3, 7,
            5, 3,
            5, 6,
            1, 3,
            0
        ],
        size=14
    )
    mat_frame_inside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Window in",
        description="Material index of window frame inside",
        items=mat_enum,
        get=mat_index_getter(MAT_FRAME_INSIDE),
        set=mat_index_setter(MAT_FRAME_INSIDE),
        update=update_parent
    )
    mat_frame_outside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Window out",
        description="Material index of window frame outside",
        items=mat_enum,
        get=mat_index_getter(MAT_FRAME_OUTSIDE),
        set=mat_index_setter(MAT_FRAME_OUTSIDE),
        update=update_parent
    )
    mat_out_frame: EnumProperty(
        options={'SKIP_SAVE'},
        name="Frame out",
        description="Material index of frame outside",
        items=mat_enum,
        get=mat_index_getter(MAT_OUT_FRAME),
        set=mat_index_setter(MAT_OUT_FRAME),
        update=update_parent
    )
    mat_glass: EnumProperty(
        options={'SKIP_SAVE'},
        description="Material index of glass",
        name="Glass",
        items=mat_enum,
        get=mat_index_getter(MAT_GLASS),
        set=mat_index_setter(MAT_GLASS),
        update=update_parent
    )
    mat_override: BoolProperty(
        name="Override material",
        default=False,
        update=update_parent
    )

    @property
    def parent_data(self):
        return self.id_data.archipack_window[0]

    def update_parent(self, context):
        if self.parent_data.auto_update:
            self.parent_data.update(context)

    def window(self,
               d,
               fixed,
               side_material,
               only_glass=False):

        joint_h = 0.002
        joint_v = 2 * joint_h
        chanfer = 0.004
        if fixed:
            verre = 0.5 * min(0.45 * d.panel_y - 2 * (joint_h + 0.001), d.glass_thickness)
        else:
            verre = 0.5 * min(d.panel_y - 2 * (chanfer + joint_h + 0.001), d.glass_thickness)

        x0 = 0
        x1 = d.panel_x
        x2 = 0.75 * d.panel_x
        x3 = chanfer
        x4 = x1 + joint_v
        y0 = -d.panel_y
        y1 = 0
        y2 = -0.5 * d.panel_y
        y3 = -chanfer
        y4 = chanfer - d.panel_y
        mi, mo = d.id_mat(MAT_FRAME_INSIDE), d.id_mat(MAT_FRAME_OUTSIDE)
        mc = d.id_mat(MAT_GLASS_FRAME)
        mj = d.id_mat(MAT_JOINT)
        side_cap_front = -1
        side_cap_back = -1

        if fixed:
            # profil carre avec support pour verre
            # p ______       y1             -0.45 * panel_y           inside
            # / |            y3
            # |       |___                  y6
            # x       |___   y2  verre      y5
            # |       |      y4
            #  \______|      y0             -panel_y    frame
            # x0 x3   x1
            #
            x1 = 0.5 * d.panel_x
            x4 = x1 + joint_v

            y1 = -0.45 * d.panel_y
            y3 = y1 - chanfer
            y4 = chanfer + y0
            y2 = (y0 + y1) / 2
            # -2  - -0.45 * 2  -1.1 = -0.55
            available = 0.5 * (-y0 + y1) - verre - joint_h - 0.001
            yo = max(-available, min(available, d.glass_offset))
            y5 = y2 + yo - verre
            y6 = y2 + yo + verre
            if only_glass and d.separate_glass:

                if d.open_outside:
                    return WindowPanel(
                        False,  # closed
                        [0, 0],  # x index
                        [x4],
                        [-y5, -y6],
                        [mc, mc],  # materials
                        side_cap_front=0,
                        side_cap_back=1  # cap index
                    )
                else:

                    return WindowPanel(
                        False,  # closed
                        [0, 0],  # x index
                        [x4],
                        [y6, y5],
                        [mc, mc],  # materials
                        side_cap_front=0,
                        side_cap_back=1  # cap index
                    )

            else:

                if d.open_outside:
                    if d.enable_glass and not d.separate_glass:
                        side_cap_front = 12-7
                        side_cap_back = 12-10

                    return WindowPanel(
                        True,  # closed shape
                        list(reversed([1, 0, 0, 0, 1, 2, 2, 3, 2, 2, 3, 2, 2])),  # x index
                        [x0, x3, x1, x4],  # unique x positions
                        list(reversed(
                            [-v for v in [y0, y4, y2, y3, y1, y1, y6 + joint_h, y6, y6, y5, y5, y5 - joint_h, y0]]
                        )),
                        list(reversed([mo, mo, mi, mi, mi, mi, mj, mj, mc, mj, mj, mo, mo, mo])),  # materials
                        side_cap_front=side_cap_front,
                        side_cap_back=side_cap_back,  # cap index
                        vertex_groups={'outside_out': 0, 'inside_out': 1, 'inside_in': 2, 'outside_in': 5}
                    )

                if d.enable_glass and not d.separate_glass:
                    side_cap_front = 7
                    side_cap_back = 10

                return WindowPanel(
                    True,  # closed
                    [1, 0, 0, 0, 1, 2, 2, 3, 2, 2, 3, 2, 2],  # x index
                    [x0, x3, x1, x4],
                    [y0, y4, y2, y3, y1, y1, y6 + joint_h, y6, y6, y5, y5, y5 - joint_h, y0],
                    [mo, mo, mi, mi, mi, mi, mj, mj, mc, mj, mj, mo, mo, mo],  # materials
                    side_cap_front=side_cap_front,
                    side_cap_back=side_cap_back,  # cap index
                    vertex_groups={'outside_out': 0, 'inside_out': 1, 'inside_in': 2, 'outside_in': 5}
                )
        else:
            # profil avec chanfrein et joint et support pour verre
            # p ____         y1    inside
            # /     |_       y3
            # |       |___y5
            # x       |___   y2  verre
            # |      _|   y6 y4
            #  \____|        y0
            # x0 x3 x2 x1 x4         outside
            available = 0.5 * (-y0 + y1) - verre - chanfer - joint_h - 0.001
            yo = max(-available, min(available, d.glass_offset))
            y5 = y2 + yo - verre
            y6 = y2 + yo + verre

            # TODO: handle hung window sides materials
            if side_material == 0:
                materials = [mo, mo, mi, mi, mi, mi, mi, mi, mj, mj, mc, mj, mj, mo, mo, mo, mo]
            elif side_material == 1:
                # rail window exterior
                materials = [mo, mo, mo, mi, mi, mi, mi, mi, mj, mj, mc, mj, mj, mo, mo, mo, mo]
            else:
                # rail window interior
                materials = [mo, mi, mi, mi, mi, mi, mi, mi, mj, mj, mc, mj, mj, mo, mo, mo, mo]

            if only_glass and d.separate_glass:
                if d.open_outside:
                    return WindowPanel(
                        False,  # closed shape
                        [0, 0],  # x index
                        [x4],  # unique x positions
                        [-y5, -y6],
                        [mj, mj],  # materials
                        side_cap_front=0,
                        side_cap_back=1  # cap index
                    )
                else:
                    return WindowPanel(
                        False,  # closed shape
                        [0, 0],  # x index
                        [x4],  # unique x positions
                        [y6, y5],
                        [mj, mj],  # materials
                        side_cap_front=0,
                        side_cap_back=1  # cap index
                    )
            else:

                if d.open_outside:
                    if d.enable_glass and not d.separate_glass:
                        side_cap_front = 16-9
                        side_cap_back = 16-12
                    return WindowPanel(
                        True,  # closed shape
                        list(reversed([1, 0, 0, 0, 1, 2, 2, 3, 3, 4, 3, 3, 4, 3, 3, 2, 2])),  # x index
                        [x0, x3, x2, x1, x4],  # unique x positions
                        list(reversed([-v for v in [y0, y4, y2, y3, y1, y1, y3, y3, y6 + joint_h, y6, y6, y5, y5, y5 - joint_h, y4, y4, y0]])),
                        list(reversed(materials)),  # materials
                        side_cap_front=side_cap_front,
                        side_cap_back=side_cap_back  # cap index
                    )
                if d.enable_glass and not d.separate_glass:
                    side_cap_front = 9
                    side_cap_back = 12
                return WindowPanel(
                    True,  # closed shape
                    [1, 0, 0, 0, 1, 2, 2, 3, 3, 4, 3, 3, 4, 3, 3, 2, 2],  # x index
                    [x0, x3, x2, x1, x4],  # unique x positions
                    [y0, y4, y2, y3, y1, y1, y3, y3, y6 + joint_h, y6, y6, y5, y5, y5 - joint_h, y4, y4, y0],
                    materials,  # materials
                    side_cap_front=side_cap_front,
                    side_cap_back=side_cap_back  # cap index
                )

    def update(self,
               context,
               o,
               d,
               origin,
               center,
               radius,
               size,
               pivot,
               shape,
               fixed,
               side_material
               ):

        mat_glass = d.id_mat(MAT_GLASS)
        window = self.window(d, fixed, side_material, False)

        offset = Vector((0, 0, 0))
        verts = window.vertices(d.curve_steps, offset, center, origin, size,
                                radius, d.angle_y, pivot, shape_z=None, path_type=shape)
        faces = window.faces(d.curve_steps, path_type=shape)

        matids = window.mat(d.curve_steps, mat_glass, mat_glass, path_type=shape)
        uvs = window.uv(d.curve_steps, center, origin, size,
                        radius, d.angle_y, pivot, 0, d.frame_x, path_type=shape)
        col = self.random_color
        vcolors = window.vcolors(d.curve_steps, col, path_type=shape)
        bm = bmed.buildmesh(o, verts, faces, matids, uvs, vcolors=vcolors)

        c = self.find_one_by_flag(o, 'glass')
        if d.separate_glass and d.enable_glass:
            if c is None:
                c, m = self.create_mesh("Window glass")
                self.set_flag(c, 'glass', True)
                c.parent = o
                self.link_object_to_scene(context, c, layer_name="Openings")
                # self.hide_for_render_engines(c)
                self.link_collections(o, c)

            window = self.window(d, fixed, side_material, True)
            verts = window.vertices(d.curve_steps, offset, center, origin, size,
                                    radius, d.angle_y, pivot, shape_z=None, path_type=shape)

            faces = window.faces(d.curve_steps, path_type=shape)
            matids = window.mat(d.curve_steps, mat_glass, mat_glass, path_type=shape)
            uvs = window.uv(d.curve_steps, center, origin, size,
                            radius, d.angle_y, pivot, 0, d.frame_x, path_type=shape)
            col = self.random_color
            vcolors = window.vcolors(d.curve_steps, col, path_type=shape)
            bmed.buildmesh(c, verts, faces, matids, uvs, vcolors=vcolors)

            self.link_materials(context, o, c)
            self.shade_smooth(context, c, 0.20944)

        elif c is not None:
            self.delete_object(context, c)

        self.shade_smooth(context, o, 0.20944)


class archipack_window_panelrow2(Archipacki18n, PropertyGroup):

    parts: CollectionProperty(type=archipack_window_panel)

    cols: IntProperty(
        name="Window leaf",
        description="Number of leaf on this row",
        min=1,
        max=512,
        default=2,
        get=get_cols, set=set_cols
    )
    n_cols: IntProperty(
        name="Window leaf",
        description="store number of leaf, internal use only to avoid infinite recursion",
        min=1,
        max=512,
        default=2,
        update=update
    )
    height: FloatProperty(
        name="Height",
        min=0.1,
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        name="auto_update",
        description="Disable auto update to avoid infinite recursion",
        default=True
    )

    @property
    def parent_data(self):
        return self.id_data.archipack_window[0]

    def get_row(self, x, y):
        size = [Vector((x * part.width / 100, y, 0)) for part in self.parts[:-1]]
        sum_x = sum([s.x for s in size])
        size.append(Vector((x - sum_x, y, 0)))
        origin = []
        pivot = []
        ttl = 0
        xh = x / 2
        n_center = len(size) / 2
        for i, sx in enumerate(size):
            ttl += sx.x
            if i < n_center:
                # pivot left
                origin.append(Vector((ttl - xh - sx.x, 0, 0)))
                pivot.append(1)
            else:
                # pivot right
                origin.append(Vector((ttl - xh, 0, 0)))
                pivot.append(-1)
        return size, origin, pivot

    def add_col(self):
        p = self.parts.add()
        p.part_uid = str(uuid4())
        return p

    def _set_width(self, cols):
        # cols is 1 based
        n_parts = len(self.parts)
        for i in range(n_parts, cols, -1):
            self.parts.remove(i - 1)
        for i in range(n_parts, cols):
            self.add_col()
        width = 100 / cols
        for part in self.parts:
            part.width = width

    def update(self, context):
        if self.auto_update:
            self.parent_data.update(context, childs_only=False)

    def draw(self, context, layout, box, last_row):
        # store parent at runtime to trigger update on parent
        row = box.row()
        self.draw_prop(context, layout, row, self, "cols")
        row = box.row()
        if not last_row:
            self.draw_prop(context, layout, row, self, "height")
        for i, panel in enumerate(self.parts):
            row = box.row()
            if i + 1 < self.cols:
                self.draw_prop(context, layout, row, panel, "width", text="Col", postfix=str(i + 1))
            row = box.row()
            self.draw_prop(context, layout, row, panel, "fixed", text="fixed")
            self.draw_prop(context, layout, row, panel, "handle_side", text="Handle")


class archipack_window_panelrow(Archipacki18n, PropertyGroup):

    # NOTE: 32 is max len !
    # must rely on collection property to overcome this issue
    width: FloatVectorProperty(
        name="Width",
        description="Leaf width in percent of overall width",
        min=0.1,
        max=100.0,
        default=[50 for i in range(31)],
        size=31,
        update=update
    )
    fixed: BoolVectorProperty(
        name="Fixed",
        description="Fixed leaf (generate a smallest frame)",
        default=[False for i in range(32)],
        size=32,
        update=update
    )

    cols: IntProperty(
        name="Window leaf",
        description="Number of leaf on this row (up to 32)",
        min=1,
        max=32,
        default=2,
        get=get_cols, set=set_cols
    )
    n_cols: IntProperty(
        name="Window leaf",
        description="store number of leaf, internal use only to avoid infinite recursion",
        min=1,
        max=32,
        default=2,
        update=update
    )
    height: FloatProperty(
        name="Height",
        min=0.1,
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        name="auto_update",
        description="Disable auto update to avoid infinite recursion",
        default=True
    )

    @property
    def parent_data(self):
        return self.id_data.archipack_window[0]

    def get_row(self, x, y):
        size = [Vector((x * self.width[w] / 100, y, 0)) for w in range(self.cols - 1)]
        sum_x = sum([s.x for s in size])
        size.append(Vector((x - sum_x, y, 0)))
        origin = []
        pivot = []
        ttl = 0
        xh = x / 2
        n_center = len(size) / 2
        for i, sx in enumerate(size):
            ttl += sx.x
            if i < n_center:
                # pivot left
                origin.append(Vector((ttl - xh - sx.x, 0, 0)))
                pivot.append(1)
            else:
                # pivot right
                origin.append(Vector((ttl - xh, 0, 0)))
                pivot.append(-1)
        return size, origin, pivot

    def _set_width(self, cols):
        width = 100 / cols
        for i in range(cols - 1):
            self.width[i] = width

    def update(self, context):
        if self.auto_update:
            self.parent_data.update(context, childs_only=False)

    def draw(self, context, layout, box, last_row):
        # store parent at runtime to trigger update on parent
        row = box.row()
        self.draw_prop(context, layout, row, self, "cols")
        row = box.row()
        if not last_row:
            self.draw_prop(context, layout, row, self, "height")
        for i in range(self.cols - 1):
            row = box.row()
            self.draw_prop(context, layout, row, self, "width", text="Col", postfix=str(i + 1), index=i)
            self.draw_prop(context, layout, row, self, "fixed", text="fixed", index=i)
        row = box.row()
        self.draw_label(context, layout, row, "Col", postfix=str(self.cols))
        self.draw_prop(context, layout, row, self, "fixed", text="fixed", index=(self.cols - 1))


class archipack_window_shutter(ArchipackObject, PropertyGroup):

    def shutter(self, d):
        border = d.shutter_border
        chanfer = 0.004
        spacing = 0.75 * border
        x0 = 0
        x1 = border - 0.5 * spacing
        x3 = chanfer
        w = 0.5 * d.shutter_depth
        # offset pivot point on outside part
        y0 = 0
        y1 = y0 + w
        y2 = y1 - 0.5 * w
        y3 = y1 - chanfer
        y4 = y0 + chanfer

        # profil
        # p ______   y1
        #  /         y3
        # |
        # x          y2
        # |          y4
        #  \______   y0
        # x0 x3   x1
        #
        mat = d.id_mat(MAT_SHUTTER)
        side = WindowPanel(
            False,  # closed
            [2, 1, 0, 0, 0, 1, 2],  # x index
            [x0, x3, x1],
            [y0, y0, y4, y2, y3, y1, y1],
            [mat] * 7,  # materials
            closed_path=True,    #
            subdiv_x=0,
            subdiv_y=1
            )

        #     /   y2-y3
        #  __/    y1-y0
        #   x2 x3
        x2 = 0.5 * spacing
        x3 = x2 + chanfer
        y2 = y1 - chanfer
        y3 = y0 + chanfer

        face = WindowPanel(
            False,              # profil closed
            [0, 1, 2],          # x index
            [0, x2, x3],
            [y1, y1, y2],
            [mat] * 3,          # material index
            side_cap_front=2,   # cap index
            closed_path=True
            )

        back = WindowPanel(
            False,              # profil closed
            [0, 1, 2],          # x index
            [x3, x2, 0],
            [y3, y0, y0],
            [mat] * 3,          # material index
            side_cap_back=0,    # cap index
            closed_path=True
            )

        return side, face, back

    def hinge(self, altitude, offset, pivot, hinge_size, verts):

        # panel chanfer
        chanfer = 0.004

        seg = 12
        deg = 2 * pi / seg
        radius = hinge_size / 6
        x = 0
        y = 0
        z = altitude

        d = (offset + pivot * chanfer) / radius
        tM = Matrix([
            [radius, 0, 0, x],
            [0, radius, 0, y],
            [0, 0, hinge_size, z - 0.5 * hinge_size],
            [0, 0, 0, 1]
        ])
        if pivot < 0:
            verts.extend([tM @ Vector((sin(deg * a), cos(deg * a), 0)) for a in range(seg - 2)])
            verts.extend([
                tM @ Vector((d, cos(deg * (seg - 3)), 0)),
                tM @ Vector((d, 1, 0)),
            ])
        else:
            verts.extend([tM @ Vector((sin(deg * a), cos(deg * a), 0)) for a in range(3, seg + 1)])
            verts.extend([
                tM @ Vector((d, 1, 0)),
                tM @ Vector((d, cos(deg * (seg - 3)), 0)),
            ])

        if pivot < 0:
            verts.extend([tM @ Vector((sin(deg * a), cos(deg * a), 1)) for a in range(seg - 2)])
            verts.extend([
                tM @ Vector((d, cos(deg * (seg - 3)), 1)),
                tM @ Vector((d, 1, 1)),
            ])
        else:
            verts.extend([tM @ Vector((sin(deg * a), cos(deg * a), 1)) for a in range(3, seg + 1)])
            verts.extend([
                tM @ Vector((d, 1, 1)),
                tM @ Vector((d, cos(deg * (seg - 3)), 1)),
            ])

    def verts(self, d, shutter, size, center, origin, pivot, radius, offset, hinge_enable, hinge_count, hinge_space):

        side, face, back = shutter
        border = d.shutter_border
        spacing = 0.75 * border

        x1 = border - 0.5 * spacing
        _offset = Vector((offset, 0, 0))
        verts = side.vertices(d.curve_steps, _offset, center, origin, size,
            radius, d.angle_y, pivot, shape_z=None, path_type=d.shape)

        p_radius = radius.copy()
        p_radius.x -= x1
        p_radius.y -= x1

        p_size = Vector((size.x - 2 * x1, (size.y - 2 * x1) / 2, 0))

        for j in range(2):
            if j < 1:
                shape = 'RECTANGLE'
            else:
                shape = d.shape

            _offset = Vector((
                offset + pivot * x1,
                p_size.y * j + x1,
                0))

            _origin = Vector((
                origin.x + pivot * x1,
                p_size.y * j + x1,
                0))

            verts += face.vertices(d.curve_steps, _offset, center, _origin,
                p_size, p_radius, d.angle_y, pivot, shape_z=None, path_type=shape)
            verts += back.vertices(d.curve_steps, _offset, center, _origin,
                p_size, p_radius, d.angle_y, pivot, shape_z=None, path_type=shape)

        if hinge_enable:
            z0 = 0.15
            dz = (hinge_space - 2 * z0) / (hinge_count - 1)
            for j in range(hinge_count):
                self.hinge(z0 + dz * j, offset, pivot, d.shutter_hinge, verts)

        return verts

    def faces(self, d, shutter, hinge_enable, hinge_count):

        side, face, back = shutter

        faces = side.faces(d.curve_steps, path_type=d.shape)
        faces_offset = side.n_verts(d.curve_steps, path_type=d.shape)

        for j in range(2):
            if j < 1:
                shape = 'RECTANGLE'
            else:
                shape = d.shape
            faces += face.faces(d.curve_steps, path_type=shape, offset=faces_offset)
            faces_offset += face.n_verts(d.curve_steps, path_type=shape)
            faces += back.faces(d.curve_steps, path_type=shape, offset=faces_offset)
            faces_offset += back.n_verts(d.curve_steps, path_type=shape)

        if hinge_enable:
            seg = 12
            for j in range(hinge_count):
                faces.append(tuple([faces_offset + i + seg for i in range(seg - 1, -1, -1)]))
                faces.append(tuple([faces_offset + i for i in range(seg)]))
                faces.extend([tuple([faces_offset + i + f for f in (1, 0, seg, seg + 1)]) for i in range(seg - 1)])
                faces.append((
                    faces_offset,
                    faces_offset + seg - 1,
                    faces_offset + 2 * seg - 1,
                    faces_offset + seg
                    ))

                faces_offset += 2 * seg

        return faces

    def uvs(self, d, shutter, size, center, origin, pivot, radius, hinge_enable, hinge_count):

        side, face, back = shutter
        border = d.shutter_border
        spacing = 0.75 * border
        x1 = border - 0.5 * spacing

        uvs = side.uv(d.curve_steps,
            center,
            origin,
            size,
            radius,
            d.angle_y,
            pivot,
            border, 0,
            path_type=d.shape)

        p_radius = radius.copy()
        p_radius.x -= x1
        p_radius.y -= x1
        p_size = Vector((size.x - 2 * x1, (size.y - 2 * x1) / 2, 0))

        for j in range(2):
            if j < 1:
                shape = 'RECTANGLE'
            else:
                shape = d.shape
            _origin = Vector((
                origin.x + pivot * x1,
                p_size.y * j + x1,
                0))
            uvs += face.uv(d.curve_steps, center, _origin, p_size,
                p_radius, d.angle_y, pivot, 0, 0, path_type=shape)
            uvs += back.uv(d.curve_steps, center, _origin, p_size,
                p_radius, d.angle_y, pivot, 0, 0, path_type=shape)

        if hinge_enable:
            seg = 12
            deg = 2 * pi / seg
            _radius = 0.005
            x = 0
            y = 0
            z = 0
            _size = 0.04
            tM = Matrix([
                [_radius, 0, 0, x],
                [0, _radius, 0, y],
                [0, 0, _size, z],
                [0, 0, 0, 1]
            ])

            for j in range(hinge_count):
                uvs.append(tuple([(tM @ Vector((sin(deg * a), cos(deg * a), 0))).to_2d() for a in range(seg)]))
                uvs.append(tuple([(tM @ Vector((sin(deg * a), cos(deg * a), 0))).to_2d() for a in range(seg)]))
                uvs.extend([[(0, 0), (0, 1), (1, 1), (1, 0)] for i in range(seg)])

        return uvs

    def matids(self, d, shutter, hinge_enable, hinge_count):

        side, face, back = shutter
        ms, mh = d.id_mat(MAT_SHUTTER), d.id_mat(MAT_HINGE)
        mat = side.mat(d.curve_steps, ms, ms, path_type=d.shape)
        for j in range(2):
            if j < 1:
                shape = 'RECTANGLE'
            else:
                shape = d.shape
            mat += face.mat(d.curve_steps, ms, ms, path_type=shape)
            mat += back.mat(d.curve_steps, ms, ms, path_type=shape)

        if hinge_enable:
            for j in range(hinge_count):
                seg = 12
                mat.extend([mh] * (seg + 2))
        return mat

    def vcolors(self, d, shutter, hinge_enable, hinge_count):

        side, face, back = shutter
        col = self.random_color
        vcolors = side.vcolors(d.curve_steps, col, path_type=d.shape)
        for j in range(2):
            if j < 1:
                shape = 'RECTANGLE'
            else:
                shape = d.shape
            col = self.random_color
            vcolors += face.vcolors(d.curve_steps, col, path_type=shape)
            vcolors += back.vcolors(d.curve_steps, col, path_type=shape)

        if hinge_enable:
            for j in range(hinge_count):
                seg = 12
                vcolors.extend([col] * (seg + 2))
        return vcolors

    def update(self,
            context,
            o,
            d,
            origin,
            center,
            radius,
            size,
            pivot,
            offset,
            hinge_enable,
            hinge_count,
            hinge_space):

        shutter = self.shutter(d)
        verts = self.verts(d, shutter, size, center, origin, pivot, radius, offset,
                           hinge_enable, hinge_count, hinge_space)
        faces = self.faces(d, shutter, hinge_enable, hinge_count)
        matids =  self.matids(d, shutter, hinge_enable, hinge_count)
        uvs = self.uvs(d, shutter, size, center, origin, pivot, radius,
                       hinge_enable, hinge_count)
        vcolors = self.vcolors(d, shutter, hinge_enable, hinge_count)
        bmed.buildmesh(o, verts, faces, matids, uvs, vcolors=vcolors)

        self.shade_smooth(context, o, 0.20944)
        return None


class archipack_window(
    ArchipackObject, ArchipackHandle, Compound, Customizable, Snappable,
    Manipulable, DimensionProvider, Bendable, PropertyGroup
):
    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('MAIN', 'Main', 'Display main settings', 'NONE', 0),
            ('PARTS', 'Leaf', 'Display leaf settings', 'NONE', 1),
            ('SUB', 'Parts', 'Display components settings', 'NONE', 2),
            ('MATERIALS', '', 'Display materials settings', 'MATERIAL', 3)
        ),
        default='MAIN',
    )

    x: FloatProperty(
        name='Width',
        min=0.1,
        default=100.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Width', update=update
    )
    y: FloatProperty(
        name='Depth',
        min=0.01,
        default=0.20, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description="Depth\nBasically the thickness of wall, keep as it", update=update,
    )
    z: FloatProperty(
        name='Height',
        min=0.1,
        default=1.2, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Height', update=update,
    )
    angle_y: FloatProperty(
        name='Angle',
        unit='ROTATION',
        subtype='ANGLE',
        min=-1.5, max=1.5,
        default=0, precision=5,
        description='Angle', update=update,
    )
    radius: FloatProperty(
        name='Radius',
        min=0.1,
        default=2.5, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Radius', update=update,
    )
    elipsis_b: FloatProperty(
        name='Ellipsis',
        min=0.1,
        default=0.5, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Ellipsis vertical size', update=update,
    )
    altitude: FloatProperty(
        name='Altitude',
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Altitude', update=update,
    )
    offset: FloatProperty(
        name='Offset',
        default=0.1, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Offset', update=update,
    )
    frame_y: FloatProperty(
        name='Depth',
        min=0,
        default=0.06, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Frame depth', update=update,
    )
    frame_x: FloatProperty(
        name='Width',
        min=0,
        default=0.06, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Frame width', update=update,
    )
    frame_overflow: FloatProperty(
        name='Overflow',
        min=0,
        default=0.06, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='How much the frame overflow the hole',
        update=update,
    )
    finishing_out: FloatProperty(
        name='Finishing thickness',
        min=0,
        default=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Thickness of outside wall finishing'
    )
    finishing_int: FloatProperty(
        name='Finishing thickness',
        min=0,
        default=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Thickness of outside wall finishing'
    )
    panel_x: FloatProperty(
        name='Width',
        min=0,
        default=0.06, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='panel width', update=update,
    )
    panel_y: FloatProperty(
        name='Depth',
        min=0,
        default=0.06, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='panel depth', update=update,
    )
    out_frame: BoolProperty(
        description="Create a frame outside",
        name="Out frame",
        default=False, update=update,
    )
    out_frame_closed: BoolProperty(
        description="Close the frame outside on bottom",
        name="Close",
        default=False, update=update,
    )
    out_frame_y: FloatProperty(
        name='Side Depth',
        min=0.001,
        default=0.02, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='frame side depth', update=update,
    )
    out_frame_y2: FloatProperty(
        name='Front Depth',
        min=0.001,
        default=0.02, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='frame front depth', update=update,
    )
    out_frame_x: FloatProperty(
        name='Front Width',
        min=0.0,
        default=0.1, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='frame width set to 0 disable front frame', update=update,
    )
    out_frame_offset: FloatProperty(
        name='Offset',
        min=0.0,
        default=0.0, precision=3, step=0.1,
        unit='LENGTH', subtype='DISTANCE',
        description='frame offset', update=update,
    )
    out_tablet_enable: BoolProperty(
        description="Create a sill outside",
        name="Sill out",
        default=True, update=update,
    )
    out_tablet_x: FloatProperty(
        name='Width',
        min=0.0,
        default=0.04, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet width', update=update,
    )
    out_tablet_y: FloatProperty(
        name='Depth',
        min=0.001,
        default=0.04, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet depth', update=update,
    )
    out_tablet_z: FloatProperty(
        name='Height',
        min=0.001,
        default=0.03, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet height', update=update,
    )
    out_tablet_altitude: FloatProperty(
        name='Altitude',
        default=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet altitude', update=update,
    )
    out_tablet_spoiler: BoolProperty(
        description="Create a spoiler",
        name="Spoiler",
        default=True, update=update,
    )
    out_tablet_spoiler_height: FloatProperty(
        name='Height',
        default=0.01, precision=5, step=1, min=0,
        unit='LENGTH', subtype='DISTANCE',
        description='Spoiler height', update=update,
    )
    out_tablet_spoiler_width: FloatProperty(
        name='Width',
        default=0.05, precision=5, step=1, min=0.01,
        unit='LENGTH', subtype='DISTANCE',
        description='Spoiler width', update=update,
    )
    in_tablet_enable: BoolProperty(
        description="Create a sill inside",
        name="Sill in",
        default=True, update=update,
    )
    in_tablet_x: FloatProperty(
        name='Width',
        min=0.0,
        default=0.04, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet width', update=update,
    )
    in_tablet_y: FloatProperty(
        name='Depth',
        min=0.001,
        default=0.04, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet depth', update=update,
    )
    in_tablet_z: FloatProperty(
        name='Height',
        min=0.001,
        default=0.03, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet height', update=update,
    )
    in_tablet_altitude: FloatProperty(
        name='Altitude',
        default=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet altitude', update=update,
    )
    blind_inside: BoolProperty(
        default=False,
        name="Blind inside",
        description="Generate a blind inside",
        update=update
    )
    blind_outside: BoolProperty(
        default=False,
        name="Blind outside",
        description="Generate a blind outside",
        update=update
    )

    curtain_sill_enable: BoolProperty(
        description="Create a sill",
        name="Sill",
        default=False, update=update,
    )
    curtain_sill_y: FloatProperty(
        name='Depth',
        min=0.001,
        default=0.2, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Sill curtain depth', update=update,
    )
    curtain_sill_z: FloatProperty(
        name='Height',
        min=0.001,
        default=0.03, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Sill curtain height', update=update,
    )
    curtain_sill_alt: FloatProperty(
        name='Altitude',
        default=0.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Sill curtain altitude', update=update,
    )
    curtain_sill_x: FloatProperty(
        name='Over width',
        default=0.05, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Sill curtain over width', update=update,
    )
    curtain_rod_enable: BoolProperty(
        name="Rod",
        default=False, update=update,
    )
    curtain_rod_y: FloatProperty(
        name='Depth',
        min=0.001,
        default=0.15, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Distance from wall', update=update,
    )
    curtain_rod_radius: FloatProperty(
        name='Radius',
        min=0.001,
        default=0.015, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Rod radius', update=update,
    )
    curtain_rod_alt: FloatProperty(
        name='Altitude',
        default=-0.05, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Rod altitude', update=update,
    )
    curtain_rod_x: FloatProperty(
        name='Over width',
        default=0.05, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Rod over width', update=update,
    )

    # kept to allow migration between data models
    rows: CollectionProperty(type=archipack_window_panelrow)
    rows2: CollectionProperty(type=archipack_window_panelrow2)

    n_rows: IntProperty(
        name="Number of rows",
        min=1,
        max=128,
        default=1, update=update,
    )
    # 2 to allow triangle using circle as base
    curve_steps: IntProperty(
        name="Resolution",
        min=2,
        max=128,
        default=16, update=update,
    )
    idmat: IntVectorProperty(
        default=[
            2,
            1, 0,
            1, 4,
            3, 7,
            5, 3,
            5, 6,
            1, 3,
            0
        ],
        size=14
    )

    mat_curtain_rod: EnumProperty(
        options={'SKIP_SAVE'},
        name="Rod curtain",
        description="Material index of curtain rod",
        items=mat_enum,
        get=mat_index_getter(MAT_ROD_CURTAIN),
        set=mat_index_setter(MAT_ROD_CURTAIN),
        update=update
    )
    mat_curtain_sill: EnumProperty(
        options={'SKIP_SAVE'},
        name="Sill curtain",
        description="Material index of curtain sill",
        items=mat_enum,
        get=mat_index_getter(MAT_SILL_CURTAIN),
        set=mat_index_setter(MAT_SILL_CURTAIN),
        update=update
    )
    mat_frame_inside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Window in",
        description="Material index of frame inside",
        items=mat_enum,
        get=mat_index_getter(MAT_FRAME_INSIDE),
        set=mat_index_setter(MAT_FRAME_INSIDE),
        update=update
    )

    mat_frame_outside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Window out",
        description="Material index of frame outside",
        items=mat_enum,
        get=mat_index_getter(MAT_FRAME_OUTSIDE),
        set=mat_index_setter(MAT_FRAME_OUTSIDE),
        update=update
    )
    mat_out_frame: EnumProperty(
        options={'SKIP_SAVE'},
        name="Frame out",
        description="Material index of frame outside",
        items=mat_enum,
        get=mat_index_getter(MAT_OUT_FRAME),
        set=mat_index_setter(MAT_OUT_FRAME),
        update=update
    )
    mat_sill_in: EnumProperty(
        options={'SKIP_SAVE'},
        name="Sill in",
        description="Material index of sill in",
        items=mat_enum,
        get=mat_index_getter(MAT_SILL_IN),
        set=mat_index_setter(MAT_SILL_IN),
        update=update
    )

    mat_sill_out: EnumProperty(
        options={'SKIP_SAVE'},
        description="Material index of sill out",
        name="Sill out",
        items=mat_enum,
        get=mat_index_getter(MAT_SILL_OUT),
        set=mat_index_setter(MAT_SILL_OUT),
        update=update
    )

    mat_spoiler: EnumProperty(
        options={'SKIP_SAVE'},
        description="Material index of spoiler",
        name="Spoiler",
        items=mat_enum,
        get=mat_index_getter(MAT_SPOILER),
        set=mat_index_setter(MAT_SPOILER),
        update=update
    )

    mat_shutter: EnumProperty(
        options={'SKIP_SAVE'},
        description="Material index of shutters",
        name="Shutter",
        items=mat_enum,
        get=mat_index_getter(MAT_SHUTTER),
        set=mat_index_setter(MAT_SHUTTER),
        update=update
    )

    mat_handle: EnumProperty(
        options={'SKIP_SAVE'},
        description="Material index of handle",
        name="Handle",
        items=mat_enum,
        get=mat_index_getter(MAT_HANDLE),
        set=mat_index_setter(MAT_HANDLE),
        update=update
    )

    mat_hinge: EnumProperty(
        options={'SKIP_SAVE'},
        description="Material index of hinge",
        name="Hinge",
        items=mat_enum,
        get=mat_index_getter(MAT_HINGE),
        set=mat_index_setter(MAT_HINGE),
        update=update
    )

    mat_glass: EnumProperty(
        options={'SKIP_SAVE'},
        description="Material index of glass",
        name="Glass",
        items=mat_enum,
        get=mat_index_getter(MAT_GLASS),
        set=mat_index_setter(MAT_GLASS),
        update=update
    )

    mat_glass_frame: EnumProperty(
        options={'SKIP_SAVE'},
        description="Material index of glass frame",
        name="Glass frame",
        items=mat_enum,
        get=mat_index_getter(MAT_GLASS_FRAME),
        set=mat_index_setter(MAT_GLASS_FRAME),
        update=update
    )

    mat_joint: EnumProperty(
        options={'SKIP_SAVE'},
        description="Material index of glass joints",
        name="Joint",
        items=mat_enum,
        get=mat_index_getter(MAT_JOINT),
        set=mat_index_setter(MAT_JOINT),
        update=update
    )

    # TODO: take a look at this as materials are wall's ones
    mat_hole_outside: IntProperty(
        name="Outside",
        description="Material index of wall for outside part of the hole",
        min=0,
        max=128,
        default=1
    )

    mat_hole_inside: IntProperty(
        name="Inside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0
    )
    mat_finish_inside: IntProperty(
        name="Finish Inside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0
    )
    mat_finish_outside: IntProperty(
        name="Finish Outside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0
    )
    window_shape: EnumProperty(
        name='Shape',
        items=(
            ('RECTANGLE', 'Rectangle', '', 0),
            ('ROUND', 'Top Round', '', 1),
            ('ELLIPSIS', 'Top elliptic', '', 2),
            ('QUADRI', 'Top oblique', '', 3),
            ('CIRCLE', 'Full circle', '', 4)
        ),
        default='RECTANGLE', update=update,
    )
    window_type: EnumProperty(
        name='Type',
        items=(
            ('FLAT', 'Swing window', '', 0),
            ('RAIL', 'Rail window', '', 1),
            ('HUNG', 'Hung window', '', 2),
            ('USER', 'User defined Window', 'Replace all geometry by custom one', 3),
            ('USER_FRAME', 'User defined Frame', 'Replace frame geometry by custom one', 4),
            ('USER_PANEL',  'User defined Leaf', 'Replace leaf geometry by custom one,\nonly valid with rectangular shapes', 5),
        ),
        default='FLAT', update=update_user_object,
    )
    glass_offset: FloatProperty(
        name='Offset',
        default=0.0, precision=6, step=0.1,
        unit='LENGTH', subtype='DISTANCE',
        description='Offset glass from axis, positive move inside', update=update,
    )
    glass_thickness: FloatProperty(
        name='Thickness',
        default=0.016, precision=6, step=0.1,
        min=0.001,
        unit='LENGTH', subtype='DISTANCE',
        description='Glass thicnkess', update=update,
    )
    enable_glass: BoolProperty(
        name="Glass",
        default=True,
        description='Enable Glass',
        update=update
    )
    separate_glass: BoolProperty(
        name="Separate",
        default=True,
        description='Separate object for glass',
        update=update
    )
    warning: BoolProperty(
        options={'SKIP_SAVE'},
        name="Warning",
        default=False
    )

    shutter_enable: BoolProperty(
        name="Shutters",
        default=False, update=update,
    )
    shutter_left: IntProperty(
        name="Left",
        description="Number of shutters on left side",
        default=1,
        update=update
    )
    shutter_right: IntProperty(
        name="Right",
        description="Number of shutters on right side",
        default=1,
        update=update
    )
    shutter_border: FloatProperty(
        name='Border',
        min=0,
        default=0.1, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Shutter panels borders',
        update=update
    )
    shutter_depth: FloatProperty(
        name='Depth',
        min=0.01,
        default=0.04, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Shutter panels depth',
        update=update
    )
    shutter_hinge: FloatProperty(
        name='Hinge',
        min=0.001,
        default=0.03, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Shutter hinge size',
        update=update
    )
    hole_margin: FloatProperty(
        name='Hole margin',
        min=0.001,
        default=0.1, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='How much hole surround wall',
        update=update
    )
    automatic_hole: BoolProperty(
        name="Automatic hole",
        default=True,
        description="Provide automatic hole geometry",
        update=update_auto_hole
    )
    flip: BoolProperty(
        default=False,
        update=update,
        description='flip outside and outside material of hole'
    )

    auto_mat: BoolProperty(
        name="Auto materials",
        default=True
    )
    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        default=True,
        update=update
    )
    portal: BoolProperty(
        default=False,
        name="Portal",
        description="Makes this window a light portal, enabling better photon gathering during render",
        update=update
    )
    portal_energy: FloatProperty(
        default=0.3,
        min=0, step=1, precision=5,
        name="Energy",
        description="Portal lamp energy for eevee",
        update=update
    )
    curtain_expand: BoolProperty(
        options={'SKIP_SAVE'},
        name="Curtain",
        default=False
    )
    shutter_expand: BoolProperty(
        options={'SKIP_SAVE'},
        name="Shutter",
        default=False
    )
    in_tablet_expand: BoolProperty(
        options={'SKIP_SAVE'},
        name="Sill in",
        default=False
    )
    out_tablet_expand: BoolProperty(
        options={'SKIP_SAVE'},
        name="Sill out",
        default=False
    )
    frame_expand: BoolProperty(
        options={'SKIP_SAVE'},
        name="Window Frame",
        default=False
    )
    out_frame_expand: BoolProperty(
        options={'SKIP_SAVE'},
        name="Frame out",
        default=False
    )
    panel_expand: BoolProperty(
        options={'SKIP_SAVE'},
        name="Panel frame",
        default=False
    )
    # not exposed, rail profile rail and front depht
    rail_depth:FloatProperty(
        name='Rail depth',
        min=0.0,
        default=0.005, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Rail window rails depth'
    )

    rail_frame_depth:FloatProperty(
        name='Frame depth',
        min=0.0,
        default=0.01, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Rail window out frame depth before panel'
    )

    handle_altitude: FloatProperty(
        name="Altitude",
        min=0,
        default=1.5, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='handle altitude', update=update_childs,
    )
    handle_type: EnumProperty(
        name="Type",
        items=(
            ('WINDOW_0000', "Short", "Short window handle"),
            ('WINDOW_0001', "Long",  "Long window handle"),
            ('WINDOW_USER', "User defined", "User defined mesh")
        ),
        default="WINDOW_0000",
        update=update_childs
    )
    handle_side: EnumProperty(
        name="Side",
        items=(
            ('BOTH', "Both", "Inside and outside"),
            ('INSIDE', "Inside", "Inside only"),
            ('OUTSIDE', "Outside", "Outside only"),
            ('NONE', "None", "Disable handles")
        ),
        default="INSIDE",
        update=update_childs
    )
    open: EnumProperty(
        name="Open",
        items=(
            ('INSIDE', "Inside", "Inside"),
            ('OUTSIDE', "Outside", "Outside"),
        ),
        default="INSIDE",
        update=update
    )

    align_to: EnumProperty(
        name="Align",
        items=(
            ('INSIDE', "Inside", "Wall Inside", icons["window_align_inside"].icon_id, 0),
            ('OUTSIDE', "Outside", "Wall Outside", icons["window_align_outside"].icon_id, 1),
            ('AXIS', "Axis", "Wall axis", icons["window_align_axis"].icon_id, 2)
        ),
        default="INSIDE",
        update=update
    )
    frame_layout: EnumProperty(
        name="Mount.",
        items=(
            ('INTERIOR', "Interior", "Interior surface-mounted window", icons["window_frame_inside"].icon_id, 0),
            ('EXTERIOR', "Exterior", "Exterior surface-mounted window", icons["window_frame_outside"].icon_id, 1),
            ('TUNNEL', "Nail-on frame", "Nail on frame window", icons["window_frame_axis"].icon_id, 2)
        ),
        default="INTERIOR",
        update=update
    )

    user_defined_hole: PointerProperty(
        name="Hole",
        type=Object,
        update=update_source
    )

    def get_member_datablock(self, o):
        return archipack_window_panel.datablock(o)

    @property
    def _members_parts(self):
        return [part for row in self.rows2 for part in row.parts]

    @property
    def open_outside(self):
        return self.open == 'OUTSIDE' and self.window_type == 'FLAT'

    def update_user_object(self, context):
        self.manipulable_refresh = True
        if not self.has_user_defined_object:
            self.cleanup_custom_mesh(context.active_object)
        if self.window_type in {"USER_FRAME"} and self.has_user_defined_object:
            self.auto_update = False
            self.x, self.z = self.user_defined_object.dimensions.x, self.user_defined_object.dimensions.z
            self.auto_update = True
        elif self.window_type in {'USER', 'USER_FRAME'} and self.has_user_defined_custom:
            self.auto_update = False
            d = self.user_defined_object.data.archipack_custom[0]
            self.x, self.z = d.x, d.z
            self.auto_update = True
        else:
            self.update(context)

    @property
    def bend_yw(self):
        if self.window_type == 'FLAT':
            y = self.hole_center_y + 0.5 * self._frame_y
            w = self.panel_y
        elif 'USER' not in self.window_type:
            y = self.hole_center_y + self.rail_frame_depth
            w = 2 * self.panel_y
        else:
            # bend at axis, not ideal but how to make it better ??
            y, w = 0.5 * self.y, 0
        return y, w

    @property
    def shape(self):
        if self.window_type in {'RAIL', 'HUNG'}:
            return 'RECTANGLE'
        else:
            return self.window_shape

    @property
    def window(self):
        # Flat window frame profil
        #    inside          inside
        #  ___        y1    _______
        # |   |__           |      |
        # |  oi  |    y2    | oo __|
        # |______|    y0    |___|
        # x1 x0 x2          x1  x0 x2
        #    outside         outside
        
        # path definition is boundary for panels so window so x0 is reference for the frame (0) on x axis
        x0 = 0
        x1 = -x0 - self.frame_x
        x2 = x0 + 0.1 * self.frame_x

        y0 = self.hole_center_y
        mat_in, mat_out, mat_side = self.id_mat(MAT_FRAME_INSIDE), \
                                    self.id_mat(MAT_FRAME_OUTSIDE), \
                                    self.id_mat(MAT_HINGE)
        if self.window_type in {'FLAT', 'USER_PANEL'}:
            y1 = y0 + self._frame_y
            y2 = y0 + (1 - LEAF_OVERFLOW) * self._frame_y
            if self.open_outside:
                y2 += (2 * LEAF_OVERFLOW - 1) * self.frame_y
                return WindowPanel(
                    True,  # closed
                    [0, 0, 2, 2, 1, 1],  # x index
                    [x1, x0, x2],
                    [y0, y1, y1, y2, y2, y0],
                    [mat_in, mat_in, mat_in, mat_in, mat_out, mat_out],  # material index
                    vertex_groups={'outside_out':0, 'inside_out':1, 'inside_in':2, 'outside_in':5}
                )
            else:
                return WindowPanel(
                    True,     # closed
                    [0, 0, 1, 1, 2, 2],     # x index
                    [x1, x0, x2],
                    [y0, y1, y1, y2, y2, y0],
                    [mat_in, mat_in, mat_in, mat_in, mat_out, mat_out],  # material index
                    vertex_groups={'outside_out':0, 'inside_out':1, 'inside_in':2, 'outside_in':5}
                    )
        else:
            # Rail window frame profil
            #  ________       y1
            # |      __|      y5
            # |     |__       y4
            # |      __|      y3
            # |     |____
            # |          |    y2
            # |__________|    y0
            # -x1   0 x3 x2

            out_depth = self.rail_frame_depth
            rail_depth = self.rail_depth
            # space not available for panels
            rails_depth = out_depth + 2 * rail_depth
            depth = self._frame_y

            x2 = x0 + 0.5 * self.frame_x
            x3 = x0 + 0.2 * self.frame_x
            x4 = x0 + 0.1 * self.frame_x

            y1 = y0 + depth
            yc = y0 + out_depth + 0.5 * rail_depth + 0.5 * (depth - rails_depth)
            y2 = y0 + out_depth
            y3 = yc - 0.5 * rail_depth
            y4 = yc + 0.5 * rail_depth
            y5 = y1 - rail_depth

            return WindowPanel(
                True,     # closed
                [0, 0, 2, 2, 1, 1, 2, 2, 1, 1, 3, 3],     # x index
                [x1, x4, x3, x2],
                [y0, y1, y1, y5, y5, y4, y4, y3, y3, y2, y2, y0],
                [mat_in, mat_in, mat_in, mat_side, mat_in, mat_side,
                mat_side, mat_side, mat_out, mat_side, mat_out, mat_out],  # material index
                vertex_groups={'outside_out':0, 'inside_out':1, 'inside_in':2, 'outside_in':11}
                )

    @property
    def hole(self):
        # profile for hole with inside greater than outside
        #                                         ____
        #   _____  y_inside          vertical ___|      x1
        #  |
        #  |__     y0                outside   ___
        #     |___ y_outside                       |____ x1-shape_z     inside
        # -x1 x0

        # reversed hole where outside is greater than inside
        # profil percement                    ____
        #     ___  y_inside          vertical     |____      x1
        #  __|
        #  |     y0                  outside       ___
        #  |______ y_outside                  ____|     x1-shape_z     inside
        # -x1 x0
        # is half of finishing gap
        gap = 0.0001

        y0 = self.hole_center_y

        if self.frame_layout == 'EXTERIOR':
            y0 += self.frame_y

        x0 = self._overflow - gap
        x1 = -self.frame_x  # sur-largeur percement interieur

        if self.out_frame:
            x0 -= min(self.frame_x, self.out_frame_y + self.out_frame_offset)

        # ensure y0 never is coplanar to wall
        if abs(y0) - 0.5 * self.y < gap:
            y0 -= gap

        y = 0.5 * self.y + gap
        y_inside = y + self.finishing_int + self.hole_margin    # inside wall

        outside_mat = self.mat_hole_outside
        inside_mat = self.mat_hole_inside
        in_finish_mat = self.mat_finish_inside
        out_finish_mat = self.mat_finish_outside
        # if self.flip:
        #    outside_mat, inside_mat = inside_mat, outside_mat

        y_outside = -y           # outside wall
        y_outside -= self.finishing_out + self.hole_margin

        if self.frame_layout == 'EXTERIOR':
            x1, x0 = x0, x1

        if (self._frame_overflow > 0) or (
                (self.out_frame and self.out_frame_offset > 0) or self.out_tablet_enable
        ):

            # hole with overflow
            # y must only grow !!
            x_indexes = [1]
            m_indexes = [out_finish_mat]
            y_pos = [y_outside]
            if -y > y_pos[-1]:
                y_pos.append(-y)
                x_indexes.append(1)
            if y0 > y_pos[-1]:
                y_pos.append(y0)
                x_indexes.append(1)
                m_indexes.append(outside_mat)
            # no test as x changes, but keeps growing
            y_pos.append(max(y0, y_pos[-1]))
            x_indexes.append(0)
            m_indexes.append(outside_mat)
            if y > y_pos[-1]:
                y_pos.append(y)
                x_indexes.append(0)
                m_indexes.append(inside_mat)
            if y_inside >  y_pos[-1]:
                y_pos.append(y_inside)
                x_indexes.append(0)
                m_indexes.append(in_finish_mat)
            else:
                m_indexes[-1] = in_finish_mat

            return WindowPanel(
                False,     # closed
                x_indexes,     # x index
                [x1, x0],
                y_pos,
                m_indexes,     # material index
                side_cap_front=len(m_indexes),     # cap index
                side_cap_back=0
                )
        else:
            # Hole without overflow
            m_indexes = [out_finish_mat]
            y_pos = [y_outside]
            if -y > y_pos[-1]:
                y_pos.append(-y)
            if y0 > y_pos[-1]:
                y_pos.append(y0)
                m_indexes.append(outside_mat)
            if y > y_pos[-1]:
                y_pos.append(y)
                m_indexes.append(inside_mat)
            if y_inside > y_pos[-1]:
                y_pos.append(y_inside)
                m_indexes.append(in_finish_mat)
            else:
                m_indexes[-1] = in_finish_mat
            x_indexes = [0 for i in y_pos]

            return WindowPanel(
                False,     # closed
                x_indexes,     # x index
                [x0],
                y_pos,
                m_indexes,     # material index
                side_cap_front=len(m_indexes),     # cap index
                side_cap_back=0
                )

    @property
    def hole_center_y(self):
        """
        Hole center on y axis - this is the location of ground
        :return:
        """
        y = self._offset  # 0.5 * self.y - self.offset
        """
        if self.window_type == 'FLAT':
            y += self.frame_y
        else:
            y += max(self.frame_y, 2.05 * self.panel_y)
        """
        return y

    @property
    def inside_hole(self):
        # inside part of hole to setup line for floor
        # profil percement                          ____
        #   _____  y_inside          vertical ___|      x1
        #  |
        #  |__     y0                outside   ___
        #     |___ y_outside                       |____ x1-shape_z     inside
        # -x1 x0
        y0 = self.hole_center_y

        if self.frame_layout == 'EXTERIOR':
            y0 += self.frame_y

        x1 = -self._frame_x     # sur-largeur percement interieur

        y_inside = 0.5 * self.y + 0.01     # outside wall

        inside_mat = self.mat_hole_inside
        # if self.flip:
        #    outside_mat, inside_mat = inside_mat, outside_mat

        return WindowPanel(
            False,     # closed
            [0, 0],     # x index
            [x1],
            [y0, y_inside],
            [inside_mat, inside_mat],     # material index
            side_cap_front=1,     # cap index
            side_cap_back=0
            )

    @property
    def _offset(self):
        # this is the location of the frame outside
        if self.align_to == 'OUTSIDE':
            return -0.5 * self.y + self.offset
        elif self.align_to == 'INSIDE':
            return 0.5 * self.y - self._frame_y - self.offset
        elif self.align_to == 'AXIS':
            return -0.5 * self._frame_y - self.offset

    @property
    def frame(self):
        # profil cadre
        #     ___     y0  inside
        #  __|   |
        # |      |    y2
        # |______|    y1  outside
        # x1 x2  x0
        y2 = -0.5 * self.y
        y0 = self.hole_center_y
        y1 = y2 - self.out_frame_y2 - self.finishing_out
        x0 = 0.001   # -min(self.frame_x - 0.001, self.out_frame_offset)
        x1 = x0 - self.out_frame_x
        x2 = x0 - self.out_frame_y
        # y = depth
        # x = width
        mat = self.id_mat(MAT_OUT_FRAME)
        closed_path = self.out_frame_closed or bool(self.shape == 'CIRCLE')
        if self.out_frame_x <= self.out_frame_y:
            if self.out_frame_x == 0:
                pts_y = [y2, y0, y0, y2]
            else:
                pts_y = [y1, y0, y0, y1]

            return WindowPanel(
                True,     # closed profil
                [0, 0, 1, 1],     # x index
                [x2, x0],
                pts_y,
                [mat] * 4,     # material index
                closed_path=closed_path  # closed path
                )
        else:
            return WindowPanel(
                True,     # closed profil
                [0, 0, 1, 1, 2, 2],     # x index
                [x1, x2, x0],
                [y1, y2, y2, y0, y0, y1],
                [mat] * 6,     # material index
                closed_path=closed_path   # closed path
                )

    @property
    def out_tablet(self):
        # profil tablette
        #  __  y0
        # |  | y2
        # | / y3
        # |_| y1
        # x0 x2 x1
        y0 = self.hole_center_y
        y1 = -0.5 * self.y - self.out_tablet_y - self.finishing_out
        y2 = y0 - 0.2 * self.out_tablet_spoiler_width
        y3 = y0 - self.out_tablet_spoiler_width

        if self.frame_layout == "EXTERIOR":
            x2 = self.out_tablet_z - self._frame_x
        else:
            x2 = 0.001

        x0 = x2 - self.out_tablet_z
        x1 = x2 + self.out_tablet_spoiler_height

        ms, mp = self.id_mat(MAT_SILL_OUT), self.id_mat(MAT_SPOILER)

        if y3 < y1 or not self.out_tablet_spoiler:
            # no space available for spoiler
            return WindowPanel(
                True,  # closed profil
                [1, 1, 0, 0],  # x index
                [x0, x2],
                [y1, y0, y0, y1],
                [ms, ms, ms, ms],  # material index
                closed_path=False  # closed path
            )
        else:
            return WindowPanel(
                True,  # closed profil
                [1, 1, 2, 2, 0, 0],  # x index
                [x0, x2, x1],
                [y1, y3, y2, y0, y0, y1],
                [ms, mp, mp, ms, ms, ms],  # material index
                closed_path=False  # closed path
            )
        # y = depth
        # x = width1

    @property
    def in_tablet(self):
        # profil tablette
        #  __  y0  inside
        # |  |
        # |  |
        # |__| y1 outside
        # x0  x1  top
        y0 = self.hole_center_y + self._frame_y + self.finishing_int
        y1 = 0.5 * self.y + self.in_tablet_y
        if self.window_type == 'RAIL':
            y0 = self._offset + max(self._frame_y, 2.05 * self.panel_y)

        if self.frame_layout == "INTERIOR":
            x1 = self.in_tablet_z - self._frame_x
            # XXX limit fails with window_type USER_FRAME
        else:
            x1 = 0.001

        x0 = x1 - self.in_tablet_z

        mat = self.id_mat(MAT_SILL_IN)
        return WindowPanel(
            True,     # closed profil
            [0, 0, 1, 1],     # x index
            [x0, x1],
            [y1, y0, y0, y1],
            [mat] * 4,     # material index
            closed_path=False           # closed path
            )

    @property
    def curtain_tablet(self):
        # profil tablette
        #  __  y0
        # |  |
        # |  |
        # |__| y1
        # x0  x1
        y0 = 0.5 * self.y
        y1 = y0 + self.curtain_sill_y

        x0 = self.altitude + self.z + self.curtain_sill_alt + min(self._frame_overflow, self._frame_x)
        x1 = x0 + self.curtain_sill_z
        # y = depth
        # x = width1
        mat = self.id_mat(MAT_SILL_CURTAIN)
        return WindowPanel(
            True,  # closed profil
            [0, 0, 1, 1],  # x index
            [x0, x1],
            [y1, y0, y0, y1],
            [mat] * 4,  # material index
            closed_path=False  # closed path
        )

    @property
    def curtain_rod(self):
        # profil rod
        #  __  y0
        # |  |
        # |  |
        # |__| y1
        # x0  x1
        y0 = 0.5 * self.y
        yc = y0 + self.curtain_rod_y
        xc = self.altitude + self.z + self.curtain_rod_alt + min(self._frame_overflow, self._frame_x)
        r = self.curtain_rod_radius
        da = 2 * pi / self.curve_steps
        mat = self.id_mat(MAT_ROD_CURTAIN)
        rod = WindowPanel(
            True,  # closed profil
            [i for i in range(self.curve_steps)],  # x index
            [xc + r * sin(a * da) for a in range(self.curve_steps)],
            [yc + r * cos(a * da) for a in range(self.curve_steps)],
            [mat] * self.curve_steps,  # material index
            closed_path=False  # closed path
        )
        side = WindowPanel(
            False,
            [0, 0],
            [r],
            [y0, yc],
            [mat],
            closed_path=True
        )
        return rod, side

    @property
    def vertical_space(self):
        """
            avaliable space for hinges
        """
        center, origin, size, radius = self.get_radius(self._x, self._z)
        offset = Vector((0, self.altitude - self._overflow, 0))
        left, right = self.window.avaliable_vertical_space(self.curve_steps, offset, center, origin,
            size, radius, self.angle_y, 0, shape_z=None, path_type=self.shape)
        return left, right

    def find_blind(self, o, inside):
        for child in o.children:
            if child.type == 'MESH' and 'archipack_blind' in child.data:
                loc = o.matrix_world.inverted() @ child.matrix_world.translation
                if inside:
                    if loc.y > 0:
                        return child
                elif loc.y < 0:
                    return child
        return None

    def update_blind(self, context, o, inside):

        x = self.x
        z = self.z
        a = self.altitude

        blind = self.find_blind(o, inside)

        if inside:
            enabled = self.blind_inside
            overflow = 2 * self._frame_overflow
            style = 'VENITIAN'
            # half width + handle
            y = 0.02 + 0.08
        else:
            enabled = self.blind_outside
            overflow = 0
            style = 'SLAT'
            y = -0.5 * (self.y - self.offset)
            if self.frame_layout == 'EXTERIOR':
                x += 2 * min(self._frame_x, self._frame_overflow)
                z += min(self._frame_x, self._frame_overflow)

        if enabled:
            x += overflow
            z += overflow
            a -= 0.5 * overflow
            if inside:
                tM = Matrix([
                    [-1, 0, 0, 0],
                    [0, -1, 0, 0.5 * self.y],
                    [0, 0, 1, 0],
                    [0, 0, 0, 1]
                ])
            else:
                tM = Matrix([
                    [1, 0, 0, 0],
                    [0, 1, 0, -0.5 * self.y],
                    [0, 0, 1, 0],
                    [0, 0, 0, 1]
                ])
            if blind is None:

                # print("create blind")
                # should only occur in interactive mode, but we do not care anymore as create is context less
                # print("########################  BLIND ################")
                bpy.ops.archipack.blind(
                    'INVOKE_DEFAULT',
                    x=x,
                    z=z,
                    offset_y=y,
                    altitude=a,
                    frame_enable=inside,
                    frame_depth=2 * y,
                    frame_height=0.04,
                    style=style,
                    randomize=True,
                    parent=o.name,
                    tM=tM.col[0][:] + tM.col[1][:] + tM.col[2][:] + tM.col[3][:]
                    )

            else:

                d = blind.data.archipack_blind[0]
                blind.matrix_world = o.matrix_world @ tM
                bend = len(self.bend) > 0
                if (d.x != x or
                        d.z != z or
                        d.offset_y != y or
                        d.altitude != a or
                        bend):
                        # should occur in update operator
                        d.x = x
                        d.z = z
                        d.offset_y = y
                        d.altitude = a
                        with context_override(context, blind, [blind]) as ctx:
                            d.update(ctx, bend=bend)

        else:
            self.delete_object(context, blind)

    def find_portal(self, o):

        for child in o.children:
            if child.type == 'LIGHT':
                return child
        return None

    def update_portal(self, context, o):

        lamp = self.find_portal(o)
        if self.portal:
            if lamp is None:
                d = bpy.data.lights.new(name="Portal", type='AREA')
                lamp = bpy.data.objects.new("Portal", d)
                self.link_object_to_scene(context, lamp, layer_name="Lights")
                lamp.parent = o

            d = lamp.data
            d.shape = 'RECTANGLE'
            d.size = self.x
            d.size_y = self.z

            # eevee
            d.energy = self.portal_energy
            d.use_contact_shadow = True
            # cycles
            if hasattr(d, "cycles"):
                d.cycles.is_portal = True

            tM = Matrix([
                [1, 0, 0, 0],
                [0, 0, -1, -0.5 * self.y],
                [0, 1, 0, 0.5 * self.z + self.altitude],
                [0, 0, 0, 1]
            ])
            lamp.matrix_world = o.matrix_world @ tM

        else:
            self.delete_object(context, lamp)

    def get_generator(self, o=None, typ="WINDOW"):
        return OpeningGenerator(self, o, typ)

    def setup_manipulators(self):
        n_manips = len(self.manipulators)
        if n_manips < 1:
            s = self.manipulators.add()
            s.prop1_name = "x"
            s.prop2_name = "x"
        else:
            s = self.manipulators[0]
        if self.has_user_defined_object:
            s.type_key = "DUMB_SIZE"
        else:
            s.type_key = "SNAP_SIZE_LOC"

        if n_manips < 2:
            s = self.manipulators.add()
            s.prop1_name = "y"
            s.prop2_name = "y"
        else:
            s = self.manipulators[1]
        if self.has_user_defined_object:
            s.type_key = "DUMB_SIZE"
        else:
            s.type_key = "SNAP_SIZE_LOC"

        if n_manips < 3:
            s = self.manipulators.add()
            s.prop1_name = "z"
            s.normal = Vector((0, 1, 0))
        else:
            s = self.manipulators[2]

        if self.has_user_defined_object:
            s.type_key = "DUMB_SIZE"
        else:
            s.type_key = "SIZE"

        if n_manips < 4:
            s = self.manipulators.add()
            s.prop1_name = "altitude"
            s.normal = Vector((0, 1, 0))

    def remove_childs(self, context, o, to_remove):
        for child in o.children:
            if to_remove < 1:
                return
            if archipack_window_panel.filter(child):
                to_remove -= 1
                self.delete_object(context, child)

    def remove_shutters(self, context, childs, to_remove):
        for child in childs:
            if to_remove < 1:
                return
            to_remove -= 1
            self.delete_object(context, child)

    def update_rows(self, context, o):
        n_rows = 1
        w_child = 2
        if self.shape == 'CIRCLE':
            w_child = 1
        elif self.shape != 'RAIL':
            n_rows = self.n_rows

        # remove rows
        for i in range(len(self.rows2), n_rows, -1):
            self.rows2.remove(i - 1)

        # add rows
        for i in range(len(self.rows2), n_rows):
            self.rows2.add()
            for j in range(w_child):
                self.rows2[-1].add_col()

        def _filter(c):
            return not self.has_flag(c, 'hole') and 'archipack_blind' not in c.data

        return self.cleanup_members(context, o, _filter)

    def get_childs_shutters(self, context, o, left_side):
        if left_side:
            return [child for child in o.children
                if (archipack_window_shutter.filter(child) and
                    child.location.x < 0)
                ]
        else:
            return [child for child in o.children
                if (archipack_window_shutter.filter(child) and
                    child.location.x > 0)
                ]

    def adjust_size_for_rail(self, row, size, origin, pivot, materials):
        # rail window
        # delta panel -> glass    |1|2|3|   ||||
        less_large = (row.n_cols + 1) * self.panel_x / row.n_cols
        o = origin[0].x
        for i, s in enumerate(size):
            s.x += 2 * self.panel_x - less_large
            origin[i].x = o + 0.5 * size[i].x * (1 - pivot[i])
            o += s.x - self.panel_x

        out_depth = self.rail_frame_depth
        rail_depth = self.rail_depth
        # space not available for panels
        rails_depth = out_depth + 2 * rail_depth
        frame_y = max(self._frame_y, 2 * self.panel_y + rails_depth)
        # max panel depth
        panel_max = 0.5 * (frame_y - rails_depth)
        # delta frame rail axis / window axis

        for i, o in enumerate(origin):
            panel_y = min(panel_max, self.panel_y)

            if row.parts[i].fixed:
                panel_y *= 0.5
            frame_axis = - (0.5 * self._frame_y + panel_y) + out_depth + 0.5 * rail_depth + 0.5 * (frame_y - rails_depth)

            o.y = frame_axis + (1 - (i % 2)) * panel_y

        for i, o in enumerate(origin):
            materials[i] = (1 - (i % 2)) + 1
    
    def adjust_size_for_hung(self, n_rows, row_id, row, size, origin, offset, materials):
        # hung window
        out_depth = self.rail_frame_depth
        rail_depth = self.rail_depth
        # space not available for panels
        rails_depth = out_depth + 2 * rail_depth
        frame_y = max(self._frame_y, 2 * self.panel_y + rails_depth)
        # max panel depth
        panel_max = 0.5 * (frame_y - rails_depth)
        # delta frame rail axis / window axis

        # panel_y = min(self.panel_y, 0.5 * self._frame_y)
        if n_rows > 0:
            if row_id == 0 or row_id == n_rows:
                for i, s in enumerate(size):
                    delta = 0.5
                    if row.parts[i].fixed:
                        delta = 0.25
                        if row_id == n_rows:
                            origin[i].z = 0.25 * self.panel_x
                    s.y += delta * self.panel_x
            if 0 < row_id < n_rows:
                for i, s in enumerate(size):
                    delta = 0.5
                    if row.parts[i].fixed:
                        delta = 0
                        origin[i].z = 0.25 * self.panel_x
                    s.y += delta * self.panel_x

            if row_id > 0:
                offset.y -= 0.5 * self.panel_x

        for i, o in enumerate(origin):
            panel_y = min(panel_max, self.panel_y)
            if row.parts[i].fixed:
                panel_y *= 0.5
            frame_axis = -(0.5 * self._frame_y + panel_y) + out_depth + 0.5 * rail_depth + 0.5 * (frame_y - rails_depth)
            o.y = frame_axis + (1 - (row_id % 2)) * panel_y

        for i, o in enumerate(origin):
            materials[i] = (1 - (i % 2)) + 1

    def _synch_childs(self, context, o, linked, childs):
        """
            sub synch childs nodes of linked object
        """

        # remove childs not found on source

        members = self._members(linked)

        # add missing childs and update other ones
        for uid, panel in childs.items():
            if uid not in members:
                p = bpy.data.objects.new("Window Panel", panel.data)
                # Link object into scene
                self.link_object_to_scene(context, p)
                self.link_collections(linked, p)
                self.link_materials(context, o, p)
                p.color = (0, 1, 0, 1)
                p.show_transparent = True
                p.lock_location = (True, True, True)
                p.lock_scale = (True, True, True)
                p.parent = linked
                p.matrix_world = linked.matrix_world.copy()

                # m = p.archipack_material.add()
                # m.category = 'window'
                # m.material = o.archipack_material[0].material
            else:
                p = members[uid]
                self.link_materials(context, o, p)

            self.synch_locks(p)

            glass = self.find_one_by_flag(panel, 'glass')
            g = self.find_one_by_flag(p, 'glass')
            if self.separate_glass and self.enable_glass:
                if glass is not None:
                    if g is None:
                        g = bpy.data.objects.new("Window Glass", glass.data)
                        # Link object into scene
                        self.link_object_to_scene(context, g, layer_name="Openings")
                        self.link_collections(linked, g)
                        self.link_materials(context, o, g)
                        self.set_flag(g, 'glass', True)
                        g.color = (0, 1, 0, 1)
                        g.show_transparent = True
                        g.lock_location = (True, True, True)
                        g.lock_scale = (True, True, True)
                        g.parent = p
                        g.matrix_world = p.matrix_world.copy()
            elif g is not None:
                self.delete_object(context, g)

            # update handle
            handle, handle_outside = self.find_handle(panel)
            h, h_outside = self.find_handle(p)
            if handle is not None:
                if h is None:
                    h = self.duplicate_object(context, handle, linked=True)
                    self.link_collections(linked, h)
                    h.parent = p
                    h.matrix_world = p.matrix_world.copy()

                h.location = handle.location.copy()
            else:
                self.delete_object(context, h)

            if handle_outside is not None:
                if h_outside is None:
                    h_outside = self.duplicate_object(context, handle_outside, linked=True)
                    self.link_collections(linked, h_outside)
                    h_outside.parent = p
                    h_outside.matrix_world = p.matrix_world.copy()

                h_outside.location = handle_outside.location.copy()
            else:
                self.delete_object(context, h_outside)

            p.location = panel.location.copy()

        # restore context
        # self.select_object(context, o, True)

    def _synch_shutters(self, context, o, linked, left_side):
        """
            sub synch childs nodes of linked object
        """
        childs = self.get_childs_shutters(context, o, left_side)
        # remove childs not found on source
        l_childs = self.get_childs_shutters(context, linked, left_side)
        c_names = [c.data.name for c in childs]
        for c in l_childs:
            try:
                id = c_names.index(c.data.name)
            except:
                self.delete_object(context, c)

        # children ordering may not be the same, so get the right l_childs order
        l_childs = self.get_childs_shutters(context, linked, left_side)
        l_names = [c.data.name for c in l_childs]
        order = []
        for c in childs:
            try:
                id = l_names.index(c.data.name)
            except:
                id = -1
            order.append(id)

        # add missing childs and update other ones
        for i, child in enumerate(childs):
            if order[i] < 0:
                p = bpy.data.objects.new("Shutter", child.data)
                # Link object into scene
                self.link_object_to_scene(context, p)
                self.link_collections(o, p)
                p.color = (0, 1, 0, 1)
                p.lock_location[1] = True
                p.lock_location[2] = True
                p.lock_rotation[1] = True
                p.lock_scale = (True, True, True)
                p.parent = linked
                p.matrix_world = linked.matrix_world.copy()
                # m = p.archipack_material.add()
                # m.category = 'window'
                # m.material = o.archipack_material[0].material
            else:
                p = l_childs[order[i]]

            self.link_materials(context, o, p)
            p.location = child.location.copy()
            p.rotation_euler = child.rotation_euler.copy()

        # select and make active
        # self.select_object(context, o, True)
        
    def _synch_hole(self, context, linked, hole):
        l_hole = self.find_hole(linked)
        if hole is None:
            if l_hole is not None:
                # user defined hole
                self.delete_object(context, l_hole)
        elif l_hole is None:
            l_hole = bpy.data.objects.new("hole", hole.data)
            l_hole['archipack_hole'] = True
            # Link object into scene
            self.link_object_to_scene(context, l_hole)
            self.link_collections(linked, l_hole)
            l_hole.parent = linked
            l_hole.matrix_world = linked.matrix_world.copy()
            l_hole.location = hole.location.copy()
            self.safe_scale(hole)
            ArchipackBoolManager.prepare_hole(context, l_hole)
            self.hide_for_render_engines(l_hole)
        else:
            l_hole.data = hole.data

    def synch_locks(self, p):
        s = self.window_type != 'FLAT'
        g = self.window_type != 'HUNG'
        r = self.window_type != 'RAIL'
        p.lock_location = (r, True, g)
        p.lock_rotation = (s, True, s)

    def synch_childs(self, context, o):
        """
            synch childs nodes of linked objects
        """
        # bpy.ops.object.select_all(action='DESELECT')
        # select and make active
        # self.select_object(context, o, True)
        childs = self._members(o)

        hole = self.find_hole(o)
        linked_objects = self.get_linked_objects(context, o)
        # bpy.ops.object.select_linked(type='OBDATA')
        for linked in linked_objects:
            if linked != o:
                ld = archipack_window.datablock(linked)
                ld.update_portal(context, linked)
                ld.update_blind(context, linked, True)
                ld.update_blind(context, linked, False)
                self._synch_childs(context, o, linked, childs)
                self._synch_shutters(context, o, linked, True)
                self._synch_shutters(context, o, linked, False)
                self._synch_hole(context, linked, hole)

    def get_shutter_row(self, x, y, left_side):
        n_shutters = self.shutter_left + self.shutter_right
        size = Vector((x / n_shutters, y, 0))
        origin = []
        ttl = 0
        xh = x / 2
        # offset pivot
        if left_side:
            n_shutters = self.shutter_left
            ttl -= size.x
        else:
            ttl += self.shutter_left * size.x
            n_shutters = self.shutter_right

        for i in range(n_shutters):
            ttl += size.x
            origin.append(Vector((ttl - xh, 0)))
        return size, origin

    def update_shutter(self, context, o, left_side, hinge_space):
        # wanted childs
        if self.shutter_enable:
            if left_side:
                side = 0
                pivot = 1
                n_shutters = self.shutter_left
            else:
                pivot = -1
                n_shutters = self.shutter_right
                side = n_shutters - 1

        else:
            n_shutters = 0

        # real childs
        childs = self.get_childs_shutters(context, o, left_side)
        n_childs = len(childs)

        # remove child
        if n_childs > n_shutters:
            self.remove_shutters(context, childs, n_childs - n_shutters)

        if not self.shutter_enable or n_shutters == 0:
            return

        childs = self.get_childs_shutters(context, o, left_side)
        n_childs = len(childs)

        location_y = -0.5 * self.y - 0.25 * self.shutter_depth - self.finishing_out
        if self.out_frame:
            location_y -= self.out_frame_y2

        x = self.x
        z = self.z
        altitude = 0

        if self.frame_layout == 'EXTERIOR':
            altitude = max(0, self._frame_x - self.out_tablet_z + self.out_tablet_altitude)
            x += 2 * min(self._frame_x, self._frame_overflow)
            z += min(self._frame_x, self._frame_overflow) + altitude

        center, origin, size, radius = self.get_radius(x, z)
        offset = Vector((0.05, 0))
        size, origin = self.get_shutter_row(x, z, left_side)

        if hinge_space > 1.5:
            hinge_count = 3
        else:
            hinge_count = 2

        for panel in range(n_shutters):

            if panel >= n_childs:
                child, m = self.create_mesh("Shutter")

                d = m.archipack_window_shutter.add()

                # Link object into scene
                self.link_object_to_scene(context, child)
                self.link_collections(o, child)
                child.color = (0, 1, 0, 1)
                child.lock_location = (False, True, True)
                child.lock_rotation = (False, True, False)
                child.lock_scale = (True, True, True)

                # parenting at 0, 0, 0 before set object matrix_world
                # so location remains local from frame
                child.parent = o
                child.matrix_world = o.matrix_world.copy()
                child.rotation_euler.z = pi
                self.safe_scale(child)
            else:
                child = childs[panel]
                # select and make active
                # self.select_object(context, child, True)
                d = archipack_window_shutter.datablock(child)

            if d is not None:
                self.link_materials(context, o, child)
                d.update(context,
                         child,
                         self,
                         Vector((origin[panel].x, offset.y, 0)),
                         center,
                         radius,
                         size,
                         pivot,
                         pivot * offset.x,
                         panel == side,
                         hinge_count,
                         hinge_space
                         )

            child.location = Vector((
                origin[panel].x - pivot * offset.x + (side - panel) * size.x,
                origin[panel].y + location_y + (side - panel) * pivot * 0.5 * self.shutter_depth,
                self.altitude + offset.y - altitude
                ))

    def update_childs(self, context, o):
        """
            pass params to childrens
            :o: blender object
        """
        members = self.update_rows(context, o)
        row_n = 0

        if self.window_type in {'FLAT', 'USER_PANEL'}:
            overflow = LEAF_OVERFLOW
        else:
            overflow = 0.5

        if self.open_outside:
            location_y = self._offset + overflow * self._frame_y - self.panel_y
            handle_y = self.panel_y
        else:
            location_y = self._offset + (1 - overflow) * self._frame_y  + self.panel_y
            handle_y = 0

        center, origin, size, radius = self.get_radius(self._x, self._z)
        offset = Vector((0, 0))

        auto_handle_sides = 0
        if self.shape != 'CIRCLE':
            auto_handle_sides = {
                'NONE': 0,
                'INSIDE': 1,
                'OUTSIDE': 2,
                'BOTH': 3
            }[self.handle_side]
            is_circle = False
        else:
            is_circle = True

        for row in self.rows2:
            handle_num = 0

            row_n += 1
            if row_n < self.n_rows and not is_circle and self.window_type != 'RAIL':
                z = row.height
                shape = 'RECTANGLE'
            else:
                z = max(2 * self.frame_x + 0.001, self._z - offset.y)
                shape = self.shape

            warning = bool(z > self._z - offset.y)
            if warning:
                break

            size, origin, pivot = row.get_row(self._x, z)

            # side materials

            materials = [0 for i in range(row.cols + 1)]

            handle_altitude = min(
                max(self.panel_x, self.handle_altitude + self._overflow - self.altitude),
                z - self.panel_x
                )

            if self.window_type == 'RAIL':
                self.adjust_size_for_rail(row, size, origin, pivot, materials)
                
            elif self.window_type == 'HUNG':
                self.adjust_size_for_hung(self.n_rows - 1, row_n - 1, row, size, origin, offset, materials)
            
            for i, panel in enumerate(row.parts):

                handle_sides = auto_handle_sides
                handle_type = "NONE"

                if not panel.fixed:
                    handle_num += 1
                    if panel.handle_side != "AUTO":
                        handle_type = self.handle_type
                        handle_sides = {
                            'NONE': 0,
                            'INSIDE': 1,
                            'OUTSIDE': 2,
                            'BOTH': 3
                        }[panel.handle_side]
                    elif handle_num < 2:
                        handle_type = self.handle_type

                if panel.part_uid not in members:

                    child, m = self.create_mesh("Window Panel")
                    d = m.archipack_window_panel.add()
                    d.part_uid = panel.part_uid
                    # Link object into scene
                    self.link_object_to_scene(context, child)
                    self.link_collections(o, child)
                    # select and make active
                    # self.select_object(context, child, True)
                    child.color = (0, 1, 0, 1)

                    child.show_transparent = True
                    child.lock_location = (False, True, True)
                    child.lock_rotation = (False, True, False)
                    child.lock_scale = (True, True, True)
                    # parenting at 0, 0, 0 before set object matrix_world
                    # so location remains local from frame
                    child.parent = o
                    child.matrix_world = o.matrix_world.copy()

                else:
                    child = members[panel.part_uid]

                    d = archipack_window_panel.datablock(child)

                if d is not None:

                    self.link_materials(context, o, child)

                    d.update(context,
                        child,
                        self,
                        Vector((origin[i].x, offset.y, 0)),
                        center,
                        radius,
                        size[i],
                        pivot[i],
                        shape,
                        panel.fixed,
                        materials[i]
                    )


                    if self.window_type == "RAIL":
                        # the handle is located on the other side for rail window
                        handle_location = (pivot[i] * (0.6 * self.panel_x), handle_y, handle_altitude)
                    elif self.window_type == "FLAT":
                        handle_location = (pivot[i] * (size[i].x - 0.4 * self.panel_x), handle_y, handle_altitude)
                    elif self.window_type == "HUNG":
                        handle_location = (pivot[i] * (0.5 * size[i].x), handle_y, 0.4 * self.panel_x)
                    else:
                        # Custom window, should never reach this point
                        handle_location = Vector()

                    self.update_handle(
                        context, child, handle_type, handle_location, self.id_mat(MAT_HANDLE),
                        sides=handle_sides, y=self.panel_y
                    )

                # location y + frame width. frame depends on choosen profile (fixed or not)
                # update linked childs location too
                child.location = Vector((
                    origin[i].x,
                    origin[i].y + location_y,
                    origin[i].z + self.altitude - self._overflow + offset.y))

                self.synch_locks(child)

                # only one single panel allowed for circle
                if is_circle:
                    return

            # only one single row allowed for rail window
            if self.window_type == 'RAIL':
                return
            offset.y += row.height

    @property
    def _frame_overflow(self):
        if self.frame_layout == 'TUNNEL':
            return 0
        return self.frame_overflow

    @property
    def _frame_y(self):
        if self.window_type == 'USER_FRAME':
            # use source y as frame_y
            # if self.has_user_defined_custom:
            #    return self.user_defined_object.data.archipack_custom[0].y_cur
            # el
            if self.has_user_defined_object:
                return self.user_defined_object.dimensions.y

        if self.window_type in {'RAIL', 'HUNG'}:
            return max(self.frame_y, 2 * self.panel_y + self.rail_frame_depth + 2 * self.rail_depth)

        return self.frame_y

    @property
    def _frame_x(self):
        if (self.window_type == 'USER_FRAME' and self.has_user_defined_custom) or \
           (self.window_type in {'USER_FRAME', 'USER'} and self.has_user_defined_object):
            return 0
        return self.frame_x

    @property
    def _overflow(self):
        # if self.window_type == "USER_FRAME" and self.has_user_defined_custom:
        #    return self._frame_overflow
        return min(0, self._frame_overflow - self._frame_x)

    @property
    def _x(self):
        if self.window_type == "USER_FRAME" and self.has_user_defined_object:
            return self.user_defined_object.dimensions.x
        return self.x + 2 * self._overflow

    @property
    def _z(self):
        if self.window_type == "USER_FRAME" and self.has_user_defined_object:
            return self.user_defined_object.dimensions.z
        return self.z + 2 * self._overflow

    def _get_tri_radius(self, _x, _z):
        return Vector((0, self.y, 0)), Vector((0, 0, 0)), \
            Vector((_x, _z, 0)), Vector((_x, 0, 0))

    def _get_quad_radius(self, _x, _z):
        fx_z = _z / _x
        center_y = min(_x / (_x - self.frame_x) * _z - self.frame_x * (1 + sqrt(1 + fx_z * fx_z)),
            abs(tan(self.angle_y) * _x))
        if self.angle_y < 0:
            center_x = 0.5 * _x
        else:
            center_x = -0.5 * _x
        return Vector((center_x, center_y, 0)), Vector((0, 0, 0)), \
            Vector((_x, _z, 0)), Vector((_x, 0, 0))

    def _get_round_radius(self, _x, _z):
        """
            bound radius to available space
            return center, origin, size, radius
        """
        x = 0.5 * _x - self.frame_x
        # minimum space available
        y = _z - sum([row.height for row in self.rows[:self.n_rows - 1]]) - 2 * self.frame_x
        y = min(y, x)
        # minimum radius inside
        r = y + x * (x - (y * y / x)) / (2 * y)
        radius = max(self.radius, 0.001 + self.frame_x + r)
        return Vector((0, _z - radius, 0)), Vector((0, 0, 0)), \
            Vector((_x, _z, 0)), Vector((radius, 0, 0))

    def _get_circle_radius(self, _x, _z):
        """
            return center, origin, size, radius
        """
        return Vector((0, 0.5 * _x, 0)), Vector((0, 0, 0)), \
            Vector((_x, _z, 0)), Vector((0.5 * _x, 0, 0))

    def _get_ellipsis_radius(self, _x, _z):
        """
            return center, origin, size, radius
        """
        y = self.z - sum([row.height for row in self.rows[:self.n_rows - 1]])
        radius_b = max(0, 0.001 - 2 * self.frame_x + min(y, self.elipsis_b))
        return Vector((0, _z - radius_b, 0)), Vector((0, 0, 0)), \
            Vector((_x, _z, 0)), Vector((_x / 2, radius_b, 0))

    def get_radius(self, _x, _z):
        """
            return center, origin, size, radius
        """
        if self.shape == 'ROUND':
            return self._get_round_radius(_x, _z)
        elif self.shape == 'ELLIPSIS':
            return self._get_ellipsis_radius(_x, _z)
        elif self.shape == 'CIRCLE':
            return self._get_circle_radius(_x, _z)
        elif self.shape == 'QUADRI':
            return self._get_quad_radius(_x, _z)
        elif self.shape in ['TRIANGLE', 'PENTAGON']:
            return self._get_tri_radius(_x, _z)
        else:
            return Vector((0, 0, 0)), Vector((0, 0, 0)), \
                Vector((_x, _z, 0)), Vector((0, 0, 0))

    def find_hole(self, o):
        return self.find_one_by_flag(o, ('hole', "custom_hole"))

    def upgrade(self):
        # upgrade from older data models
        old = tuple(self.version)
        if old < (2, 4, 0):
            # version change occurs after preset loading so does apply to presets !
            self.version[:] = (2, 4, 0)
            self.migrate_to_24()
            print("upgrade from ", old)

    def migrate_to_24(self):
        # Handle data model change from < 2.4
        if self.rows:
            self.auto_update = False
            # TODO: migrate other params too
            self.align_to = 'INSIDE'
            self.offset -= self.frame_y
            handle_side = "AUTO"
            if self.window_type == "HUNG":
                handle_side = "NONE"
            # Migrate rows
            for i in range(self.n_rows):
                row2 = self.rows2.add()
                row = self.rows[i]
                row2.n_cols = row.n_cols
                row2.height = row.height
                for i in range(row.cols):
                    c = row2.add_col()
                    c.fixed = row.fixed[i]
                    c.width = row.width[i]
                    c.handle_side = handle_side
            self.rows.clear()

            self.auto_update = True


    def update(self, context, childs_only=False):
        # NOTE: childs_only is disabled as it does not work with bend

        # support for "copy to selected"
        o = self.find_in_selection(context, self.auto_update)

        if o is None:
            return

        t = time.time()
        # logger.debug("window.update is_updating:%s" % (self.is_updating))
        bm = None

        self.upgrade()

        if self.manipulable_refresh:
            # update manipulators to handle type change for customs (dumb vs active)
            self.manipulable_disable(o)

        self.setup_manipulators()

        is_user_object = (
            'USER' in self.window_type and
            self.has_user_defined_object
        )
        is_custom = (
            'USER' in self.window_type and
            self.has_user_defined_custom
        )
        is_user_window = is_user_object and self.window_type == 'USER'
        is_user_frame = is_user_object and  self.window_type == 'USER_FRAME'
        is_custom_window = is_custom and self.window_type == 'USER'
        is_custom_panel = is_custom and self.window_type == 'USER_PANEL'
        is_custom_frame = is_custom and self.window_type == 'USER_FRAME'

        # is the custom / user part of regular window, using generator
        is_custom_part = is_user_frame or is_custom_frame or is_custom_panel
        is_regular_window = not (is_custom or is_user_object)

        if is_custom:
            if is_custom_panel:
                # use source y as frame_y, x and z, use overflow
                members = self.update_rows(context, o)
                altitude = self.altitude - self._overflow
                tz = 0

                if self.open_outside:
                    location_y = self._offset + LEAF_OVERFLOW * self._frame_y - self.panel_y
                else:
                    location_y = self._offset + (1 - LEAF_OVERFLOW) * self._frame_y + self.panel_y

                for j, row in enumerate(self.rows2):
                    size, origin, pivot = row.get_row(self._x, row.height)
                    if tz + row.height > self._z or j + 1 == self.n_rows:
                        z = self._z - tz
                    else:
                        z = row.height
                    tz += row.height
                    if z <= 0:
                        for i, panel in enumerate(row.parts):
                            if panel.part_uid in members:
                                self.delete_object(context, members[panel.part_uid])
                        break

                    for i, panel in enumerate(row.parts):
                        override = {'x': size[i].x, 'y': self.panel_y, 'z': z, 'altitude': 0}
                        translate = Vector((0.5 * size[i].x, -0.5 * self._frame_y, 0))
                        if panel.part_uid not in members:
                            dst, me = self.create_mesh("Panel")
                            p = me.archipack_window_panel.add()
                            p.part_uid = panel.part_uid
                            dst.parent = o
                            self.link_object_to_scene(context, dst, layer_name="Openings")
                            dst.matrix_world = o.matrix_world.copy()
                            members[panel.part_uid] = dst
                        else:
                            dst = members[panel.part_uid]

                        self.custom_datablock_update(
                            context, self.user_defined_object, dst, translate, override
                        )

                        dst.location = Vector((
                            origin[i].x,
                            origin[i].y + location_y,
                            altitude
                        ))

                        self.set_flag(dst.data, "nested_custom", True)
                        self.set_flag(dst, "custom_door", False)
                        # as we reset mesh every time, must also reset mirror state
                        self.set_flag(dst.data, "mirror", False)
                        self._mirror_custom_object(dst, pivot[i] < 0)
                    altitude += row.height

            # Provide support for "align"
            elif is_custom_frame:
                # use source y as frame_y, x and z, use overflow
                _overflow = 2 * self._frame_overflow
                override =  {'x': self._x + _overflow, 'y': self._frame_y, 'z':self._z + _overflow}
                # translate = Vector((0, self._offset + 0.5 * self._frame_y, -self._overflow))
                translate = Vector((0, self._offset + 0.5 * self._frame_y, -self._frame_overflow))

                self.custom_datablock_update(
                    context, self.user_defined_object, o, translate, override
                )
            else:
                translate = Vector()
                override = None
                self.custom_datablock_update(
                    context, self.user_defined_object, o, translate, override
                )

        elif is_user_object:

            if is_user_frame:
                translate = Vector((0, self._offset + (1 - LEAF_OVERFLOW) * self._frame_y, self.altitude))

            elif is_user_window:
                translate = Vector((0, 0, self.altitude))

            bm = self.custom_geometry_update(
                context, self.user_defined_object, o, translate, linked=len(self.bend) == 0
            )

        if not (is_custom_frame or is_user_frame or is_custom_window or is_user_window):
            self.remove_custom_childs(context, o)

        elif is_custom_panel:
            members = self._members(o)
            for uid, c in members.items():
                self.delete_object(context, c)

        # default to generator when there is no valid source
        if (is_custom_part or is_regular_window):

            # native update
            # if childs_only is False:
            # Frame
            center, origin, size, radius = self.get_radius(self._x, self._z)
            is_not_circle = self.shape != 'CIRCLE'
            offset = Vector((0, self.altitude - self._overflow, 0))
            col = self.random_color

            if is_user_frame or is_custom_frame:
                # Use frame
                verts, faces, mat, uvs, vcolors, vgroups = [], [], [], [], [], {}

            else:
                window = self.window
                verts = window.vertices(self.curve_steps, offset, center, origin, size, radius,
                                        self.angle_y, 0, shape_z=None, path_type=self.shape)
                logger.debug("window.update verts %.4f" % (time.time() - t))
                faces = window.faces(self.curve_steps, path_type=self.shape)

                logger.debug("window.update faces %.4f" % (time.time() - t))
                mat = window.mat(self.curve_steps, 0, 0, path_type=self.shape)
                logger.debug("window.update mat %.4f" % (time.time() - t))
                uvs = window.uv(self.curve_steps, center, origin, size, radius,
                                     self.angle_y, 0, 0, self.frame_x, path_type=self.shape)
                logger.debug("window.update uvs %.4f" % (time.time() - t))

                vcolors = window.vcolors(self.curve_steps, col, path_type=self.shape)

                vgroups = window.vgroups(self.curve_steps, 0, path_type=self.shape)

                logger.debug("window.update vcolors %.4f" % (time.time() - t))

            if self.out_frame:

                altitude = 0
                if is_not_circle:

                    if self.frame_layout == "EXTERIOR":
                        altitude =  self.out_tablet_altitude + self.out_tablet_z - self._frame_x
                    else:
                        altitude = self.out_tablet_altitude

                frame = self.frame
                _size = Vector((self.x, self.z - altitude, 0))
                _offset = Vector((0, self.altitude + altitude, 0))
                _center = Vector((center.x, center.y - self._overflow, center.z))
                if self.out_frame_closed and self.out_tablet_enable:
                    _size.y += self.out_tablet_z
                    _offset.y -= self.out_tablet_z

                if self.shape == 'ELLIPSIS':
                    _radius = Vector((
                        radius.x - self._overflow,
                        radius.y - self._overflow,
                        0))

                elif self.shape == 'QUADRI':
                    _radius = Vector((self.x, 0, 0))

                    if self.angle_y < 0:
                        _center.x = 0.5 * self.x
                    else:
                        _center.x = -0.5 * self.x
                    fx_z = self.z / self.x
                    _center.y = min(
                        self.x / (self.x - self._frame_x) * self.z - self._frame_x * (1 + sqrt(1 + fx_z * fx_z)),
                        abs(tan(self.angle_y) * self.x)
                    )
                else:
                    _radius = Vector((radius.x - self._overflow, 0, 0))

                faces.extend(
                    frame.faces(self.curve_steps, path_type=self.shape, offset=len(verts))
                )
                verts.extend(
                    frame.vertices(self.curve_steps, _offset, _center, origin, _size, _radius,
                                   self.angle_y, 0, shape_z=None, path_type=self.shape)
                )
                mat.extend(
                    frame.mat(self.curve_steps, 0, 0, path_type=self.shape)
                )
                uvs.extend(
                    frame.uv(self.curve_steps, _center, origin, _size, _radius,
                                  self.angle_y, 0, 0, self._frame_x, path_type=self.shape)
                )
                vcolors.extend(
                    frame.vcolors(self.curve_steps, col, path_type=self.shape)
                )
            if is_not_circle:

                if self.out_tablet_enable:

                    if self.frame_layout == "INTERIOR":
                        _offset = Vector((0, self.altitude - self._overflow + self.out_tablet_altitude, 0))
                        size_x = size.x + 2 * (self._frame_x + self.out_tablet_x)
                    else:
                        _offset = Vector((0, self.altitude + self.out_tablet_altitude, 0))
                        size_x = self.x + 2 * self.out_tablet_x
                    _size = Vector((
                        size_x,
                        size.y,
                        size.z))
                    tablet = self.out_tablet
                    faces.extend(tablet.faces(self.curve_steps, path_type='HORIZONTAL', offset=len(verts)))
                    verts.extend(
                        tablet.vertices(self.curve_steps, _offset, center, origin, _size, radius,
                                        self.angle_y, 0, shape_z=None, path_type='HORIZONTAL')
                    )
                    mat.extend(tablet.mat(self.curve_steps, 0, 0, path_type='HORIZONTAL'))
                    uvs.extend(
                        tablet.uv(self.curve_steps, center, origin, _size, radius,
                                  self.angle_y, 0, 0, self._frame_x, path_type='HORIZONTAL')
                    )
                    vcolors.extend(tablet.vcolors(self.curve_steps, col, path_type='HORIZONTAL'))
                if self.in_tablet_enable:
                    if self.frame_layout == "INTERIOR":
                        offset = Vector((0, self.altitude - self._overflow + self.in_tablet_altitude, 0))
                        size_x = size.x + 2 * (self._frame_x + self.in_tablet_x)
                    else:
                        offset = Vector((0, self.altitude + self.in_tablet_altitude, 0))
                        size_x = self.x + 2 * self.in_tablet_x
                    tablet = self.in_tablet
                    _size = Vector((
                        size_x,
                        size.y,
                        size.z))
                    faces.extend(
                        tablet.faces(self.curve_steps, path_type='HORIZONTAL', offset=len(verts))
                    )
                    verts.extend(
                        tablet.vertices(self.curve_steps, offset, center, origin, _size, radius,
                                        self.angle_y, 0, shape_z=None, path_type='HORIZONTAL')
                    )
                    mat.extend(
                        tablet.mat(self.curve_steps, 0, 0, path_type='HORIZONTAL')
                    )
                    uvs.extend(
                        tablet.uv(self.curve_steps, center, origin, _size, radius,
                                  self.angle_y, 0, 0, self._frame_x, path_type='HORIZONTAL')
                    )
                    vcolors.extend(
                        tablet.vcolors(self.curve_steps, col, path_type='HORIZONTAL')
                    )

            if self.curtain_sill_enable:
                col = self.random_color
                tablet = self.curtain_tablet
                _offset = Vector((offset.x, 0, 0))
                _size = Vector((size.x + 2 * (self.curtain_sill_x + self._frame_x),
                                size.y,
                                size.z))
                faces.extend(
                    tablet.faces(self.curve_steps, path_type='HORIZONTAL', offset=len(verts))
                )
                verts.extend(
                    tablet.vertices(self.curve_steps, _offset, center, origin, _size, radius,
                                    self.angle_y, 0, shape_z=None, path_type='HORIZONTAL')
                )
                mat.extend(
                    tablet.mat(self.curve_steps, 0, 0, path_type='HORIZONTAL')
                )
                uvs.extend(
                    tablet.uv(self.curve_steps, center, origin, _size, radius,
                              self.angle_y, 0, 0, self._frame_x, path_type='HORIZONTAL')
                )
                vcolors.extend(
                    tablet.vcolors(self.curve_steps, col, path_type='HORIZONTAL')
                )

            if self.curtain_rod_enable:
                col = self.random_color
                rod, side = self.curtain_rod
                _size = Vector((size.x + 2 * (self.curtain_rod_x + self._frame_x),
                                size.y,
                                size.z))
                _offset = Vector((offset.x, 0, 0))
                faces.extend(
                    rod.faces(self.curve_steps, path_type='HORIZONTAL', offset=len(verts))
                )
                verts.extend(
                    rod.vertices(self.curve_steps, _offset, center, origin, _size, radius,
                                    self.angle_y, 0, shape_z=None, path_type='HORIZONTAL')
                )

                mat.extend(
                    rod.mat(self.curve_steps, 0, 0, path_type='HORIZONTAL')
                )
                uvs.extend(
                    rod.uv(self.curve_steps, center, origin, _size, radius,
                              self.angle_y, 0, 0, self._frame_x, path_type='HORIZONTAL')
                )
                vcolors.extend(
                    rod.vcolors(self.curve_steps, col, path_type='HORIZONTAL')
                )
                _size = Vector((self.x, self.z, 0))
                # lefts
                z = self.altitude + self.z + self.curtain_rod_alt + min(self._frame_x, self._frame_overflow)
                _radius = Vector((0, 0, 0))
                _center = _radius
                _offset = Vector((-0.5 * self.x, z, 0))
                faces.extend(
                    side.faces(self.curve_steps, path_type='CIRCLE', offset=len(verts))
                )
                verts.extend(
                    side.vertices(self.curve_steps, _offset, _center, origin, _size, _radius,
                                 self.angle_y, 0, shape_z=None, path_type='CIRCLE')
                )
                mat.extend(
                    side.mat(self.curve_steps, 0, 0, path_type='CIRCLE')
                )
                uvs.extend(
                    side.uv(self.curve_steps, _center, origin, _size, _radius,
                           self.angle_y, 0, 0, self._frame_x, path_type='CIRCLE')
                )
                vcolors.extend(
                    side.vcolors(self.curve_steps, col, path_type='CIRCLE')
                )
                # right
                _offset = Vector((0.5 * self.x, z, 0))
                faces.extend(
                    side.faces(self.curve_steps, path_type='CIRCLE', offset=len(verts))
                )
                verts.extend(
                    side.vertices(self.curve_steps, _offset, _center, origin, _size, _radius,
                                  self.angle_y, 0, shape_z=None, path_type='CIRCLE')
                )
                mat.extend(
                    side.mat(self.curve_steps, 0, 0, path_type='CIRCLE')
                )
                uvs.extend(
                    side.uv(self.curve_steps, _center, origin, _size, _radius,
                            self.angle_y, 0, 0, self._frame_x, path_type='CIRCLE')
                )
                vcolors.extend(
                    side.vcolors(self.curve_steps, col, path_type='CIRCLE')
                )
            logger.debug("window.update frame %.4f" % (time.time() - t))

            # return a bmesh to join for either merged geom or USER_FRAME
            bm = bmed.buildmesh(
                o, verts, faces, mat, uvs,
                vcolors=vcolors, temporary=is_user_frame or is_custom_frame
            )

            if is_user_frame or is_custom_frame:
                bmed.bmesh_join(o, [bm])

            bmed.set_vertex_groups(o, vgroups)

            logger.debug("window.update buildmesh %.4f" % (time.time() - t))

            self.shade_smooth(context, o, 0.20944)

            logger.debug("window.update 0 %.4f" % (time.time() - t))


            self.update_blind(context, o, True)
            self.update_blind(context, o, False)

            if is_regular_window:
                # update panels
                self.update_childs(context, o)

            logger.debug("window.update 1 %.4f" % (time.time() - t))

            left, right = self.vertical_space
            self.update_shutter(context, o, True, left)
            self.update_shutter(context, o, False, right)

        self.update_portal(context, o)

        # update hole
        # if childs_only is False:
        self.interactive_hole(context, o)

        logger.debug("window.update 2 %.4f" % (time.time() - t))

        if len(self.bend) > 0:
            sel =[]
            def _filter(c):
                return c.type == "MESH" and "archipack_blind" not in c.data
            self.rec_get_childrens(o, sel, _filter)
            self.bend_mesh(o, sel)

        # store 3d points for gl manipulators
        x, y = 0.5 * self.x, 0.5 * self.y
        self.manipulators[0].set_pts([(-x, -y, 0), (x, -y, 0), (0.5, 0, 0)])
        self.manipulators[1].set_pts([(-x, -y, 0), (-x, y, 0), (-1, 0, 0)])
        self.manipulators[2].set_pts([(x, -y, self.altitude), (x, -y, self.altitude + self.z), (-1, 0, 0)])
        self.manipulators[3].set_pts([(x, -y, 0), (x, -y, self.altitude), (-1, 0, 0)])

        # soft_segment_2d for dimension points
        p0, p1 = Vector((-x, -y, 0)), Vector((x, -y, 0))
        p2, p3 = Vector((-0.5 * self._x - self._frame_x, y, 0)), Vector((0.5 * self._x + self._frame_x, y, 0))
        coords = [p0, p1, p2, p3]

        if len(self.bend) > 0:
            self.bend_coords(coords, add_section=False)

        self.add_dimension_point(0, coords[0])
        self.add_dimension_point(1, coords[1])
        self.add_dimension_point(2, coords[2])
        self.add_dimension_point(3, coords[3])
        
        # support for instances childs, update at object level
        if is_regular_window:
            self.synch_childs(context, o)

        if self.has_flag(o, 'standalone'):
            self.snap(o, 2 * self.y)

        logger.debug("window.update 3 %.4f" % (time.time() - t))

        # synch dimensions when apply
        if o.parent:
            self.update_dimensions(context, o)

        logger.debug("window.update end %.4f" % (time.time() - t))
        # restore context
        self.restore_context(context)
        logger.debug("window.restore_context %.4f" % (time.time() - t))

    def update_auto_hole(self, context):
        """ Handle automatic_hole state changes
        :param context:
        :return:
        """
        o = self.find_in_selection(context, True)
        if o is None:
            return
        linked_objects = self.get_linked_objects(context, o)
        for linked in linked_objects:
            hole_obj = self.find_hole(linked)
            if hole_obj is not None:
                manager = ArchipackBoolManager()
                manager.automatic_hole(context, linked, hole_obj, self.automatic_hole)

        self.restore_context(context)

    def interactive_hole(self, context, o):
        if not self.automatic_hole:
            return None

        if self.has_flag(o, "standalone"):
            # standalone windows do not require hole at all
            return None

        hole_obj = self.find_hole(o)

        if self.user_defined_hole is None and (self.has_user_defined_object or self.has_user_defined_custom):
            # use hole copy found with user_defined object
            return hole_obj

        # Create hole_obj when not found
        if hole_obj is None:
            hole_obj, m = self.create_mesh("hole")
            # Link object into scene
            self.set_flag(hole_obj, 'hole', True)
            self.set_flag(hole_obj, 'skip_material', True)
            self.link_object_to_scene(context, hole_obj)
            hole_obj.parent = o
            hole_obj.matrix_world = o.matrix_world.copy()

            self.safe_scale(hole_obj)

            # ArchipackBoolManager.prepare_hole(context, hole_obj)
            self.hide_for_render_engines(hole_obj)
            Callbacks.call("create", context, hole_obj, None)

        # Use custom hole mesh as source
        if self.user_defined_hole is not None:
            vcolors = None
            transform = Matrix.Translation(Vector((0, 0, self.altitude)))
            verts, faces, uvs, matids = \
                bmed.mesh_data_from_obj(self.user_defined_hole, transform=transform)

        else:

            hole = self.hole

            center, origin, size, radius = self.get_radius(self._x, self._z)
            x0 = 0

            if self.out_frame:
                x0 += min(self._frame_x + 0.001, self.out_frame_y + self.out_frame_offset)

            if self.out_tablet_enable:
                x0 -= self.out_tablet_z - self.out_tablet_altitude

            x0 = min(x0, -0.001)

            shape_z = [-0.001, x0]

            verts = hole.vertices(self.curve_steps,
                Vector((0, self.altitude - self._overflow, 0)),
                center, origin, size, radius,
                self.angle_y, 0, shape_z=shape_z, path_type=self.shape)

            faces = hole.faces(self.curve_steps, path_type=self.shape)

            matids = hole.mat(self.curve_steps, 2, 2, path_type=self.shape)

            uvs = hole.uv(self.curve_steps, center, origin, size, radius,
                self.angle_y, 0, 0, self._frame_x, path_type=self.shape)
            col = self.random_color
            vcolors = hole.vcolors(self.curve_steps, col, path_type=self.shape)

        bmed.buildmesh(hole_obj, verts, faces, matids, uvs, vcolors=vcolors)

        Callbacks.call("update", context, hole_obj, None)
        return hole_obj

    def get_snap_generator(self, tM):
        return self.get_generator(tM, typ="SNAP_WINDOW")

    def _add_spline(self, curve, coords):
        spline = curve.splines.new('POLY')
        spline.use_endpoint_u = False
        spline.use_cyclic_u = coords[-1] == coords[0]
        if coords[-1] == coords[0]:
            coords.pop()
        spline.points.add(len(coords) - 1)
        for i, coord in enumerate(coords):
            x, y, z = coord
            spline.points[i].co = (x, y, z, 1)

    def _to_curve(self, context, coords, name: str, dimensions: str='3D'):
        curve = bpy.data.curves.new(name, type='CURVE')
        curve.dimensions = dimensions
        for co in coords:
            self._add_spline(curve, co)
        curve_obj = bpy.data.objects.new(name, curve)
        # Link object into scene
        self.link_object_to_scene(context, curve_obj)
        # select and make active
        self.select_object(context, curve_obj, True)
        return curve_obj

    def merge_geometry(self, o):
        def _filter(c):
            return not self.has_flag(c, ("hole", "custom_hole")) and "archipack_blind" not in c.data

        bm = bmed.bmesh_from_obj(
            o, hierarchy=True, filter_hierarchy=_filter
        )
        # offset model so pivot is located to window's axis along wall
        # bmed.translate(bm, Vector((0, 0.5 * self.y, 0)))
        me = bpy.data.meshes.new("%s-simple" % o.data.name)
        bm.to_mesh(me)
        bm.free()
        return me

    def ifc_representation(self, context, o, representation_id="FootPrint"):

        if representation_id == "Annotation":
            curve = self.as_2d(context, o)
            curve.matrix_world = Matrix()
            return curve

        elif representation_id == "FootPrint":
            coords = self.hole_2d(mode="BOUND")
            curve = self._to_curve(context, [coords], name="{}-footprint".format(o.name), dimensions='2D')
            curve.matrix_world = Matrix()
            return curve

        elif representation_id == "Body":
            return self.merge_geometry(o)

        return None

    def as_2d(self, context, o):
        """ provide 2d symbol
        :param context:
        :param o:
        :return:
        """
        
        self.upgrade()
        
        members = self._members(o)

        if len(members) == 0:
            with context_override(context, o, [o]) as ctx:
                self.update(ctx)
            members = self._members(o)
        
        # frame
        center, origin, size, radius = self.get_radius(self._x, self._z)
        offset = Vector((0, 0, 0))

        # draw borders
        connect = 2
        if self.window_type == 'RAIL':
            connect = 3

        coords = self.window.as_2d(self.curve_steps, offset, center, origin,
            size, radius, 0, 0, connect=connect)

        # panels
        if self.open_outside:
            location_y = self._offset + LEAF_OVERFLOW * self._frame_y - self.panel_y
        else:
            location_y = self._offset + (1 - LEAF_OVERFLOW) * self._frame_y + self.panel_y

        row = self.rows2[0]
        size, origin, pivot = row.get_row(self._x, row.height)

        materials = [0 for i in range(row.cols + 1)]

        if self.window_type == 'RAIL':
            self.adjust_size_for_rail(row, size, origin, pivot, materials)

        elif self.window_type == 'HUNG':
            self.adjust_size_for_hung(1, 0, row, size, origin, offset, materials)
        
        for i, panel in enumerate(row.parts):
            if panel.part_uid not in members:
                break
            child = members[panel.part_uid]
            
            # location y + frame width. frame depends on choosen profile (fixed or not)
            # update linked childs location too
            d = child.data.archipack_window_panel[0]
            if self.shape == 'CIRCLE':
                s = 2
            else: 
                s = 1

            location = Vector((
                origin[i].x,
                origin[i].y + location_y,
                0))

            window = d.window(self, panel.fixed, materials[i])
            coords.extend(
                window.as_2d(
                    self.curve_steps, location, center, Vector((origin[i].x, offset.y, 0)),
                    s * size[i], radius, 0, pivot[i], path_type='RECTANGLE')
                )
            # arc
            if self.window_type == 'FLAT' and not panel.fixed:
                x, y = location.x, location.y
                r = s * size[i].x

                direction = 1
                if self.open_outside:
                    direction = -1

                steps = 8
                # 30 deg
                da = pi / (6 * steps)
                arc = [Vector((
                        x + pivot[i] * r * cos(da * j),
                        y + direction * r * sin(da * j),
                        0))
                    for j in range(steps + 1)]
                arc.append(location)
                coords.append(arc)

        # 1 make a mesh based geometry with edges only
        # 2 bend
        # 3 get coords from mesh
        # C.object.data.archipack_window[0].as_2d(C, C.object)
        # self.bend_2d(context, o, coords)
        if len(self.bend) > 0:
            coords = [[Vector(co) for co in coord] for coord in coords]
            for coord in coords:
                self.bend_coords(coord, add_section=True)

        curve = self._to_curve(context, coords, name="{}-2d".format(o.name), dimensions='2D')
        curve.matrix_world = o.matrix_world.copy()
        return curve

    def hole_2d(self, mode='PLAN_2D'):
        """
          return coords of full / inside hole in 2d top ortho view
        """
        if mode == 'BOUND':
            x, y = 0.5 * self._x + self._frame_x, 0.5 * self.y + 0.01
            coords = [(-x, -y, 0), (-x, y, 0), (x, y, 0), (x, -y, 0), (-x, -y, 0)]

        else:
            center, origin, size, radius = self.get_radius(self._x, self._z)

            if mode in {'FLOORS', 'FLOORS_CHILD'}  :
                coords = self.inside_hole.as_2d(self.curve_steps,
                    Vector((0, 0, 0)),
                    center, origin, size, radius,
                    0, 0, shape_z=None, path_type=self.shape)
            else:
                coords = self.hole.as_2d(self.curve_steps,
                    Vector((0, 0, 0)),
                    center, origin, size, radius,
                    0, 0, shape_z=None, path_type=self.shape)
            coords = coords[0]

        coords = [Vector(co) for co in coords]

        if len(self.bend) > 0:
            self.bend_coords(coords, add_section=True)

        # Use only first curve
        return coords

    def remove_hole(self, context, hole, walls):
        ctx = context.copy()
        ctx['object'] = hole
        ctx['selected_objects'] = walls
        bpy.ops.archipack.remove_hole(ctx)

    def on_delete(self, context, obj):

        # print("window.on_delete")
        walls = set()
        wall2 = {}
        sel = context.selected_objects
        # collect walls
        ref = self.get_reference_point(obj)
        if ref is not None:
            walls = [
                c for c in ref.children
                 if (c.data and (
                    "archipack_wall2" in c.data or
                    "archipack_wall" in c.data
                    )
                    or self.has_flag(c, "custom_wall")
                )]
            wall2 = {
                c: c.data.archipack_wall2[0]
                for c in ref.children
                if c.data and "archipack_wall2" in c.data
            }

        for o in sel:
            if self.filter(o):
                hole = self.find_hole(o)
                if hole is not None:
                    self.remove_hole(context, hole, walls)

                if o.name != obj.name:
                    self.delete_object(context, o)

        for c, d in wall2.items():
            # update providers
            d.setup_childs(context, c, openings_only=True)
            for i, child in enumerate(d.childs):
                if child.child_name == obj.name:
                    d.childs.remove(i)
                    break
            d.synch_dimension(context, c, remove_object=obj.name)

        ArchipackObject.on_delete(self, context, obj)

    @property
    def user_defined_objects(self):
        return [
                self.user_defined_object,
                self.user_defined_handle,
                self.user_defined_handle_outside,
                self.user_defined_hole
        ]


class ARCHIPACK_PT_window(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_window"
    bl_label = "Window"

    @classmethod
    def poll(cls, context):
        return archipack_window.filter(context.active_object)

    def draw(self, context):
        o = context.active_object
        d = archipack_window.datablock(o)
        if d is None:
            return
        layout = self.layout
        global icons

        self.draw_common(context, layout)

        row = layout.row(align=True)
        self.draw_op(context, layout, row, 'archipack.window', icon='FILE_REFRESH', text="Refresh").mode = 'REFRESH'
        if o.data.users > 1:
            self.draw_op(context, layout, row, 'archipack.window', icon='UNLINKED',
                         text="Make unique", postfix="({})".format(o.data.users)).mode = 'UNIQUE'
        # self.draw_op(context, layout, row, 'archipack.window', text="Delete", icon='ERROR').mode = 'DELETE'
        self.draw_op(context, layout, layout, "archipack.window_array", icon='MOD_ARRAY', text="Array")

        box = layout.box()
        # self.draw_label(context, layout, box, "Styles")
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.window_preset_menu",
                     text=bpy.types.ARCHIPACK_OT_window_preset_menu.bl_label, icon="PRESET"
                     ).preset_operator = "archipack.preset_loader"
        self.draw_op(context, layout, row, "archipack.window_preset", icon='ADD', text="")
        self.draw_op(context, layout, row, "archipack.window_preset", icon='REMOVE', text="").remove_active = True

        self.draw_prop(context, layout, layout, d, 'tabs', expand=True)

        box = layout.box()

        if d.tabs == 'MAIN':
            self.draw_prop(context, layout, box, d, 'window_type')
            if d.window_type == 'FLAT':
                self.draw_prop(context, layout, box, d, 'open')
            self.draw_prop(context, layout, box, d, 'x')
            self.draw_prop(context, layout, box, d, 'y')
            if d.window_shape != 'CIRCLE':
                self.draw_prop(context, layout, box, d, 'z')
                if d.warning:
                    self.draw_label(context, layout, box, "Insufficient height")
            self.draw_prop(context, layout, box, d, 'altitude')
            self.draw_prop(context, layout, box, d, 'align_to')
            self.draw_prop(context, layout, box, d, 'offset')
            self.draw_prop(context, layout, box, d, 'frame_layout')
            if d.frame_layout != 'TUNNEL':
                self.draw_prop(context, layout, box, d, 'frame_overflow')

            # self.draw_prop(context, layout, box, d, 'standalone')

            if 'USER' in d.window_type:
                self.draw_label(context, layout, box, "Custom geometry")
                self.draw_prop(context, layout, box, d, 'user_defined_object')
                self.draw_prop(context, layout, box, d, 'user_defined_hole')

            if d.window_type == 'FLAT':
                box = layout.box()
                self.draw_prop(context, layout, box, d, 'window_shape')
                if d.window_shape in ['ROUND', 'CIRCLE', 'ELLIPSIS']:
                    self.draw_prop(context, layout, box, d, 'curve_steps')
                if d.window_shape in ['ROUND']:
                    self.draw_prop(context, layout, box, d, 'radius')
                elif d.window_shape == 'ELLIPSIS':
                    self.draw_prop(context, layout, box, d, 'elipsis_b')
                elif d.window_shape == 'QUADRI':
                    self.draw_prop(context, layout, box, d, 'angle_y')

            box = layout.box()
            self.draw_prop(context, layout, box, d, 'automatic_hole', icon="BLANK1", emboss=True)

            if d.automatic_hole:
                self.draw_prop(context, layout, box, d, "hole_margin")
            box = layout.box()
            self.draw_op(context, layout, box, 'archipack.window_surface_deform', icon="MOD_MESHDEFORM", text="Deform")

        elif d.tabs == 'SUB':

            if d.window_type == 'USER':
                return

            icon = "TRIA_RIGHT"
            if d.frame_expand:
                icon = "TRIA_DOWN"
            self.draw_prop(context, layout, box, d, 'frame_expand', icon=icon)
            if d.frame_expand:
                self.draw_prop(context, layout, box, d, 'frame_x')
                self.draw_prop(context, layout, box, d, 'frame_y')


            box = layout.box()
            icon = "TRIA_RIGHT"
            if d.panel_expand:
                icon = "TRIA_DOWN"
            self.draw_prop(context, layout, box, d, 'panel_expand', icon=icon)
            if d.panel_expand:
                self.draw_prop(context, layout, box, d, 'panel_x')
                self.draw_prop(context, layout, box, d, 'panel_y')

            box = layout.box()
            row = box.row(align=True)
            icon = "TRIA_RIGHT"
            if d.out_frame_expand:
                icon = "TRIA_DOWN"
            self.draw_prop(context, layout, row, d, 'out_frame_expand', icon=icon)
            self.draw_prop(context, layout, row, d, 'out_frame', text="Enable")
            if d.out_frame_expand:
                self.draw_prop(context, layout, box, d, 'out_frame_x')
                self.draw_prop(context, layout, box, d, 'out_frame_y2')
                self.draw_prop(context, layout, box, d, 'out_frame_y')
                self.draw_prop(context, layout, box, d, 'out_frame_offset')
                self.draw_prop(context, layout, box, d, 'out_frame_closed')

            if d.window_shape != 'CIRCLE':

                box = layout.box()
                row = box.row(align=True)
                icon = "TRIA_RIGHT"
                if d.out_tablet_expand:
                    icon = "TRIA_DOWN"
                self.draw_prop(context, layout, row, d, 'out_tablet_expand', icon=icon)
                self.draw_prop(context, layout, row, d, 'out_tablet_enable', text="Enable")
                if d.out_tablet_expand:
                    self.draw_prop(context, layout, box, d, 'out_tablet_x')
                    self.draw_prop(context, layout, box, d, 'out_tablet_y')
                    self.draw_prop(context, layout, box, d, 'out_tablet_z')
                    self.draw_prop(context, layout, box, d, 'out_tablet_altitude')
                    self.draw_prop(context, layout, box, d, 'out_tablet_spoiler')
                    if d.out_tablet_spoiler:
                        self.draw_prop(context, layout, box, d, 'out_tablet_spoiler_height')
                        self.draw_prop(context, layout, box, d, 'out_tablet_spoiler_width')

                box = layout.box()
                row = box.row(align=True)
                icon = "TRIA_RIGHT"
                if d.in_tablet_expand:
                    icon = "TRIA_DOWN"
                self.draw_prop(context, layout, row, d, 'in_tablet_expand', icon=icon)
                self.draw_prop(context, layout, row, d, 'in_tablet_enable', text="Enable")
                if d.in_tablet_expand:
                    self.draw_prop(context, layout, box, d, 'in_tablet_x')
                    self.draw_prop(context, layout, box, d, 'in_tablet_y')
                    self.draw_prop(context, layout, box, d, 'in_tablet_z')
                    self.draw_prop(context, layout, box, d, 'in_tablet_altitude')

                box = layout.box()
                row = box.row(align=True)
                icon = "TRIA_RIGHT"
                if d.shutter_expand:
                    icon = "TRIA_DOWN"
                self.draw_prop(context, layout, row, d, 'shutter_expand', icon=icon)
                self.draw_prop(context, layout, row, d, 'shutter_enable', text="Enable")
                if d.shutter_expand:
                    self.draw_prop(context, layout, box, d, 'shutter_left')
                    self.draw_prop(context, layout, box, d, 'shutter_right')
                    self.draw_prop(context, layout, box, d, 'shutter_depth')
                    self.draw_prop(context, layout, box, d, 'shutter_border')
                    self.draw_prop(context, layout, box, d, 'shutter_hinge')

            box = layout.box()
            row = box.row(align=True)
            icon = "TRIA_RIGHT"
            if d.curtain_expand:
                icon = "TRIA_DOWN"
            self.draw_prop(context, layout, row, d, 'curtain_expand', icon=icon)
            if d.curtain_expand:
                self.draw_op(context, layout, box, "archipack.window_curtain")
                self.draw_prop(context, layout, box, d, 'curtain_sill_enable')
                if d.curtain_sill_enable:
                    self.draw_prop(context, layout, box, d, 'curtain_sill_x')
                    self.draw_prop(context, layout, box, d, 'curtain_sill_y')
                    self.draw_prop(context, layout, box, d, 'curtain_sill_z')
                    self.draw_prop(context, layout, box, d, 'curtain_sill_alt')
                self.draw_prop(context, layout, box, d, 'curtain_rod_enable')
                if d.curtain_rod_enable:
                    self.draw_prop(context, layout, box, d, 'curtain_rod_x')
                    self.draw_prop(context, layout, box, d, 'curtain_rod_y')
                    self.draw_prop(context, layout, box, d, 'curtain_rod_alt')
                    self.draw_prop(context, layout, box, d, 'curtain_rod_radius')

            if d.window_shape != 'CIRCLE':
                box = layout.box()
                self.draw_label(context, layout, box, text="Handle")
                self.draw_prop(context, layout, box, d, 'handle_side', text="")
                self.draw_prop(context, layout, box, d, 'handle_type', text="")
                self.draw_prop(context, layout, box, d, 'handle_altitude')
                if d.handle_type == "WINDOW_USER":
                    self.draw_prop(context, layout, box, d, 'user_defined_handle')
                    self.draw_prop(context, layout, box, d, 'user_defined_handle_outside')

                box = layout.box()
                self.draw_prop(context, layout, box, d, 'blind_inside', icon_value=icons["blind"].icon_id)
                self.draw_prop(context, layout, box, d, 'blind_outside', icon_value=icons["blind"].icon_id)

            box = layout.box()
            self.draw_prop(context, layout, box, d, 'enable_glass')
            self.draw_prop(context, layout, box, d, 'separate_glass')
            self.draw_prop(context, layout, box, d, 'glass_thickness')
            self.draw_prop(context, layout, box, d, 'glass_offset')

            box = layout.box()
            self.draw_prop(context, layout, box, d, 'portal', icon="LIGHT_AREA", emboss=True)
            self.draw_prop(context, layout, box, d, 'portal_energy')

        elif d.tabs == 'PARTS':

            if d.window_type == 'USER':
                return

            if d.window_shape != 'CIRCLE':
                row = box.row(align=False)

                if d.window_type != 'RAIL':
                    self.draw_prop(context, layout, row, d, 'n_rows')

                if d.window_type != 'RAIL':
                    last_row = d.n_rows - 1
                    for i, d_row in enumerate(d.rows):
                        box = layout.box()
                        self.draw_label(context, layout, box, "Row", postfix=str(i + 1))
                        d_row.draw(context, layout, box, i == last_row)
                    for i, d_row in enumerate(d.rows2):
                        box = layout.box()
                        self.draw_label(context, layout, box, "Row", postfix=str(i + 1))
                        d_row.draw(context, layout, box, i == last_row)

                else:
                    if d.rows:
                        d.rows[0].draw(context, layout, box, True)
                    else:
                        d.rows2[0].draw(context, layout, box, True)
            else:
                self.draw_label(context, layout, box, "Option not available")

        elif d.tabs == 'MATERIALS':

            if "archipack_material" in o:
                o.archipack_material[0].draw(context, box)

            box = layout.box()
            self.draw_label(context, layout, box, "Apply materials")
            self.draw_prop(context, layout, box, d, 'mat_frame_inside')
            self.draw_prop(context, layout, box, d, 'mat_frame_outside')
            self.draw_prop(context, layout, box, d, 'mat_out_frame')
            self.draw_prop(context, layout, box, d, 'mat_sill_in')
            self.draw_prop(context, layout, box, d, 'mat_sill_out')
            self.draw_prop(context, layout, box, d, 'mat_spoiler')
            self.draw_prop(context, layout, box, d, 'mat_handle')
            self.draw_prop(context, layout, box, d, 'mat_curtain_sill')
            self.draw_prop(context, layout, box, d, 'mat_curtain_rod')
            self.draw_prop(context, layout, box, d, 'mat_shutter')
            self.draw_prop(context, layout, box, d, 'mat_hinge')
            self.draw_prop(context, layout, box, d, 'mat_glass')
            self.draw_prop(context, layout, box, d, 'mat_glass_frame')
            self.draw_prop(context, layout, box, d, 'mat_joint')

            icon = "TRIA_RIGHT"
            if not d.auto_mat:
                icon = "TRIA_DOWN"
            self.draw_prop(context, layout, box, d, 'auto_mat', icon=icon, emboss=True, text="Hole material auto")
            if not d.auto_mat:
                self.draw_prop(context, layout, box, d, 'mat_hole_inside')
                self.draw_prop(context, layout, box, d, 'mat_hole_outside')
                self.draw_prop(context, layout, box, d, 'mat_finish_inside')
                self.draw_prop(context, layout, box, d, 'mat_finish_outside')


class ARCHIPACK_PT_window_panel(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_window_panel"
    bl_label = "Window leaf"

    @classmethod
    def poll(cls, context):
        return archipack_window_panel.filter(context.active_object)

    def draw(self, context):
        layout = self.layout
        self.draw_op(context, layout, layout, "archipack.select_parent", icon="RESTRICT_SELECT_OFF")


class ARCHIPACK_PT_window_shutter(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_window_shutter"
    bl_label = "Shutter"

    @classmethod
    def poll(cls, context):
        return archipack_window_shutter.filter(context.active_object)

    def draw(self, context):
        layout = self.layout
        self.draw_op(context, layout, layout, "archipack.select_parent", icon="RESTRICT_SELECT_OFF")


# ------------------------------------------------------------------
# Define operator class to create object
# ------------------------------------------------------------------


class ARCHIPACK_OT_window(ArchipackCreateTool, Operator):
    bl_idname = "archipack.window"
    bl_label = "Window"
    bl_description = "Window"

    x: FloatProperty(
        name='width',
        min=0.1, max=10000,
        default=2.0, precision=5,
        description='width'
    )
    y: FloatProperty(
        name='depth',
        min=0.001, max=10000,
        default=0.20, precision=5,
        description='Depth, basically the thickness of wall, you should keep as it'
    )
    z: FloatProperty(
        name='height',
        min=0.1, max=10000,
        default=1.2, precision=5,
        description='height'
    )
    altitude: FloatProperty(
        name='altitude',
        min=0.0, max=10000,
        default=1.0, precision=5,
        description='altitude'
    )
    mode: EnumProperty(
        items=(
            ('CREATE', 'Create', '', 0),
            ('REFRESH', 'Refresh', '', 2),
            ('UNIQUE', 'Make unique', '', 3),
        ),
        default='CREATE'
    )
    standalone: BoolProperty(default=True)

    def create(self, context):
        o, m = self.create_mesh("Window")
        d = m.archipack_window.add()
        d.x = self.x
        d.y = self.y
        d.z = self.z
        d.altitude = self.altitude
        # is standalone until boolean state otherwise, but draw tool may override in order to see hole at create time
        self.set_flag(o, "standalone", self.standalone)
        # Link object into scene
        self.link_object_to_scene(context, o)
        o.color = (0, 1, 0, 1)
        # select and make active
        self.select_object(context, o, True)
        self.add_material(context, o, material="DEFAULT", category="window")
        self.load_preset(context, o, d)
        # if not self.standalone:
        #    d.interactive_hole(context, o)
        return o

    def update(self, context):
        o = context.active_object
        d = archipack_window.datablock(o)
        if d is not None:
            d.update(context)
            linked_objects = self.get_linked_objects(context, o)
            # bpy.ops.object.select_linked(type='OBDATA')
            for linked in linked_objects:
                if linked != o:
                    archipack_window.datablock(linked).update(context)

        # bpy.ops.object.select_all(action="DESELECT")
        # select and make active
        # self.select_object(context, o, True)

    def unique(self, context):
        obj = context.active_object
        sel = context.selected_objects[:]
        uniques = []
        for o in sel:
            if archipack_window.filter(o):
                # select and make active
                Callbacks.call("unique", context, o, None)
                uniques.append(o)
                for child in o.children:
                    d = child.data
                    if self.has_flag(child, 'hole') or (
                            d is not None and (
                            'archipack_window_panel' in d or
                            'archipack_window_shutter' in d or
                            'archipack_dimension' in d
                            )):
                        uniques.append(child)
                        # select hole, handles, glass and dimension text
                        for c in child.children:
                            uniques.append(c)
        if bool(uniques):
            bpy.ops.archipack.disable_manipulate()
            with ensure_select_and_restore(context, uniques[0], uniques):
                bpy.ops.object.make_single_user(
                    type='SELECTED_OBJECTS', object=True, obdata=True, material=False, animation=False
                )
            self.select_object(context, obj, True)
    # -----------------------------------------------------
    # Execute
    # -----------------------------------------------------
    def execute(self, context):
        if context.mode == "OBJECT":
            if self.mode == 'CREATE':
                bpy.ops.object.select_all(action="DESELECT")
                o = self.create(context)
                o.location = self.get_cursor_location(context)
                # select and make active
                self.select_object(context, o, True)

            elif self.mode == 'REFRESH':
                self.update(context)
            elif self.mode == 'UNIQUE':
                self.unique(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_window_surface_deform(Operator, ArchipackCreateTool):
    bl_idname = "archipack.window_surface_deform"
    bl_label = "Surface deform"
    bl_description = "Create surface deform plane"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.object is not None and archipack_window.filter(context.object)

    def build_deform_plane(self, frame):
        me = bpy.data.meshes.new(name="plane")
        d = frame.data.archipack_window[0]
        w = 0.5 * d.x
        z = d.altitude
        h = z + d.z
        me.from_pydata([(-w, 0, z), (w, 0, z), (-w, 0, h), (w, 0, h)], [],[(0,1,3,2)])
        plane = bpy.data.objects.new("Deform plane", me)
        plane.matrix_world = frame.matrix_world.copy()
        frame.users_collection[0].objects.link(plane)
        self.hide_for_render_engines(plane)
        plane.display_type = 'BOUNDS'
        return plane

    def add_deform(self, obj, target):
        m = obj.modifiers.new("SurfaceDeform", 'SURFACE_DEFORM')
        m.target = target
        ctx = {}
        ctx['active_object'] = obj
        ctx['object'] = obj
        bpy.ops.object.surfacedeform_bind(ctx, modifier=m.name)
        for c in obj.children:
            self.add_deform(c, target)

    def execute(self, context):
        frame = context.active_object
        plane = self.build_deform_plane(frame)
        self.add_deform(frame, plane)
        self.select_object(context, plane, True)
        return {'FINISHED'}


class ARCHIPACK_OT_window_array(ArchipackArrayTool, Operator):
    bl_idname = "archipack.window_array"
    bl_label = "Window Array"
    bl_description = "Duplicate selected windows"
    bl_options = {'UNDO'}
    # XXX crash on redo when using spinner values ..
    # bl_options = {'REGISTER', 'UNDO'}

    def filter_object(self, o):
        return archipack_window.filter(o)

    def get_object_datablock(self, o):
        return archipack_window.datablock(o)


class ARCHIPACK_OT_window_draw(ArchipackDrawTool, Operator):
    bl_idname = "archipack.window_draw"
    bl_label = "Draw Windows"
    bl_description = "Draw Windows over walls"

    filepath: StringProperty(default="")

    feedback = None
    stack = []
    object_name = ""
    auto_manipulating = False

    @classmethod
    def poll(cls, context):
        return True

    def draw_callback(self, _self, context):
        # print("feedback.draw()")
        self.feedback.draw(context)

    def add_object(self, context, event):
        bpy.ops.object.select_all(action="DESELECT")

        o = context.scene.objects.get(self.object_name)

        if self.filepath == '' and archipack_window.filter(o):
            o = self.duplicate_object(context, o, False)
            self.select_object(context, o, True)

        else:
            bpy.ops.archipack.window(filepath=self.filepath, standalone=False)
            o = context.active_object

        if o is None:
            o = context.object

        self.object_name = o.name

        return o

    def remove_object(self, context, o):
        if archipack_window.filter(o):
            with context_override(context, o, [o]) as ctx:
                bpy.ops.archipack.delete(ctx)

    def exit(self, context, o):
        self.remove_object(context, o)
        self.feedback.disable()
        try:
            context.space_data.show_gizmo = True
        except:
            pass
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        self.restore_walls(context)

    def modal(self, context, event):

        o = self.get_scene_object(context, self.object_name)

        if o is None or context.area is None:
            self.exit(context, o)
            return {'FINISHED'}

        context.area.tag_redraw()

        d = archipack_window.datablock(o)

        to_hide = []
        self.rec_get_childrens(o, to_hide)

        for obj in to_hide:
            self.hide_object(obj)

        res, tM, wall, width, y, z_offset = self.mouse_hover_wall(context, event)

        for obj in to_hide:
            self.show_object(obj)
            
        if res and d is not None:
            o.matrix_world = tM.copy()
            if abs(d.y - width) > 0.001:
                self.select_object(context, o, True)
                d.y = width
                
        if event.value == 'PRESS':

            if event.type in {'C', 'D'}:
                self.exit(context, o)

                if event.alt:
                    bpy.ops.archipack.window_preset_menu('INVOKE_DEFAULT', preset_operator="archipack.window_draw")
                else:
                    bpy.ops.archipack.window_draw('INVOKE_DEFAULT', filepath=self.filepath)

                return {'FINISHED'}

            if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'}:
                if wall is not None:

                    # self.select_object(context, wall, True)
                    ctx = context.copy()
                    ctx['object'] = wall
                    ctx['selected_objects'] = [o]
                    bpy.ops.archipack.single_boolean(ctx)

                    # o must be a window here
                    if d is not None:
                        # do it first as bend depends on this
                        if "archipack_wall2" in wall.data:
                            # ensure windows always look outside
                            print("Draw tool -> update wall")
                            with ensure_select_and_restore(context, wall, [wall]):
                                wd = wall.data.archipack_wall2[0]
                                wg = wd.get_generator()
                                wd.setup_childs(context, wall, g=wg, openings_only=True)
                                wd.relocate_childs(context, wall, g=wg)
                                wd.update_dimension(context, wall, wg)
                        # Link if y does match
                        # with last stacked one
                        # unless shift pressed
                        if len(self.stack) > 0 and not event.shift:
                            last = self.stack[-1]
                            d_last = last.data.archipack_window[0]
                            if d_last.y == d.y and len(d_last.bend) == 0 and len(d.bend) == 0:
                                # Must disable manipulators before link !!
                                bpy.ops.archipack.disable_manipulate()
                                print("Draw tool -> link object")
                                self.link_object(last, o)

                        self.stack.append(o)
                        o = self.add_object(context, event)
                        o.matrix_world = tM
                        
                    return {'RUNNING_MODAL'}

            # prevent selection of other object
            if event.type in {'RIGHTMOUSE'}:
                return {'RUNNING_MODAL'}

        if self.keymap.check(event, self.keymap.undo) or (
                event.type in {'BACK_SPACE'} and event.value == 'RELEASE'
                ):
            if len(self.stack) > 0:
                last = self.stack.pop()
                self.remove_object(context, last)
            return {'RUNNING_MODAL'}

        if event.value == 'RELEASE':

            if event.type in {'ESC', 'RIGHTMOUSE'}:
                self.exit(context, o)
                return {'FINISHED'}

        return {'PASS_THROUGH'}

    def invoke(self, context, event):

        if context.mode == "OBJECT":
            o = context.active_object

            self.stack = []
            self.keymap = Keymaps(context)

            # exit manipulate_mode if any
            bpy.ops.archipack.disable_manipulate()
            # Hide manipulators
            context.space_data.show_gizmo = False

            # invoke with alt pressed will use current object as basis for linked copy
            if self.filepath == '' and archipack_window.filter(o):
                self.stack.append(o)
                o = self.duplicate_object(context, o, False)
                self.object_name = o.name

            else:
                o = self.add_object(context, event)

            # select and make active
            # bpy.ops.object.select_all(action="DESELECT")
            # self.select_object(context, o, True)
            
            self.feedback = FeedbackPanel()
            self.feedback.instructions(context, "Draw a window", "Click & Drag over a wall", [
                ('LEFTCLICK, RET, SPACE, ENTER', 'Create a window'),
                ('BACKSPACE, CTRL+Z', 'undo last'),
                ('D', 'Draw independant window with same preset'),
                ('ALT+D', 'Draw a window with another preset'),
                ('SHIFT', 'Make independant copy'),
                ('RIGHTCLICK or ESC', 'exit')
                ])
            self.feedback.enable()
            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_window_portals(Operator):
    bl_idname = "archipack.window_portals"
    bl_label = "Portals"
    bl_description = "Create portal for each window"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        for o in context.scene.objects:
            d = archipack_window.datablock(o)
            if d is not None:
                d.update_portal(context)

        return {'FINISHED'}


class archipack_window_curtain(ArchipackObject, PropertyGroup):

    def update(self, context, d, x, z,
               side="LEFT",
               random_y=0.02,
               open=1.0,
               self_distance_min=0.015):

        process_frames = d.process_frames
        end_frame = d.process_frames
        air_damping = 0.001

        o = self.get_context_value(context, "object")
        scene = self.get_context_value(context, "scene")
        actions = set([a.name for a in bpy.data.actions])

        frame_current = scene.frame_current
        n_attach = max(3, x / d.attach_spacing)
        rh = max(2, int(n_attach * d.resolution))
        rv = d.resolution_v  #max(5, int(rh / x * z))
        vg_spacing = max(1, int(rh / n_attach))
        dx = x / (rh - 2)
        dz = z / (rv - 1)
        # left
        if side == "LEFT":
            h0 = 0
        elif side == "RIGHT":
            h0 = -x
        else:
            h0 = -0.5 * x

        # Build a sinuzoid between attachs
        #    _
        #   / \
        #  |   |   |
        #       \_/
        #
        # steps 1 2
        # segs  4 8
        steps = (d.resolution - 1)
        da = pi / steps
        y = d.y
        dy = 0.1 * y
        verts = [
            Vector((h0 + h * dx, uniform(-dy, dy) + y * sin(da * h), z - v * dz))
            for v in range(rv) for h in range(rh)
        ]
        faces = [
            (j * rh + i,
              j * rh + i + 1,
              j * rh + i + rh + 1,
              j * rh + i + rh)
             for i in range(rh - 1)
             for j in range(rv - 1)
        ]
        du = x / rh
        dv = z / rv
        uvs = [[(i * du, j * dv),
                ((i + 1) * du, j * dv),
                ((i + 1) * du, (j + 1) * dv),
                (i * du , (j + 1) * dv)]
               for i in range(rh - 1)
               for j in range(rv - 1)]
        bmed.buildmesh(o, verts, faces, uvs=uvs)
        self.shade_smooth(context, o, pi)

        # Setup pin vertex group
        off = 0
        if (rh % vg_spacing) > 0.5 * vg_spacing:
            off = int(0.5 * vg_spacing)
        vgroup_top = [int(off + i) for i in range(0, rh, vg_spacing)]
        for v in o.data.vertices:
            v.select = v.index in vgroup_top
        vgroup = o.vertex_groups.get("Top")
        if vgroup is None:
            vgroup = o.vertex_groups.new(name="Top")
        vgroup.add(vgroup_top, 1, 'REPLACE')

        # Add shape keys
        basis = o.shape_key_add()
        basis.name = "Basis"
        o.data.update()
        sk = o.shape_key_add()
        sk.name = "Rescale"
        o.data.update()

        # Animate rescale shape key
        sk.keyframe_insert("value", frame=1)
        sk.value = 1.0
        sk.keyframe_insert("value", frame=end_frame)

        # Set closed vertex location to shape
        scale = n_attach * 1.0 * self_distance_min / x
        verts = o.data.shape_keys.key_blocks[sk.name].data
        for i in vgroup_top:
            px, py, pz = verts[i].co.to_3d()
            verts[i].co = Vector((px * scale, py * uniform(-random_y, random_y), pz))

        # Setup cloth modifier
        scene.frame_current = 1
        m = o.modifiers.new("Cloth", type="CLOTH")
        m.settings.mass = d.mass
        m.settings.air_damping = air_damping
        m.settings.vertex_group_mass = "Top"
        m.settings.tension_stiffness = 5
        m.settings.compression_stiffness = 5
        m.settings.shear_stiffness = 5
        m.settings.bending_stiffness = 0.05
        m.collision_settings.use_collision = False
        m.collision_settings.use_self_collision = True
        m.collision_settings.self_impulse_clamp = 0.1
        m.collision_settings.self_distance_min = self_distance_min
        m.collision_settings.vertex_group_self_collisions = "Top"

        # Process cloth
        for i in range(process_frames):
            scene.frame_set(i)

        self.modifier_apply(context, apply_as='SHAPE', modifier=m.name)

        # Remove rescale keyframes and shape key
        sk.keyframe_delete("value", frame=1)
        sk.keyframe_delete("value", frame=end_frame)
        o.active_shape_key_index = 1
        bpy.ops.object.shape_key_remove(context, all=False)

        # Set open value to Curtain shape key
        o.active_shape_key_index = 1
        o.active_shape_key.value = open

        # clean up actions
        to_remove = set([
            a.name for a in bpy.data.actions
            if a.name not in actions and a.users < 1])

        for a_name in to_remove:
            a = bpy.data.actions[a_name]
            bpy.data.actions.remove(a)

        # Clean up vertex group
        o.vertex_groups.remove(vgroup)

        # Corners crease
        bm = bmed._start(o)
        bmed.ensure_bmesh(bm)
        layer = bm.edges.layers.crease.verify()
        edges = [ed for v in bm.verts for ed in v.link_edges if len(v.link_edges) == 2]
        for ed in edges:
            ed[layer] = 1.0
        bmed._end(bm, o)

        m = o.modifiers.new("Subsurf", type="SUBSURF")
        m.levels = 2

        scene.frame_current = frame_current


class ARCHIPACK_PT_window_curtain(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_window_curtain"
    bl_label = "Curtain"

    @classmethod
    def poll(cls, context):
        return archipack_window_curtain.filter(context.active_object)

    def draw(self, context):
        o = context.active_object
        d = archipack_window_curtain.datablock(o)
        if d is None:
            return
        layout = self.layout

        self.draw_op(context, layout, layout, "archipack.delete", icon="TRASH")
        box = layout.box()

        if hasattr(o.data, 'shape_keys') and "Cloth" in o.data.shape_keys.key_blocks:
            layout.prop(o.data.shape_keys.key_blocks['Cloth'], "value", text="Open")

        if "archipack_material" in o:
            o.archipack_material[0].draw(context, box)


class ARCHIPACK_OT_window_curtain(Archipacki18n, ArchipackCreateTool, Operator):
    bl_idname = "archipack.window_curtain"
    bl_label = "Create curtains (very slow)"
    bl_description = "Create random pyhsical based curtain for each selected window, very slow (6 - 30+ sec / window)"
    y: FloatProperty(
        precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        name="Curtain Depth",
        description="Curtain depth when open",
        min=0,
        default=0.06
    )
    dy: FloatProperty(
        precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        name="Wall Distance",
        description="Offset from wall",
        min=0,
        default=0.15
    )
    x: FloatProperty(
        precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        name="Horizontal overflow",
        description="Horizontal overflow",
        min=0,
        default=0
    )
    z: FloatProperty(
        precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        name="Vertical overflow",
        description="Vertical overflow",
        min=0,
        default=0
    )
    z0: FloatProperty(
        precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        name="Bottom offset",
        description="Bottom offset from window frame",
        default=0
    )
    oversize: FloatProperty(
        precision=1, step=1,
        subtype='PERCENTAGE',
        name="Oversize",
        description="Oversize curtain so they are not flat when closed",
        min=0, max=100,
        default=30
    )

    open: FloatProperty(
        precision=1, step=1,
        subtype='PERCENTAGE',
        name="Open",
        description="Open percent",
        min=0, max=100,
        default=50
    )
    random_open: FloatProperty(
        precision=1, step=1,
        subtype='PERCENTAGE',
        name="Random open",
        description="Randomize open",
        min=0, max=100,
        default=50
    )
    attach_spacing: FloatProperty(
        precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        name="Attach spacing",
        description="Attach spacing",
        min=0.05,
        max=0.5,
        default=0.2
    )
    resolution: IntProperty(
        name="Resolution",
        description="Amount of geometry subdivisions between attaches",
        min=2,
        max=10,
        default=4
    )
    resolution_v: IntProperty(
        name="Resolution vertical",
        description="Amount of vertical subdivisions of curtain",
        min=2,
        max=20,
        default=10
    )
    process_frames: IntProperty(
        name="Processing iterations",
        description="Amount of frames for cloth simulation",
        min=100,
        max=500,
        default=300
    )

    mass: FloatProperty(
        precision=5, step=1,
        name="Mass",
        description="Mass of curtain tissue",
        min=0.01,
        default=5
    )
    advanced: BoolProperty(
        name="Show advanced params",
        default=False
    )

    @classmethod
    def poll(cls, context):
        return True

    def create(self, context):
        o, m = self.create_mesh("Curtain")
        self.set_flag(o, 'skip_material', True)
        d = m.archipack_window_curtain.add()
        self.link_object_to_scene(context, o)
        o.color = (0, 1, 0, 1)
        # select and make active
        self.load_preset(context, o, d)
        self.add_material(context, o, material="DEFAULT")
        return o, d

    def execute(self, context):
        sel = context.selected_objects[:]
        bpy.ops.object.select_all(action="DESELECT")
        t = time.time()
        n = 0
        # absolute size when open at maximum
        self_distance_min = 0.01
        context.window.cursor_set("WAIT")
        for o in sel:
            d = archipack_window.datablock(o)
            if d is not None:
                x, y = 0.5 * d.x + d._frame_overflow + self.x, 0.5 * d.y
                sz = d.z + min(d.frame_x, d._frame_overflow) + self.z - self.z0
                sx = x * (1 + self.oversize /100)
                ro = self.random_open / 200

                open = min(1, max(0, self.open / 100 + uniform(-ro, ro)))
                c, cd = self.create(context)
                with context_override(context, c, [c]) as ctx:
                    cd.update(ctx, self, sx, sz, side="LEFT", self_distance_min=self_distance_min, open=open)
                c.parent = o
                c.matrix_world = o.matrix_world.copy()
                c.location = Vector((-x, self.dy + y, d.altitude + self.z0))

                open = min(1, max(0, self.open / 100 + uniform(-ro, ro)))
                c, cd = self.create(context)
                with context_override(context, c, [c]) as ctx:
                    cd.update(ctx, self, sx, sz, side="RIGHT", self_distance_min=self_distance_min, open=open)
                c.parent = o
                c.matrix_world = o.matrix_world.copy()
                c.location = Vector((x, self.dy + y, d.altitude + self.z0))

                n += 2
                print("Curtains %s done" % n)

        context.window.cursor_set("DEFAULT")
        dt = time.time()-t
        if n > 0:
            self.report({'INFO'}, "Curtains %s %.2f seconds (%.2f seconds each)" % (n, dt, dt / n))
        else:
            self.report({'WARNING'}, "Curtain creation failed")

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "dy", text_ctxt=self.translation_context)
        layout.prop(self, "x", text_ctxt=self.translation_context)
        layout.prop(self, "z", text_ctxt=self.translation_context)
        layout.prop(self, "z0", text_ctxt=self.translation_context)
        layout.prop(self, "open", text_ctxt=self.translation_context)
        layout.prop(self, "random_open", text_ctxt=self.translation_context)
        layout.separator()
        icon = "TRIA_RIGHT"
        if self.advanced:
            icon = "TRIA_DOWN"
        layout.prop(self, "advanced", icon=icon, text_ctxt=self.translation_context)
        if self.advanced:
            layout.prop(self, "y", text_ctxt=self.translation_context)
            layout.prop(self, "oversize", text_ctxt=self.translation_context)
            layout.prop(self, "mass", text_ctxt=self.translation_context)
            layout.prop(self, "attach_spacing", text_ctxt=self.translation_context)
            layout.prop(self, "resolution", text_ctxt=self.translation_context)
            layout.prop(self, "resolution_v", text_ctxt=self.translation_context)
            layout.prop(self, "process_frames", text_ctxt=self.translation_context)
        layout.separator()

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


# ------------------------------------------------------------------
# Define operator class to load / save presets
# ------------------------------------------------------------------

class ARCHIPACK_OT_window_preset_draw(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and draw windows over wall"
    bl_idname = "archipack.window_preset_draw"
    bl_label = "Window preset"
    preset_subdir = "archipack_window"
    
    
class ARCHIPACK_OT_window_preset_menu(PresetMenuOperator, Operator):
    bl_description = "Choose a window preset"
    bl_idname = "archipack.window_preset_menu"
    bl_label = "Window preset"
    preset_subdir = "archipack_window"


class ARCHIPACK_OT_window_preset_create(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and create standalone window at cursor location"
    bl_idname = "archipack.window_preset_create"
    bl_label = "Window preset"
    preset_subdir = "archipack_window"


class ARCHIPACK_OT_window_preset(ArchipackPreset, Operator):
    bl_description = "Add / remove a Window Preset"
    bl_idname = "archipack.window_preset"
    bl_label = "Window preset"
    preset_menu = "ARCHIPACK_OT_window_preset_menu"

    @property
    def blacklist(self):
        return ['y']


def register():
    bpy.utils.register_class(archipack_window_panel)
    bpy.utils.register_class(archipack_window_panelrow)
    bpy.utils.register_class(archipack_window_panelrow2)
    Mesh.archipack_window_panel = CollectionProperty(type=archipack_window_panel)
    bpy.utils.register_class(ARCHIPACK_PT_window_panel)

    bpy.utils.register_class(archipack_window_shutter)
    Mesh.archipack_window_shutter = CollectionProperty(type=archipack_window_shutter)
    bpy.utils.register_class(ARCHIPACK_PT_window_shutter)

    bpy.utils.register_class(archipack_window)
    Mesh.archipack_window = CollectionProperty(type=archipack_window)
    bpy.utils.register_class(ARCHIPACK_OT_window_preset_menu)
    bpy.utils.register_class(ARCHIPACK_OT_window_preset_create)
    bpy.utils.register_class(ARCHIPACK_OT_window_preset_draw)
    bpy.utils.register_class(ARCHIPACK_PT_window)
    bpy.utils.register_class(ARCHIPACK_OT_window)
    bpy.utils.register_class(ARCHIPACK_OT_window_preset)
    bpy.utils.register_class(ARCHIPACK_OT_window_draw)
    bpy.utils.register_class(ARCHIPACK_OT_window_portals)
    bpy.utils.register_class(archipack_window_curtain)
    Mesh.archipack_window_curtain = CollectionProperty(type=archipack_window_curtain)
    bpy.utils.register_class(ARCHIPACK_OT_window_curtain)
    bpy.utils.register_class(ARCHIPACK_PT_window_curtain)
    bpy.utils.register_class(ARCHIPACK_OT_window_array)
    bpy.utils.register_class(ARCHIPACK_OT_window_surface_deform)

def unregister():

    bpy.utils.unregister_class(ARCHIPACK_OT_window_array)
    bpy.utils.unregister_class(archipack_window_panelrow)
    bpy.utils.unregister_class(archipack_window_panelrow2)
    bpy.utils.unregister_class(archipack_window_panel)

    bpy.utils.unregister_class(ARCHIPACK_PT_window_panel)
    del Mesh.archipack_window_panel

    bpy.utils.unregister_class(archipack_window_shutter)
    bpy.utils.unregister_class(ARCHIPACK_PT_window_shutter)
    del Mesh.archipack_window_shutter

    bpy.utils.unregister_class(archipack_window)
    del Mesh.archipack_window

    bpy.utils.unregister_class(ARCHIPACK_OT_window_preset_menu)
    bpy.utils.unregister_class(ARCHIPACK_OT_window_preset_create)
    bpy.utils.unregister_class(ARCHIPACK_OT_window_preset_draw)
    bpy.utils.unregister_class(ARCHIPACK_PT_window)
    bpy.utils.unregister_class(ARCHIPACK_OT_window)
    bpy.utils.unregister_class(ARCHIPACK_OT_window_preset)
    bpy.utils.unregister_class(ARCHIPACK_OT_window_draw)
    bpy.utils.unregister_class(ARCHIPACK_OT_window_portals)
    bpy.utils.unregister_class(ARCHIPACK_OT_window_surface_deform)

    bpy.utils.unregister_class(ARCHIPACK_OT_window_curtain)
    bpy.utils.unregister_class(ARCHIPACK_PT_window_curtain)
    bpy.utils.unregister_class(archipack_window_curtain)
    del Mesh.archipack_window_curtain
