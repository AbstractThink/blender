# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
import bpy
import json
from uuid import uuid4
from mathutils import Vector
from bpy.types import Operator, PropertyGroup, Mesh, Panel, Object
from bpy.props import (
    FloatProperty, IntProperty, BoolProperty,
    CollectionProperty, EnumProperty, StringProperty, PointerProperty,
    FloatVectorProperty
)
from .bmesh_utils import BmeshEdit as bmed
from .archipack_preset import ArchipackPreset, PresetMenuOperator
from .archipack_manipulator import Manipulable, archipack_manipulator
from .archipack_abstraction import Callbacks, ensure_select_and_restore, context_override
from .archipack_i18n import Archipacki18n
from .archipack_object import (
    ArchipackPanel,
    ArchipackObject,
    ArchipackCreateTool,
    ArchipackDrawTool,
    ArchipackArrayTool
)
from .archipack_compound import Compound, CompoundPart
from .archipack_gl import FeedbackPanel
from .archipack_keymaps import Keymaps


def update(self, context):
    self.update(context)


def update_source(self, context):
    self.update_source(context)
    if self.source is not None and self.parent_data is not None:
        o = self.source
        self.parent_data.auto_update = False
        self.location = context.active_object.matrix_world.inverted() @ o.matrix_world.translation
        self.rotation = 0
        self.parent_data.auto_update = True
    else:
        self.update(context)
    self.cleanup_user_defined_objects(context, bpy.data.objects)


class archipack_assembly_member(Archipacki18n, ArchipackObject, CompoundPart, PropertyGroup):
    # assoc by index so it is possible to re-use same source many time
    source: PointerProperty(type=Object, update=update_source, name="", description="Source parent object")

    rotation: FloatProperty(
        name="Rotation (Z)",
        default=0,
        subtype='ANGLE', unit='ROTATION',
        update=update
    )
    location: FloatVectorProperty(
        subtype='XYZ',
        name="Location",
        default=Vector((0, 0, 0)),
        update=update
    )
    manipulators: CollectionProperty(type=archipack_manipulator)

    def update(self, context):
        if self.parent_data is not None:
            self.parent_data.update(context)

    @property
    def parent_data(self):
        if isinstance(self.id_data, Mesh):
            return self.id_data.archipack_assembly[0]
        return None

    def draw_member(self, context, layout, num, target):
        box = layout.box()
        row = box.row(align=True)
        if target is not None:
            self.draw_op(
                context, layout, row, "archipack.select", icon="RESTRICT_SELECT_OFF", text=""
                ).name = target.name
        row.prop(self, "source")
        self.draw_op(context, layout, row, "archipack.assembly_remove", icon='REMOVE', text="").index = num
        self.draw_prop(context, layout, box, self, "location")
        self.draw_prop(context, layout, box, self, "rotation")


class ARCHIPACK_PT_assembly_member(ArchipackPanel, Archipacki18n, Panel):
    """Archipack Assembly"""
    bl_idname = "ARCHIPACK_PT_assembly_member"
    bl_label = "Assembly"

    @classmethod
    def poll(cls, context):
        return archipack_assembly_member.poll(context.active_object)

    def draw(self, context):
        o = context.active_object
        d = archipack_assembly_member.datablock(o)

        if d is None:
            return

        layout = self.layout
        self.draw_op(
            context, layout, layout, "archipack.select_parent", icon="RESTRICT_SELECT_OFF", text="Select assembly"
        )


class archipack_assembly(Archipacki18n, Compound, ArchipackObject, Manipulable, PropertyGroup):

    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('MAIN', 'Main', 'Display main settings', 'NONE', 0),
            ('MEMBERS', 'Members', 'Display members settings', 'NONE', 1),
        ),
        default='MAIN',
    )

    x: FloatProperty(
        name="Width",
        min=0.001,
        default=0.1, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE'
    )
    y: FloatProperty(
        name="Depth",
        min=0.001,
        default=0.1, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE'
    )
    z: FloatProperty(
        name="Height",
        default=2.0, min=0.01, precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )
    symbol_scale: FloatProperty(name="Symbol scale", min=0.01, default=0.2, update=update)

    parts: CollectionProperty(type=archipack_assembly_member)

    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        default=True,
        update=update
    )
    def get_member_datablock(self, o):
        return archipack_assembly_member.datablock(o)

    @property
    def _members_parts(self):
        return [part for part in self.parts if part.source is not None]

    def on_delete(self, context, obj):
        # call on_delete of members
        for c in obj.children:
            d = self.archipack_datablock(c)
            if d is not None and hasattr(d, "on_delete"):
                d.on_delete(context, c)
        ArchipackObject.on_delete(self, context, obj)

    def setup_manipulators(self):
        for i, p in enumerate(self.parts):
            n_manips = len(p.manipulators)
            if n_manips < 1:
                s = p.manipulators.add()
            else:
                s = p.manipulators[0]
            s.prop1_name = "x"
            s.prop2_name = json.dumps({"do_not_move": True})
            s.type_key = 'DELTA_LOC'
            s.normal = Vector((0, 1, 0))

    def manipulable_setup(self, context, o):
        self.setup_manipulators()
        for p in self.parts:
            self.manip_stack.append(p.manipulators[0].setup(context, o, p.location))

    def update(self, context):

        o = self.find_in_selection(context, self.auto_update)

        if o is None:
            return

        # clean up manipulators before any data model change
        if self.manipulable_refresh:
            self.manipulable_disable(o)

        verts = [self.symbol_scale * Vector(v) for v in [
            (-0.5, -0.5, -0.5), (-0.5, -0.5, 0.5), (-0.5, 0.5, -0.5),
            (-0.5, 0.5, 0.5), (0.5, -0.5, -0.5), (0.5, -0.5, 0.5),
            (0.5, 0.5, -0.5), (0.5, 0.5, 0.5), (-0.123, -0.379, -0.125),
            (-0.123, -0.379, 0.375), (-0.123, 0.121, 0.375), (0.377, -0.379, -0.125),
            (0.377, -0.379, 0.375), (0.377, 0.121, -0.125), (0.377, 0.121, 0.375),
            (0.25, -0.25, 0.25), (-0.123, -0.25, 0.25), (-0.123, -0.25, -0.125),
            (-0.123, 0.121, 0.25), (0.25, 0.121, 0.25), (0.25, 0.121, -0.125),
            (0.25, -0.25, -0.125), (-0.375, -0.125, -0.375), (-0.375, 0.375, -0.375),
            (-0.375, -0.125, 0.125), (0.125, -0.125, -0.375), (0.125, 0.375, -0.375),
            (0.125, 0.375, 0.125), (-0.375, 0.375, 0.125), (-0.25, 0.25, -0.25),
            (-0.25, -0.125, 0.125), (0.125, -0.125, -0.25), (-0.25, -0.125, -0.25),
            (0.125, 0.25, -0.25), (0.125, 0.25, 0.125), (-0.25, 0.25, 0.125),
            (0.5, 0.0, 0.0), (0.0, 0.0, 0.0), (-0.5, 0.0, 0.0),
            (0.0, 0.5, 0.0), (0.0, -0.5, 0.0)
        ]]
        edges = [
            (2, 0), (0, 1), (1, 3),
            (3, 2), (6, 2), (3, 7),
            (7, 6), (4, 6), (7, 5),
            (5, 4), (0, 4), (5, 1),
            (8, 9), (9, 10), (8, 11),
            (11, 12), (11, 13), (10, 14),
            (13, 14), (15, 16), (8, 17),
            (10, 18), (18, 19), (13, 20),
            (17, 21), (19, 20), (9, 12),
            (20, 21), (16, 17), (15, 19),
            (16, 18), (15, 21), (12, 14),
            (22, 23), (22, 24), (22, 25),
            (23, 26), (26, 27), (24, 28),
            (27, 28), (24, 30), (25, 31),
            (31, 32), (31, 33), (27, 34),
            (34, 35), (33, 34), (23, 28),
            (29, 32), (25, 26), (29, 33),
            (30, 32), (30, 35), (29, 35),
            (36, 37), (37, 38), (37, 39),
            (37, 40)
        ]

        bmed.buildmesh(o, verts, [], edges=edges)

        self.setup_manipulators()

        members = self.cleanup_members(context, o)

        for part in self.parts:

            if part.source is None:
                continue

            if part.part_uid not in members:

                new_c = self.duplicate_object(context, part.source, True)
                self.link_collections(o, new_c)
                # at object's level so assembly mesh remains linked
                d = new_c.archipack_assembly_member.add()
                d.source = part.source
                d.part_uid = part.part_uid
                new_c.parent = o

                for c in new_c.children:
                    if self.has_flag(c, ("hole", "custom_hole")) and c.data.users > 1:
                        # Always unlink hole data
                        c.data = c.data.copy()
            else:
                new_c = members[part.part_uid]

            # new_c must exist here but who knows ?
            if new_c is not None:
                new_c.matrix_world = o.matrix_world.copy()
                new_c.location = part.location
                new_c.rotation_euler.z = part.rotation
                self.safe_scale(new_c)
                # prevent any change of transforms
                new_c.lock_location = (True, True, True)
                new_c.lock_rotation = (True, True, True)
                new_c.lock_scale = (True, True, True)

            part.manipulators[0].set_pts([
                (part.location.x+1, 0, 0),
                (part.location.x-1, 0, 0),
                (0, 0, 0)])

        # recompute overall size for array operator
        mini, maxi, size, center = self.bound_box(o)
        self.x, self.y, self.z = size

        # synch child location of linked assembly
        self.synch_linked_location(context, o)

        # x, cx, y, cy = 0.5 * self.x, 0, 0.5 * self.y, 0
        # x0, x1 = cx - x, cx + x
        # y0, y1 = cy - y, cy + y
        #
        # self.manipulators[0].set_pts([(x0, y0, 0), (x0, y0, self.z), (0.5, 0, 0)])
        # self.manipulators[1].set_pts([(x0, y0, 0), (x1, y0, 0), (0.5, 0, 0)])
        # self.manipulators[2].set_pts([(x1, y0, 0), (x1, y1, 0), (0.5, 0, 0)])

        self.restore_context(context)


class ARCHIPACK_PT_assembly(ArchipackPanel, Archipacki18n, Panel):
    """Archipack Assembly"""
    bl_idname = "ARCHIPACK_PT_assembly"
    bl_label = "Assembly"

    @classmethod
    def poll(cls, context):
        return archipack_assembly.poll(context.active_object)

    def draw(self, context):
        o = context.active_object
        d = archipack_assembly.datablock(o)

        if d is None:
            return

        layout = self.layout

        self.draw_common(context, layout, draw_animation=False, draw_manipulate=False)
        row = layout.row(align=True)
        self.draw_op(context, layout, row, 'archipack.assembly', icon='FILE_REFRESH', text="Refresh").mode = 'REFRESH'
        if o.data.users > 1:
            self.draw_op(context, layout, row, 'archipack.assembly', icon='UNLINKED',
                         text="Make unique", postfix="({})".format(o.data.users)).mode = 'UNIQUE'
        self.draw_op(context, layout, layout, "archipack.assembly_array", icon='MOD_ARRAY', text="Array")

        box = layout.box()
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.assembly_preset_menu",
                     text=bpy.types.ARCHIPACK_OT_assembly_preset_menu.bl_label, icon="PRESET"
                     ).preset_operator = "archipack.preset_loader"
        self.draw_op(context, layout, row, "archipack.assembly_preset", icon='ADD', text="")
        self.draw_op(context, layout, row, "archipack.assembly_preset", icon='REMOVE', text="").remove_active = True

        self.draw_prop(context, layout, layout, d, 'tabs', expand=True)

        box = layout.box()
        if d.tabs == 'MAIN':
            self.draw_prop(context, layout, box, d, "symbol_scale")
            self.draw_prop(context, layout, box, d, 'z')
            self.draw_prop(context, layout, box, d, 'x')
            self.draw_prop(context, layout, box, d, 'y')

        elif d.tabs == 'MEMBERS':
            self.draw_op(context, layout, box, "archipack.assembly_add", icon='ADD', text="")

            members = d._members(o)
            for i, c in enumerate(d.parts):
                target = None
                if c.part_uid in members:
                    target = members[c.part_uid]
                c.draw_member(context, layout, i, target)


class ARCHIPACK_OT_assembly(ArchipackCreateTool, Operator):
    bl_idname = "archipack.assembly"
    bl_label = "Assembly"
    bl_description = "Create New empty Assembly at cursor location"
    mode: EnumProperty(
        items=(
            ('CREATE', 'Create', '', 0),
            ('REFRESH', 'Refresh', '', 2),
            ('UNIQUE', 'Make unique', '', 3),
        ),
        default='CREATE'
    )
    standalone: BoolProperty(default=True)

    def create(self, context):
        o, m = self.create_mesh("Assembly")
        d = m.archipack_assembly.add()

        self.link_object_to_scene(context, o)
        o.color = (0, 1, 0, 1)

        # select and make active
        self.select_object(context, o, True)
        # self.add_material(context, o, material="DEFAULT", category="assembly")
        self.load_preset(context, o, d)
        self.hide_for_render_engines(o)
        # set / clear standalone parameter
        for c in o.children:
            if c.data and (
                "archipack_window" in c.data or
                "archipack_door" in c.data
            ):
                self.set_flag(c, "standalone", self.standalone)
                
        return o

    def update(self, context):
        o = context.active_object
        d = archipack_assembly.datablock(o)
        if d is not None:
            for part in d.parts:
                part.part_uid = str(uuid4())
            d.update(context)
            linked_objects = self.get_linked_objects(context, o)
            for linked in linked_objects:
                if linked != o:
                    archipack_assembly.datablock(linked).update(context)

    def unique(self, context):
        obj = context.active_object
        sel = context.selected_objects[:]
        uniques = []
        for o in sel:
            if archipack_assembly.filter(o):
                # select and make active
                Callbacks.call("unique", context, o, None)
                self.rec_get_childrens(o, uniques)

        if bool(uniques):
            with ensure_select_and_restore(context, uniques[0], uniques):
                bpy.ops.object.make_single_user(
                    type='SELECTED_OBJECTS', object=True, obdata=True, material=False, animation=False
                )
            self.select_object(context, obj, True)
        # -----------------------------------------------------
        # Execute
        # -----------------------------------------------------

    def execute(self, context):
        if context.mode == "OBJECT":
            if self.mode == 'CREATE':
                bpy.ops.object.select_all(action="DESELECT")
                o = self.create(context)
                o.location = self.get_cursor_location(context)
                # select and make active
                self.select_object(context, o, True)

            elif self.mode == 'REFRESH':
                self.update(context)
            elif self.mode == 'UNIQUE':
                self.unique(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_assembly_add(Operator):
    bl_idname = "archipack.assembly_add"
    bl_label = "Add"
    bl_description = "Add member"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_assembly.datablock(o)
            if d is None:
                return {'CANCELLED'}
            d.manipulable_refresh = True
            p = d.parts.add()
            p.part_uid = str(uuid4())
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_assembly_remove(Operator):
    bl_idname = "archipack.assembly_remove"
    bl_label = "Remove"
    bl_description = "Remove"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_assembly.datablock(o)
            if d is None:
                return {'CANCELLED'}
            d.manipulable_refresh = True
            d.parts.remove(self.index)
            d.update(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_assembly_array(ArchipackArrayTool, Operator):
    bl_idname = "archipack.assembly_array"
    bl_label = "Assembly Array"
    bl_description = "Duplicate selected Assembly"
    bl_options = {'UNDO'}

    # XXX crash on redo when using spinner values ..
    # bl_options = {'REGISTER', 'UNDO'}

    def filter_object(self, o):
        d = o.data
        return d is not None and (
            "archipack_door" in d or
            "archipack_window" in d or
            "archipack_custom" in d or
            "archipack_hole" in d
        )

    def get_object_datablock(self, o):
        return self.archipack_datablock(o)


class ARCHIPACK_OT_assembly_draw(ArchipackDrawTool, Operator):
    bl_idname = "archipack.assembly_draw"
    bl_label = "Draw Assemblys"
    bl_description = "Draw Assemblys over walls"

    filepath: StringProperty(default="")
    feedback = None
    stack = []
    object_name = ""
    keymap = None
    _handle = None

    @classmethod
    def poll(cls, context):
        return True

    def draw_callback(self, _self, context):
        self.feedback.draw(context)

    def add_object(self, context, event):

        bpy.ops.object.select_all(action="DESELECT")
        o = context.scene.objects.get(self.object_name)

        if self.filepath == '' and archipack_assembly.filter(o):
            o = self.duplicate_object(context, o, False)
            d = archipack_assembly.datablock(o)
            self.load_preset(context, o, d)
            self.select_object(context, o, True)
        else:
            bpy.ops.archipack.assembly(filepath=self.filepath, standalone=False)
            o = context.active_object

        if o is None:
            o = context.object

        self.object_name = o.name
        return o

    @staticmethod
    def remove_object(context, o):
        if archipack_assembly.filter(o):
            with context_override(context, o, [o]) as ctx:
                bpy.ops.archipack.delete(ctx)

    def exit(self, context, o):
        self.remove_object(context, o)
        self.feedback.disable()
        try:
            context.space_data.show_gizmo = True
        except:
            pass
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

    def modal(self, context, event):

        o = self.get_scene_object(context, self.object_name)

        if o is None or context.area is None:
            self.exit(context, o)
            return {'FINISHED'}

        context.area.tag_redraw()

        d = archipack_assembly.datablock(o)
        hole = None

        # hide Assembly and hole from ray cast, broken till 28.02 ..
        to_hide = []
        self.rec_get_childrens(o, to_hide)

        for obj in to_hide:
            self.hide_object(obj)

        res, tM, wall, width, y, z_offset = self.mouse_hover_wall(context, event)

        for obj in to_hide:
            self.show_object(obj)

        if res and d is not None:
            o.matrix_world = tM
            for c in o.children:
                cd = self.archipack_datablock(c)
                if cd is not None:
                    if hasattr(cd, "z_offset") and abs(cd.z_offset - z_offset) > 0.001:
                        self.select_object(context, c, True)
                        cd.z_offset = z_offset

                    if hasattr(cd, "y") and abs(cd.y - width) > 0.001:
                        self.select_object(context, c, True)
                        cd.y = width

        if event.value == 'PRESS':

            if event.type in {'C', 'D'}:
                self.exit(context, o)
                bpy.ops.archipack.assembly_preset_menu(
                    'INVOKE_DEFAULT',
                    preset_operator="archipack.assembly_draw")
                self.restore_walls(context)
                return {'FINISHED'}

            if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'}:
                if wall is not None:
                    # select and make active
                    for c in o.children:
                        if c.data and (
                                "archipack_window" in c.data or
                                "archipack_door" in c.data or
                                "archipack_hole" in c.data or
                                self.has_flag(c, "custom_hole")
                        ):
                            with context_override(context, wall, [c]) as ctx:
                                bpy.ops.archipack.single_boolean(ctx, parent_to_reference=False)

                    # link assembly to reference
                    with context_override(context, wall, [o]) as ctx:
                        bpy.ops.archipack.add_reference_point(ctx)

                    # o must be a assembly here
                    if d is not None:
                        # make linked object
                        if len(self.stack) > 0 and not event.shift:
                            last = self.stack[-1]
                            d_last = archipack_assembly.datablock(last)
                            if d_last.y == d.y:
                                # Must disable manipulators before link !!
                                self.link_object(last, o)

                        if "archipack_wall2" in wall.data:
                            # update dimensions
                            with ensure_select_and_restore(context, wall, [wall]):
                                wd = wall.data.archipack_wall2[0]
                                wg = wd.get_generator()
                                wd.setup_childs(context, wall, g=wg, openings_only=True)
                                wd.relocate_childs(context, wall, g=wg)
                                wd.update_dimension(context, wall, wg)

                    if d is not None:
                        # self.select_object(context, o, True)
                        self.stack.append(o)

                        o = self.add_object(context, event)
                        o.matrix_world = tM

                    return {'RUNNING_MODAL'}

            # prevent selection of other object
            if event.type in {'RIGHTMOUSE'}:
                return {'RUNNING_MODAL'}

        if self.keymap.check(event, self.keymap.undo) or (
                event.type in {'BACK_SPACE'} and event.value == 'RELEASE'
        ):
            if len(self.stack) > 0:
                last = self.stack.pop()
                self.remove_object(context, last)
                # self.select_object(context, o, True)
            return {'RUNNING_MODAL'}

        if event.value == 'RELEASE':

            if event.type in {'ESC', 'RIGHTMOUSE'}:
                self.exit(context, o)
                self.restore_walls(context)

                return {'FINISHED'}

        return {'PASS_THROUGH'}

    def invoke(self, context, event):

        if context.mode == "OBJECT":
            o = context.active_object
            self.stack = []
            self.keymap = Keymaps(context)
            # exit manipulate_mode if any
            bpy.ops.archipack.disable_manipulate()

            # Hide manipulators
            context.space_data.show_gizmo = False

            # invoke with alt pressed will use current object as basis for linked copy
            if self.filepath == '' and archipack_assembly.filter(o):
                self.stack.append(o)
                o = self.duplicate_object(context, o, False)
                self.object_name = o.name
            else:
                o = self.add_object(context, event)

            # select and make active
            bpy.ops.object.select_all(action="DESELECT")
            self.select_object(context, o, True)

            self.feedback = FeedbackPanel()
            self.feedback.instructions(context, "Draw a Assembly", "Click & Drag over a wall", [
                ('LEFTCLICK, RET, SPACE, ENTER', 'Create a Assembly'),
                ('BACKSPACE, CTRL+Z', 'undo last'),
                ('D', 'Draw another Assembly'),
                ('SHIFT', 'Make independant copy'),
                ('RIGHTCLICK or ESC', 'exit')
            ])
            self.feedback.enable()
            args = (self, context)

            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


# ------------------------------------------------------------------
# Define operator class to load / save presets
# ------------------------------------------------------------------


class ARCHIPACK_OT_assembly_preset_draw(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and draw Assemblys over wall"
    bl_idname = "archipack.assembly_preset_draw"
    bl_label = "Assembly Presets"
    preset_subdir = "archipack_assembly"


class ARCHIPACK_OT_assembly_preset_create(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and create standalone Assembly at cursor location"
    bl_idname = "archipack.assembly_preset_create"
    bl_label = "Assembly preset"
    preset_subdir = "archipack_assembly"


class ARCHIPACK_OT_assembly_preset_menu(PresetMenuOperator, Operator):
    bl_description = "Show Assemblys presets"
    bl_idname = "archipack.assembly_preset_menu"
    bl_label = "Assembly Presets"
    preset_subdir = "archipack_assembly"


class ARCHIPACK_OT_assembly_preset(ArchipackPreset, Operator):
    bl_description = "Add / remove a Assembly Preset"
    bl_idname = "archipack.assembly_preset"
    bl_label = "Assembly Preset"
    preset_menu = "ARCHIPACK_OT_assembly_preset_menu"

    def prepare_preset(self, context, o, preset):
        d = archipack_assembly.datablock(o)
        d.update_sources_uids(o)

    @property
    def blacklist(self):
        return ['manipulators']


def register():

    bpy.utils.register_class(archipack_assembly_member)
    Object.archipack_assembly_member = CollectionProperty(type=archipack_assembly_member)

    bpy.utils.register_class(archipack_assembly)
    Mesh.archipack_assembly = CollectionProperty(type=archipack_assembly)
    bpy.utils.register_class(ARCHIPACK_PT_assembly)
    bpy.utils.register_class(ARCHIPACK_PT_assembly_member)

    bpy.utils.register_class(ARCHIPACK_OT_assembly)
    bpy.utils.register_class(ARCHIPACK_OT_assembly_add)
    bpy.utils.register_class(ARCHIPACK_OT_assembly_remove)

    bpy.utils.register_class(ARCHIPACK_OT_assembly_preset_menu)
    bpy.utils.register_class(ARCHIPACK_OT_assembly_preset_create)
    bpy.utils.register_class(ARCHIPACK_OT_assembly_preset_draw)
    bpy.utils.register_class(ARCHIPACK_OT_assembly_array)
    bpy.utils.register_class(ARCHIPACK_OT_assembly_preset)
    bpy.utils.register_class(ARCHIPACK_OT_assembly_draw)


def unregister():
    bpy.utils.unregister_class(ARCHIPACK_PT_assembly_member)

    bpy.utils.unregister_class(archipack_assembly)
    bpy.utils.unregister_class(archipack_assembly_member)

    del Mesh.archipack_assembly
    del Object.archipack_assembly_member
    bpy.utils.unregister_class(ARCHIPACK_PT_assembly)
    bpy.utils.unregister_class(ARCHIPACK_OT_assembly)
    bpy.utils.unregister_class(ARCHIPACK_OT_assembly_add)
    bpy.utils.unregister_class(ARCHIPACK_OT_assembly_remove)

    bpy.utils.unregister_class(ARCHIPACK_OT_assembly_preset_menu)
    bpy.utils.unregister_class(ARCHIPACK_OT_assembly_preset_create)
    bpy.utils.unregister_class(ARCHIPACK_OT_assembly_preset_draw)
    bpy.utils.unregister_class(ARCHIPACK_OT_assembly_array)
    bpy.utils.unregister_class(ARCHIPACK_OT_assembly_preset)
    bpy.utils.unregister_class(ARCHIPACK_OT_assembly_draw)
