# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
# ----------------------------------------------------------

import time
import bpy
from mathutils import Vector, Matrix
from bpy_extras.io_utils import ExportHelper
from bpy.types import BezierSplinePoint, Operator
from bpy.props import StringProperty, BoolProperty
from .archipack_autoboolean import ArchipackBoolManager
from .archipack_i18n import Archipacki18n
from .archipack_object import ArchipackObjectsManager

# TODO: use etree instead
# https://github.com/domlysz/BlenderGIS/blob/master/core/utils/gradient.py#L443

DEFAULT_STYLES = """
    text{
        font-style:normal;
        font-weight:normal;
        line-height:125%;
        font-family:sans-serif;
        letter-spacing:0px;
        word-spacing:0px;
        fill-opacity:1;
        stroke:none;
        stroke-width:1px;
        stroke-linecap:butt;
        stroke-linejoin:miter;
        stroke-opacity:1;
        text-anchor:middle;
        text-align:center;
    }
    path{
        stroke-linecap:butt;
        stroke-linejoin:round;
        stroke-opacity:1;
        fill-opacity:1;
    }
"""


XML_HEADER = """<?xml version="1.0" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20010904//EN" "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">
<svg id="document" width="{5}mm" height="{6}mm"  viewBox="0 0 {0} {1}" xmlns="http://www.w3.org/2000/svg">
    <title id="title">{2}</title>
    <desc id="desc">Archipack svg exporter</desc>
    <style>
        {3}
        {4}
    </style>
"""

XML_PATH = """<path id="{}" {}
    d="{}"/>
"""

XML_TEXT = """<text id="{}" {}
    x="0" y="0" transform="{}">{}</text>
"""

XML_TSPAN = """<tspan id="tspan{}{}" x="{}" y="{}">{}</tspan>
"""


XML_GROUP = """<g id="{}">
    {}</g>
"""

STROKE_WIDTH_UNIT = 'px'
FONT_SIZE_UNIT = 'px'

XML_END = "</svg>"
MOVE_COMMAND = 'M{},{} '
LINE_COMMAND = 'L{},{} '
CURVE_COMMAND = 'C{},{} {},{} {},{} '
JOIN_COMMAND = 'Z '

objman = ArchipackObjectsManager()


class SvgGroup:
    def __init__(self, index, components):
        self.index = index
        self.components = components
    
    def __str__(self):
        return XML_GROUP.format(
            self.index,
            "".join(["%s" % c for c in self.components])
        ) 


class SvgPath:
    """
      path might contains multiple curves
      create with shape 0 and
      call add_shape to add shapes > 0
    """
    def __init__(self, index, tM, spline, style):
        self.index = index
        self.style = style
        self.path = []
        self.fill = ""
        self.add_shape(tM, spline, style)
    
    def __str__(self):
        return XML_PATH.format(
            self.index,
            self.style.tag(fill=self.fill),
            "".join(self.path)
        )

    def add_shape(self, tM, spline, style):

        self.fill = ""
        if spline.type == 'BEZIER':
            first_curve_point = None
            previous = None
            for n, point in enumerate(spline.bezier_points):
                co = tM @ point.co.to_3d()
                if n == 0:
                    first_curve_point = point
                    self.path.append(MOVE_COMMAND.format(co.x, co.y))
                else:
                    self.path.append(self.make_curve_command(previous, tM, point))
                previous = point

            if spline.use_cyclic_u and first_curve_point is not None:
                self.path.append(self.make_curve_command(previous, tM, first_curve_point))

        elif spline.type == 'POLY':
            for n, point in enumerate(spline.points):
                co = tM @ point.co.to_3d()
                if n == 0:
                    self.path.append(MOVE_COMMAND.format(co.x, co.y))
                else:
                    self.path.append(LINE_COMMAND.format(co.x, co.y))

        if spline.use_cyclic_u:
            self.path.append(JOIN_COMMAND)
        else:
            self.fill = 'none'

    def make_curve_command(self, previous, tM, point):
        co = tM @ point.co.to_3d()
        left = tM @ point.handle_left.to_3d()
        right = tM @ previous.handle_right.to_3d()
        return CURVE_COMMAND.format(right.x, right.y, left.x, left.y, co.x, co.y)


class SvgText:
    def __init__(self, tM, curve, scale, style):
        x, y, z = tM @ Vector((0, 0, 0))
        rM = tM.normalized().to_3x3()
        rxx, rxy = rM[0][0:2]
        ryx, ryy = rM[1][0:2]
        self.index = curve.name
        self.style = style
        self.size = curve.data.size / scale
        self.matrix = "matrix({},{},{},{},{},{})".format(rxx, rxy, -ryx, -ryy, x, y)
        self.body = curve.data.body
    
    def __str__(self):
        if "\n" in self.body:
            body = self.body.split("\n")
            body = "".join([
                XML_TSPAN.format(self.index, i, 0, (i * 1.5) * self.size, txt)
                for i, txt in enumerate(body)
            ])
        else:
            body = self.body
        return XML_TEXT.format(self.index, self.style.tag(self.size), self.matrix, body)
    

class SVGStyle:
    def __init__(self, width, stroke, fill, css_class, use_css=False):
        self.width = width
        self.stroke = stroke
        self.fill = fill
        self.css_class = css_class
        self.use_css = use_css

    def css_class_def(self):
        return ".%s{stroke-width:%s%s; stroke:%s; fill:%s;}" % (
            self.css_class, self.width, STROKE_WIDTH_UNIT, self.stroke, self.fill
        )

    def tag(self, font_size=0, fill=""):
        if self.use_css:
            if font_size > 0:
                return 'class="%s" style="font-size:%s%s;"' % (
                    self.css_class, font_size, FONT_SIZE_UNIT
                )
            else:
                if fill != "":
                    return 'class="%s" style="fill:%s;"' % (self.css_class, fill)
                else:
                    return 'class="%s"' % self.css_class
        else:
            if fill != "":
                _fill = fill
            else:
                _fill = self.fill
            if font_size > 0:
                return 'style="font-size:%s%s; stroke:none; fill:%s;"' % (
                    font_size, FONT_SIZE_UNIT, _fill
                )
            else:
                return 'style="stroke-width:%s%s; stroke:%s; fill:%s;"' % (
                    self.width, STROKE_WIDTH_UNIT, self.stroke, _fill
                )

    def copy(self):
        return SVGStyle(self.width, self.stroke, self.fill, self.css_class, self.use_css)


def SVG_blenderCurve(itM, curve, style, components, as_group=True):
    """
      when as_group is true, add components and
      append svg_path for each shape of curve into components and return a SvgGroup
      when as_group is false, add all shapes into same SvgPath entity
      append svg_path to components and return svg_path
    """
    if curve is None:
        return
    name = curve.name
    tM = itM @ curve.matrix_world
    if as_group:
        for i, spline in enumerate(curve.data.splines):
            components.append(SvgPath(
                "{}-{}".format(name, i),
                tM, spline, style)
            )
        return SvgGroup(name, components)
    else:
        svg_path = None
        for i, spline in enumerate(curve.data.splines):
            if i == 0:
                svg_path = SvgPath(
                    "{}-0".format(name),
                    tM, spline, style
                )
            else:
                svg_path.add_shape(tM, spline, style)
        if svg_path is not None:
            components.append(svg_path)
        return svg_path


def SVG_dimension(itM, dimension, scale, style):
    components = []
    _style = style.copy()
    _style.css_class = "dims-text"
    _style.stroke = 'none'
    for txt in dimension.children:
        if txt.type == 'FONT':
            components.append(SvgText(itM @ txt.matrix_world, txt, scale, _style))
    # add the curve into components
    SVG_blenderCurve(itM, dimension, style, components, as_group=False)
    return SvgGroup("{}".format(dimension.name), components)


def SVG_dimensions(itM, dims, scale, style):
    dimensions = []
    for c in dims:
        dimensions.append(SVG_dimension(itM, c, scale, style))
    return SvgGroup("Dimensions", dimensions)


def SVG_slabs(itM, context, slabs, style):
    parts = []
    for c in slabs:
        res = []
        d = c.data.archipack_slab[0]
        symbols = d.as_2d(context, c)
        for symbol in symbols:
            # add window in her own group, let separate curves so panels fill override frame
            svg_path = SVG_blenderCurve(itM, symbol, style, [], as_group=False)
            if svg_path is not None:
                res.append(svg_path)
            objman.delete_object(context, symbol)
        if len(res):
            parts.append(SvgGroup(c.name, res))
    return SvgGroup("Slabs", parts)


def SVG_wall(self, context, itM, wall, scale, styles):
    """
     Export wall with dimension and openings symbols
    """
    openings = []
    parts = []

    d = wall.data.archipack_wall2[0]

    print("Export %s" % wall.name)

    inter = []
    # doors holes
    doors = []
    windows = []

    if self.merge_walls:
        geom_mode = 'PLAN_2D_MERGED'
    else:
        geom_mode = 'PLAN_2D'

    try:
        io, geom, t_childs = d.as_geom(context, wall, geom_mode, inter, doors, windows)
    except:
        self.report(
            {"WARNING"},
            "Error exporting wall %s, take a look at console for more informations" % wall.name
        )
        print("Archipack svg export error with wall %s : topology error" % wall.name)
        print("Ensure walls are not crossing - use wall tools -> create curve -> Plan 2d")
        return None

    # collect polygons
    geoms = []
    if geom.type_id == 6:
        # Multipolygon
        geoms = geom.geoms
    elif geom.type_id == 3:
        # Polygon
        geoms = [geom]
    elif geom.type_id == 7:
        # GeometryCollection components may be Polygon and Multipolygon
        for g in geom.geoms:
            if g.type_id == 3:
                geoms.append(g)
            elif g.type_id == 6:
                geoms.extend(g.geoms)

    if len(geoms) < 1:
        # no polygons found, probably a topology error like crossing walls
        self.report(
            {"WARNING"},
            "Error exporting wall %s, take a look at console for more informations" % wall.name
        )
        print("Archipack svg export error with wall %s : no polygon found" % wall.name)
        print("Ensure walls are not crossing - use wall tools -> create curve -> Plan 2d")
        return None

    # ensure reversed cw ccw for interiors
    for poly in geoms:
        is_ccw = poly.exterior.is_ccw
        for i, c in enumerate(poly.interiors):
            if c.is_ccw == is_ccw:
                poly.interiors[i] = c.reverse()

    w = io._to_curve(geom, "{}-2d".format(wall.name), '2D')
    # wall plain parts
    SVG_blenderCurve(itM, w, styles['wall'], parts, as_group=False)
    objman.delete_object(context, w)

    # wall fill under windows
    if len(inter) > 0:
        for i, c in enumerate(inter):
            f = io._to_curve(c, "{}-w-2d-{}".format(wall.name, i), '2D')
            SVG_blenderCurve(itM, f, styles['hole'], parts, as_group=False)
            objman.delete_object(context, f)

    # windows / doors
    for c in windows:
        if "archipack_window" in c.data:
            d = c.data.archipack_window[0]
        # elif "archipack_hole" in c.data:
        #    d = c.data.archipack_hole[0]
        else:
            continue
        symbol = d.as_2d(context, c)
        # add window in her own group, let separate curves so panels fill override frame
        svg_path = SVG_blenderCurve(itM, symbol, styles['openings'], [], as_group=True)
        if svg_path is not None:
            openings.append(svg_path)
        objman.delete_object(context, symbol)

    for c in doors:
        if "archipack_door" in c.data:
            d = c.data.archipack_door[0]
        # elif "archipack_hole" in c.data:
        #    d = c.data.archipack_hole[0]
        else:
            continue
        symbol = d.as_2d(context, c)
        # add doors in her own group, let separate curves so panels fill override frame
        svg_path = SVG_blenderCurve(itM, symbol, styles['openings'], [], as_group=True)
        if svg_path is not None:
            openings.append(svg_path)
        objman.delete_object(context, symbol)

    parts.append(SvgGroup("{}-openings".format(wall.name), openings))

    return SvgGroup(wall.name, parts)


def rgb_to_hex(rgb):
    return '#%02x%02x%02x' % rgb


def getZ(curve):
    return curve.matrix_world.translation.z


def point_str(itM, point):
    co = itM @ point.co
    if isinstance(point, BezierSplinePoint):
        left = itM @ point.handle_left
        right = itM @ point.handle_right
        return "[x: {}, y: {}, z: {},\n" \
               " x: {}, y: {}, z: {},\n" \
               " x: {}, y: {}, z: {}]".format(left.x, left.y, left.z,
                                              co.x, co.y, co.z,
                                              right.x, right.y, right.z)
    else:
        return "[x: {}, y: {}, z: {}]".format(co.x, co.y, co.z)


class ARCHIPACK_OT_ExportSvg(ArchipackObjectsManager, ExportHelper, Operator):
    bl_idname = "export_svg.archipack"
    bl_label = "Export .svg"
    bl_description = "Archipack Inkscape SVG Exporter (2d curves only)"

    bl_options = {'PRESET'}
    filename_ext = ".svg"
    # ExportHelper class properties
    filter_glob: StringProperty(
            default="*.svg",
            options={'HIDDEN'},
            )
    filepath: StringProperty(subtype='FILE_PATH')
    merge_walls: BoolProperty(
        default=False,
        name="Merge wall",
        description="When enabled, merge walls. This is faster but less safe"
    )
    use_css: BoolProperty(
        default=False,
        name="Style using css",
        description="When enabled, use css class to define global styles"
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "merge_walls")
        layout.prop(self, "use_css")

    # def get_topmost_parent(self, o):
    #    if o.parent:
    #        return self.get_topmost_parent(o.parent)
    #    else:
    #        return o
    
    def get_dimensions(self, curves, dims):
        for name, c in curves.items():
            if c.data and "archipack_dimension_auto" in c.data:
                dims[name] = c

    def get_slabs(self, o, slabs):
        if o.data and "archipack_slab" in o.data:
            slabs.append(o)
        for c in o.children:
            self.get_slabs(c, slabs)

    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')
        t = time.time()
        result = {'FINISHED'}
        scene = context.scene
        context.window.cursor_set("WAIT")
        layout = context.active_object
        d = layout.data.archipack_layout[0]

        # TODO: start from reference points, sort by altitude

        curves = [
            o for o in scene.objects
            if o.type in {'CURVE', 'FONT'} and o.visible_get() and
               ("archipack_layout" not in o.data)
        ]

        # use manager to find curves in bounding box
        manager = ArchipackBoolManager()
        manager._init_bounding_box(layout)

        # exclude z filtering
        manager.mini.z = -1e32
        manager.maxi.z = 1e32
        manager.center.z = 0

        # retrieve archipack's entity
        # dimension are childs of wall
        walls = {
            o.name: o
            for o in scene.objects
            if o.data and
            "archipack_wall2" in o.data and
            manager._contains(o)
        }

        # get only one wall for each reference point
        found_walls = set()
        to_remove = set()
        for name, o in walls.items():
            if name in found_walls:
                continue
            found_walls.add(name)
            wd = o.data.archipack_wall2[0]
            childs = wd.find_walls(o)
            for c, cd in childs.items():
                found_walls.add(c.name)
                to_remove.add(c.name)

        if self.merge_walls:
            for name in to_remove:
                if name in walls:
                    del walls[name]

        stairs = [
            o for o in scene.objects
            if o.data and
            "archipack_stair" in o.data and o.visible_get() and
            manager._contains(o)
        ]

        beams = [
            o for o in scene.objects
            if o.data and
            "archipack_beam" in o.data and
            manager._contains(o)
        ]

        kitchen = [
            o for o in scene.objects
            if o.data and
               "archipack_kitchen" in o.data and o.visible_get() and
               manager._contains(o)
        ]

        # document size according layout (mm)
        width, height = d.paper_size
        # pixels / mm
        pixel_size = d.pixel_size
        w, h = d.canvas_size(context)

        # a matrix wich convert world coords
        # into paper coords pixels
        s = d.canvas_scale(context) / pixel_size
        tM = layout.matrix_world.copy()
        # tM[1][3] += Vector((0, h, 0))
        itM = (tM @ Matrix([
            [s, 0, 0, 0],
            [0, -s, 0, h],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
            ])).inverted()

        # filter curves found in layout
        curves = {o.name: o for o in curves if manager._contains(o) and o.name != layout.name}
        # print(curves)

        # remove dimension
        refs = {}
        for name, wall in walls.items():
            p = self.rec_get_parent(wall)
            refs[p.name] = p
        
        dims = {}
        self.get_dimensions(curves, dims)

        for name, dim in dims.items():
            if name in curves:
                del curves[name]
                for child in dim.children:
                    if child.type == 'FONT' and child.name in curves:
                        del curves[child.name]

        slabs = []
        for p in refs.values():
            self.get_slabs(p, slabs)

        # line width in mm
        line_width = 0.2 * pixel_size

        styles = {
            #               line_width        stroke    fill   css class name
            'wall': SVGStyle(line_width, "#000000", "#a0a0a0", "wall", use_css=self.use_css),
            'beam': SVGStyle(line_width, "#000000", "#a0a0a0", "beam", use_css=self.use_css),
            'hole': SVGStyle(line_width, "#000000", "#c0c0c0", "hole", use_css=self.use_css),
            'openings': SVGStyle(line_width, "#000000", "#FFFFFF", "openings", use_css=self.use_css),
            'stairs': SVGStyle(line_width, "#000000", "#FFFFFF", "stairs", use_css=self.use_css),
            'dims': SVGStyle(0.5 * line_width, "#000000", "#000000", "dims", use_css=self.use_css),
            'curves': SVGStyle(line_width, "#b5b5b5", "#e6e6e6", "curves", use_css=self.use_css),
            'kitchen': SVGStyle(line_width, "#b5b5b5", "#e6e6e6", "kitchen", use_css=self.use_css),
            'text': SVGStyle(line_width, "none", "#808080", "text", use_css=self.use_css),
            'slabs': SVGStyle(line_width, "#000000", "#FFFFFF", "slabs", use_css=self.use_css),
        }

        # walls with symbols
        svg_walls = [
            SVG_wall(self, context, itM, w, s, styles)
            for name, w in walls.items()
        ]

        if len(svg_walls) > 0:
            svg_walls = [
                SvgGroup("walls", svg_walls)
            ]

        # wall dimensions
        svg_dims = [
            SVG_dimensions(
                itM, dims.values(), s, styles['dims']
            )
        ]

        svg_slabs = [
            SVG_slabs(
                itM, context, slabs, styles['slabs']
            )
        ]

        # lines / text not part of walls
        svg_lines = []
        user_lines = []
        for curve in curves.values():

            # print(curve.name)

            # @TODO:
            # define color override as per curve object
            # with global default
            if curve.type == 'CURVE':
                style = styles['curves'].copy()

                if len(curve.material_slots) > 0 and curve.material_slots[0].material is not None:
                    mat = curve.material_slots[0].material
                    r, g, b = mat.diffuse_color[0:3]
                    style.stroke = rgb_to_hex((
                        int(r * 255),
                        int(g * 255),
                        int(b * 255)))
                    r, g, b = mat.specular_color[0:3]
                    style.fill = rgb_to_hex((
                        int(r * 255),
                        int(g * 255),
                        int(b * 255)))
                svg_path = SVG_blenderCurve(itM, curve, style, [])
                if svg_path is not None:
                    user_lines.append(svg_path)

        if len(user_lines) > 0:
            svg_lines.append(
                SvgGroup("lines", user_lines)
            )

        user_labels = []

        for curve in curves.values():
            tM = itM @ curve.matrix_world
            if curve.type == 'FONT':
                # define color override as per curve object
                # with global default
                style = styles['text'].copy()

                if len(curve.material_slots) > 0 and curve.material_slots[0].material is not None:
                    mat = curve.material_slots[0].material
                    r, g, b = mat.diffuse_color[0:3]
                    style.fill = rgb_to_hex((
                        int(r * 255),
                        int(g * 255),
                        int(b * 255)))

                # Export text
                user_labels.append(SvgText(tM, curve, s / curve.scale.x, style))

        if len(user_labels) > 0:
            svg_lines.append(
                SvgGroup("text", user_labels)
            )

        svg_stairs = []
        for stair in stairs:
            objman.select_object(context, stair, True)
            bpy.ops.archipack.stair_to_curve(mode="PLAN_2D")
            curve = context.active_object
            svg_path = SVG_blenderCurve(itM, curve, styles['stairs'], [], as_group=False)
            if svg_path is not None:
                svg_stairs.append(svg_path)
            objman.delete_object(context, curve)
            objman.unselect_object(context, stair)

        if len(svg_stairs) > 0:
            svg_stairs = [
                SvgGroup("Stairs", svg_stairs)
            ]

        svg_kitchen = []
        for k in kitchen:
            objman.select_object(context, k, True)
            bpy.ops.archipack.symbol_2d(join=True, hierarchy=True, sharp=True)
            curve = context.active_object
            svg_path = SVG_blenderCurve(itM, curve, styles['kitchen'], [], as_group=False)
            if svg_path is not None:
                svg_kitchen.append(svg_path)
            objman.delete_object(context, curve)
            objman.unselect_object(context, k)

        if len(svg_kitchen) > 0:
            svg_kitchen = [
                SvgGroup("Kitchen", svg_kitchen)
            ]

        svg_beams = []
        for beam in beams:
            if beam.matrix_world.col[2].z > 0.95:
                d = beam.data.archipack_beam[0]
                curve = d.as_2d(context, beam)
                svg_path = SVG_blenderCurve(itM, curve, styles['beam'], [], as_group=False)
                if svg_path is not None:
                    svg_beams.append(svg_path)
                objman.delete_object(context, curve)

        if len(svg_beams) > 0:
            svg_beams = [
                SvgGroup("Beams", svg_beams)
            ]

        # style template
        css_styles = "\n".join(
            [
                item.css_class_def()
                for key, item in styles.items()
            ]
        )

        # Open the file for writing
        with open(self.filepath, 'w') as f:
            f.write(XML_HEADER.format(
                width * pixel_size, height * pixel_size, layout.name, css_styles, DEFAULT_STYLES,
                width, height
            ))
            for slab in svg_slabs:
                f.write("%s" % slab)
            for line in svg_lines:
                f.write("%s" % line)
            for stair in svg_stairs:
                f.write("%s" % stair)
            for kitchen in svg_kitchen:
                f.write("%s" % kitchen)
            for beam in svg_beams:
                f.write("%s" % beam)
            for wall in svg_walls:
                if wall is not None:
                    f.write("%s" % wall)
            for dim in svg_dims:
                f.write("%s" % dim)
            f.write(XML_END)
        objman.select_object(context, layout, True)
        print("Archipack export svg complete %.4f seconds" % (time.time() - t))
        context.window.cursor_set("DEFAULT")
        return result

    # def invoke(self, context, event):
    #     if not self.filepath:
    #         self.filepath = bpy.path.ensure_ext(bpy.data.filepath, ".svg")
    #     wm = context.window_manager
    #     self.merge_walls = wm.archipack.svg_merge_walls
    #     wm.fileselect_add(self)
    #     return {'RUNNING_MODAL'}


# Register in File > Export menu
def menu_func_export(self, context):
    self.layout.operator(ARCHIPACK_OT_ExportSvg.bl_idname)


def register():
    bpy.utils.register_class(ARCHIPACK_OT_ExportSvg)
    # bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    import bpy
    # bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.utils.unregister_class(ARCHIPACK_OT_ExportSvg)
