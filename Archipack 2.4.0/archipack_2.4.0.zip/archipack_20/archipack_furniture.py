# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
import bpy
from uuid import uuid4
from math import pi
from mathutils import Vector, Matrix
# noinspection PyUnresolvedReferences
from bpy.types import Operator, PropertyGroup, Mesh, Panel, Object
from bpy.props import (
    FloatProperty, IntProperty, BoolProperty,
    CollectionProperty, EnumProperty, StringProperty, PointerProperty
)
from .bmesh_utils import BmeshEdit as bmed
from .archipack_preset import ArchipackPreset, PresetMenuOperator
from .archipack_abstraction import context_override, ensure_select_and_restore, Callbacks, X_AXIS, Y_AXIS
from .archipack_i18n import Archipacki18n
from .archipack_object import (
    ArchipackPanel,
    ArchipackObject,
    ArchipackCreateTool,
    ArchipackDrawTool,
    ArchipackArrayTool,
    update_source
    )
from .archipack_compound import Compound, CompoundPart
from .archipack_gl import FeedbackPanel
from .archipack_keymaps import Keymaps


def update(self, context):
    self.update(context)


class archipack_furniture_member(Archipacki18n, ArchipackObject, CompoundPart, PropertyGroup):

    source: PointerProperty(type=Object, update=update_source, name="", description="Source parent object")

    def update(self, context):
        if self.parent_data is not None:
            self.parent_data.update(context)

    @property
    def parent_data(self):
        if isinstance(self.id_data, Mesh):
            return self.id_data.archipack_furniture[0]
        return None
    
    def draw_member(self, context, layout, num):
        box = layout.box()
        row = box.row(align=True)
        row.prop(self, "source")
        self.draw_op(context, layout, row, "archipack.furniture_remove", icon='REMOVE', text="").index = num


class archipack_furniture(Archipacki18n, Compound, ArchipackObject, PropertyGroup):
    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('MAIN', 'Main', 'Display main settings', 'NONE', 0),
            ('MEMBERS', 'Members', 'Display members settings', 'NONE', 1),
        ),
        default='MAIN',
    )

    draw_target: EnumProperty(
        name="Draw target",
        description="Draw tool target objects",
        items=(
            ("WALL", "Wall", "Snap to walls", 0),
            ("FLOOR", "Floor", "Snap to floors / slabs", 1),
        ),
        default="FLOOR"
    )
    parts: CollectionProperty(type=archipack_furniture_member)

    symbol_scale: FloatProperty(name="Symbol scale", min=0.01, default=0.2, update=update)

    auto_update: BoolProperty(
            options={'SKIP_SAVE'},
            default=True,
            update=update
            )

    def get_member_datablock(self, o):
        return archipack_furniture_member.datablock(o)

    @property
    def _members_parts(self):
        return [part for part in self.parts if part.source is not None]

    def update(self, context):

        o = self.find_in_selection(context, self.auto_update)

        if o is None:
            return

        verts = [self.symbol_scale * Vector(p) for p in [
            (0.5, 0.5, 0.575), (0.5, 0.5, 0.424), (0.5, -0.5, 0.575),
            (0.5, -0.5, 0.424), (-0.5, 0.5, 0.575), (-0.5, 0.5, 0.424),
            (-0.5, -0.5, 0.575), (-0.5, -0.5, 0.424), (-0.5, 0.417, 0.424),
            (-0.5, -0.417, 0.424), (0.417, 0.5, 0.424), (-0.417, 0.5, 0.424),
            (-0.417, -0.5, 0.424), (0.417, -0.5, 0.424), (0.5, -0.417, 0.424),
            (0.5, 0.417, 0.424), (-0.417, 0.417, 0.424), (-0.417, -0.417, 0.424),
            (0.417, 0.417, 0.424), (0.417, -0.417, 0.424), (-0.5, -0.417, 0.0),
            (-0.5, -0.5, 0.0), (-0.417, 0.5, 0.0), (-0.5, 0.5, 0.0),
            (0.417, -0.5, 0.0), (0.5, -0.5, 0.0), (0.5, 0.417, 0.0),
            (0.5, 0.5, 0.0), (-0.5, 0.417, 0.0), (0.417, 0.5, 0.0),
            (-0.417, -0.5, 0.0), (0.5, -0.417, 0.0), (-0.417, -0.417, 0.0),
            (-0.417, 0.417, 0.0), (0.417, -0.417, 0.0), (0.417, 0.417, 0.0),
            (0.5, 0.242, 0.575), (-0.5, 0.242, 0.575), (-0.5, 0.242, 1.0),
            (-0.5, 0.5, 1.0), (0.5, 0.5, 1.0), (0.5, 0.242, 1.0),
            (0, 0, 0), (0, 0, 1),
        ]]

        edges = [
            (9, 7), (11, 5), (0, 1),
            (7, 6), (2, 3), (4, 5),
            (2, 6), (36, 2), (13, 3),
            (37, 4), (4, 0), (15, 1),
            (5, 8), (8, 9), (1, 10),
            (10, 11), (7, 12), (12, 13),
            (3, 14), (14, 15), (17, 12),
            (11, 16), (16, 17), (19, 13),
            (10, 18), (18, 19), (16, 8),
            (17, 9), (18, 16), (19, 17),
            (15, 18), (14, 19), (20, 21),
            (22, 23), (24, 25), (26, 27),
            (23, 28), (27, 29), (21, 30),
            (25, 31), (32, 30), (22, 33),
            (34, 24), (29, 35), (33, 28),
            (32, 20), (26, 35), (31, 34),
            (9, 20), (21, 7), (18, 35),
            (26, 15), (13, 24), (25, 3),
            (19, 34), (11, 22), (23, 5),
            (30, 12), (14, 31), (10, 29),
            (27, 1), (8, 28), (33, 16),
            (17, 32), (0, 36), (6, 37),
            (37, 36), (38, 39), (39, 40),
            (40, 41), (38, 41), (36, 41),
            (38, 37), (39, 4), (0, 40),
            (42, 43)
        ]
        bmed.buildmesh(o, verts, [], edges=edges)

        members = self.cleanup_members(context, o)

        for part in self.parts:

            if part.source is None:
                continue

            if part.part_uid not in members:

                new_c = self.duplicate_object(context, part.source, True)
                self.link_collections(o, new_c)
                # at object's level so assembly mesh remains linked parametric object
                d = new_c.archipack_furniture_member.add()
                d.source = part.source
                d.part_uid = part.part_uid
                new_c.parent = o
                new_c.matrix_world = o.matrix_world @ part.source.matrix_world
                self.safe_scale(new_c)

                for c in new_c.children:
                    if self.has_flag(c, ("hole", "custom_hole")):
                        # Always unlink hole data
                        c.data = c.data.copy()

        self.restore_context(context)


class ARCHIPACK_PT_furniture(ArchipackPanel, Archipacki18n, Panel):
    """Archipack Furniture"""
    bl_idname = "ARCHIPACK_PT_furniture"
    bl_label = "Furniture"

    @classmethod
    def poll(cls, context):
        return archipack_furniture.poll(context.active_object)

    def update(self, context):
        if self.auto_update:
            self.parent_data.update(context)

    def draw(self, context):
        o = context.active_object
        d = archipack_furniture.datablock(o)

        if d is None:
            return

        layout = self.layout

        self.draw_common(context, layout, draw_animation=False, draw_manipulate=False)

        row = layout.row(align=True)
        self.draw_op(context, layout, row, 'archipack.furniture', icon='FILE_REFRESH', text="Refresh").mode = 'REFRESH'
        if o.data.users > 1:
            self.draw_op(context, layout, row, 'archipack.furniture', icon='UNLINKED',
                         text="Make unique", postfix="({})".format(o.data.users)).mode = 'UNIQUE'

        box = layout.box()
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.furniture_preset_menu",
                     text=bpy.types.ARCHIPACK_OT_furniture_preset_menu.bl_label, icon="PRESET"
                     ).preset_operator = "archipack.preset_loader"
        self.draw_op(context, layout, row, "archipack.furniture_preset", icon='ADD', text="")
        self.draw_op(context, layout, row, "archipack.furniture_preset", icon='REMOVE', text="").remove_active = True

        self.draw_prop(context, layout, layout, d, 'tabs', expand=True)

        box = layout.box()
        if d.tabs == 'MAIN':
            self.draw_label(context, layout, box, text="Draw tool target")
            self.draw_prop(context, layout, box, d, "draw_target", text="")
            self.draw_prop(context, layout, box, d, "symbol_scale")
            
        elif d.tabs == 'MEMBERS':
            self.draw_op(context, layout, box, "archipack.furniture_add", icon='ADD', text="")

            for i, c in enumerate(d.parts):
                c.draw_member(context, layout, i)


class ARCHIPACK_PT_furniture_member(ArchipackPanel, Archipacki18n, Panel):
    """Archipack furniture"""
    bl_idname = "ARCHIPACK_PT_furniture_member"
    bl_label = "Furniture"

    @classmethod
    def poll(cls, context):
        return archipack_furniture_member.poll(context.active_object)

    def draw(self, context):
        o = context.active_object
        d = archipack_furniture_member.datablock(o)

        if d is None:
            return

        layout = self.layout
        self.draw_op(
            context, layout, layout, "archipack.select_parent", icon="RESTRICT_SELECT_OFF", text="Select Furniture"
        )


class ARCHIPACK_OT_furniture_add(Operator):
    bl_idname = "archipack.furniture_add"
    bl_label = "Add"
    bl_description = "Add member"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_furniture.datablock(o)
            if d is None:
                return {'CANCELLED'}
            p = d.parts.add()
            p.part_uid = str(uuid4())
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_furniture_remove(Operator):
    bl_idname = "archipack.furniture_remove"
    bl_label = "Remove"
    bl_description = "Remove"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_furniture.datablock(o)
            if d is None:
                return {'CANCELLED'}
            # d.manipulable_disable(o)
            d.parts.remove(self.index)
            d.update(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_furniture(ArchipackCreateTool, Operator):
    bl_idname = "archipack.furniture"
    bl_label = "Furniture"
    bl_description = "Create New empty Furniture at cursor location"
    mode: EnumProperty(
        items=(
            ('CREATE', 'Create', '', 0),
            ('REFRESH', 'Refresh', '', 2),
            ('UNIQUE', 'Make unique', '', 3),
        ),
        default='CREATE'
    )

    def create(self, context):
        o, m = self.create_mesh("Furniture")
        d = m.archipack_furniture.add()

        self.link_object_to_scene(context, o)
        o.color = (0, 1, 0, 1)

        # select and make active
        self.select_object(context, o, True)
        self.load_preset(context, o, d)
        self.hide_for_render_engines(o)
        return o

    def update(self, context):
        o = context.active_object
        d = archipack_furniture.datablock(o)
        if d is not None:
            for part in d.parts:
                part.part_uid = str(uuid4())
            d.update(context)
            linked_objects = self.get_linked_objects(context, o)
            # bpy.ops.object.select_linked(type='OBDATA')
            for linked in linked_objects:
                if linked != o:
                    archipack_furniture.datablock(linked).update(context)

        # bpy.ops.object.select_all(action="DESELECT")
        # select and make active
        # self.select_object(context, o, True)

    def unique(self, context):
        obj = context.active_object
        sel = context.selected_objects[:]
        uniques = []
        for o in sel:
            if archipack_furniture.filter(o):
                # select and make active
                Callbacks.call("unique", context, o, None)
                uniques.append(o)
                self.rec_get_childrens(o, uniques)

        if bool(uniques):
            bpy.ops.archipack.disable_manipulate()
            with ensure_select_and_restore(context, uniques[0], uniques):
                bpy.ops.object.make_single_user(
                    type='SELECTED_OBJECTS', object=True, obdata=True, material=False, animation=False
                )
            self.select_object(context, obj, True)
        # -----------------------------------------------------
        # Execute
        # -----------------------------------------------------

    def execute(self, context):
        if context.mode == "OBJECT":
            if self.mode == 'CREATE':
                sel = [o for o in context.selected_objects if o.parent is None]
                bpy.ops.object.select_all(action="DESELECT")
                o = self.create(context)
                o.location = self.get_cursor_location(context)
                # select and make active
                self.select_object(context, o, True)
                if len(sel) > 0:
                    d = archipack_furniture.datablock(o)
                    for o in sel:
                        m = d.parts.add()
                        m.source = o
                        m.part_uid = str(uuid4())
                    d.update(context)

            elif self.mode == 'REFRESH':
                self.update(context)
            elif self.mode == 'UNIQUE':
                self.unique(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_furniture_array(ArchipackArrayTool, Operator):
    bl_idname = "archipack.furniture_array"
    bl_label = "Furniture Array"
    bl_description = "Duplicate selected Furnitures"
    bl_options = {'UNDO'}

    # XXX crash on redo when using spinner values ..
    # bl_options = {'REGISTER', 'UNDO'}

    def filter_object(self, o):
        return archipack_furniture.filter(o)

    def get_object_datablock(self, o):
        return archipack_furniture.datablock(o)


class ARCHIPACK_OT_furniture_draw(ArchipackDrawTool, Operator):
    bl_idname = "archipack.furniture_draw"
    bl_label = "Draw Furnitures"
    bl_description = "Draw Furnitures"

    filepath: StringProperty(default="")
    feedback = None
    stack = []
    object_name = ""
    draw_target = "WALL"
    keymap = None
    _handle = None
    mini = Vector()
    maxi = Vector()
    center = Vector()
    snap_threshold = 0.5

    rotate_90 = 0

    @classmethod
    def poll(cls, context):
        return True

    def draw_callback(self, _self, context):
        self.feedback.draw(context)

    def add_object(self, context, event):

        bpy.ops.object.select_all(action="DESELECT")
        o = context.scene.objects.get(self.object_name)
        
        if self.filepath == '' and archipack_furniture.filter(o):
            o = self.duplicate_object(context, o, True)
            d = self.archipack_datablock(o)
            self.load_preset(context, o, d)
            self.select_object(context, o, True)

        else:
            bpy.ops.archipack.furniture(filepath=self.filepath)
            o = context.active_object


        if o is None:
            o = context.object

        d = self.archipack_datablock(o)
        self.draw_target = d.draw_target
        self.object_name = o.name
        # print("add_object bpy.ops.archipack.generate_hole")
        # bpy.ops.archipack.generate_hole()
        return o

    @staticmethod
    def remove_object(context, o):
        if archipack_furniture.filter(o):
            ctx = context.copy()
            ctx['object'] = o
            ctx['selected_objects'] = [o]
            bpy.ops.archipack.delete(ctx)

    def exit(self, context, o):
        self.remove_object(context, o)
        self.feedback.disable()
        try:
            context.space_data.show_gizmo = True
        except:
            pass
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

    def modal(self, context, event):

        o = self.get_scene_object(context, self.object_name)

        if o is None or context.area is None:
            self.exit(context, o)
            return {'FINISHED'}

        context.area.tag_redraw()

        d = archipack_furniture.datablock(o)

        to_hide = []
        self.rec_get_childrens(o, to_hide)

        for obj in to_hide:
            self.hide_object(obj)

        if self.draw_target == "WALL":
            res, tM, wall, width, y, z_offset = self.mouse_hover_wall(context, event)
        else:
            # Floor with ability to snap holding control
            res, tM, wall, width, y, z_offset = self.mouse_hover_floor(context, event, o, d)

        for obj in to_hide:
            self.show_object(obj)

        if event.value == 'PRESS':

            if event.type in {'C', 'D'}:
                self.exit(context, o)
                bpy.ops.archipack.furniture_preset_menu(
                    'INVOKE_DEFAULT',
                    preset_operator="archipack.furniture_draw")
                self.restore_walls(context)
                return {'FINISHED'}

            elif event.type in 'R':
                self.rotate_90 = (self.rotate_90 + (pi / 2)) % (2 * pi)
                tM = tM @ Matrix.Rotation(self.rotate_90, 4, "Z")

            if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'}:
                if wall is not None:
                    # o must be a Furniture here
                    if d is not None:
                        # self.select_object(context, o, True)
                        self.stack.append(o)

                        # link to reference
                        with context_override(context, wall, [o]) as ctx:
                            bpy.ops.archipack.add_reference_point(ctx)

                        o = self.add_object(context, event)
                        # copy current matrix to new object
                        o.matrix_world = tM

                    return {'RUNNING_MODAL'}

            # prevent selection of other object
            if event.type in {'RIGHTMOUSE'}:
                return {'RUNNING_MODAL'}

        if self.keymap.check(event, self.keymap.undo) or (
                event.type in {'BACK_SPACE'} and event.value == 'RELEASE'
        ):
            if len(self.stack) > 0:
                last = self.stack.pop()
                self.remove_object(context, last)
                # self.select_object(context, o, True)
            return {'RUNNING_MODAL'}

        if event.value == 'RELEASE':

            if event.type in {'ESC', 'RIGHTMOUSE'}:
                self.exit(context, o)
                self.restore_walls(context)

                return {'FINISHED'}

        if res and d is not None:
            o.matrix_world = tM

        return {'PASS_THROUGH'}

    def invoke(self, context, event):

        if context.mode == "OBJECT":
            o = context.active_object
            self.stack = []
            self.keymap = Keymaps(context)
            # exit manipulate_mode if any
            bpy.ops.archipack.disable_manipulate()

            # Hide manipulators
            context.space_data.show_gizmo = False

            # invoke with alt pressed will use current object as basis for linked copy
            if self.filepath == '' and archipack_furniture.filter(o):
                self.stack.append(o)
                o = self.duplicate_object(context, o, False)
                self.object_name = o.name
            else:
                o = self.add_object(context, event)

            d = archipack_furniture.datablock(o)
            self.draw_target = d.draw_target

            # select and make active
            bpy.ops.object.select_all(action="DESELECT")
            self.select_object(context, o, True)

            self.feedback = FeedbackPanel()
            instructions = [
                    ('LEFTCLICK, RET, SPACE, ENTER', 'Create a Furniture'),
                    ('BACKSPACE, CTRL+Z', 'undo last'),
                    ('D', 'Draw another Furniture'),
                    ('SHIFT', 'Make independant copy'),
                    ('RIGHTCLICK or ESC', 'exit')
            ]

            if self.draw_target == 'WALL':
                self.feedback.instructions(
                    context, "Draw a Furniture", "Click & Drag over a wall", instructions
                )
            else:
                instructions.insert(3, ('CTRL', 'Snap (hold)'))
                instructions.insert(3, ('R', 'Rotate 90°'))
                self.feedback.instructions(
                    context, "Draw a Furniture", "Click & Drag over a floor / slab", instructions
                )
            self.feedback.enable()
            args = (self, context)

            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


# ------------------------------------------------------------------
# Define operator class to load / save presets
# ------------------------------------------------------------------


class ARCHIPACK_OT_furniture_preset_draw(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and draw Furnitures"
    bl_idname = "archipack.furniture_preset_draw"
    bl_label = "Furniture Presets"
    preset_subdir = "archipack_furniture"


class ARCHIPACK_OT_furniture_preset_create(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and create standalone Furniture at cursor location"
    bl_idname = "archipack.furniture_preset_create"
    bl_label = "Furniture preset"
    preset_subdir = "archipack_furniture"


class ARCHIPACK_OT_furniture_preset_menu(PresetMenuOperator, Operator):
    bl_description = "Show Furnitures presets"
    bl_idname = "archipack.furniture_preset_menu"
    bl_label = "Furniture Presets"
    preset_subdir = "archipack_furniture"


class ARCHIPACK_OT_furniture_preset(ArchipackPreset, Operator):
    bl_description = "Add / remove a Furniture Preset"
    bl_idname = "archipack.furniture_preset"
    bl_label = "Furniture Preset"
    preset_menu = "ARCHIPACK_OT_furniture_preset_menu"

    def prepare_preset(self, context, o, preset):
        """Ensure that eve on copy of the object, uids are unique"""
        d = archipack_furniture.datablock(o)
        d.update_sources_uids(o)

    @property
    def blacklist(self):
        return ['member']


def register():
    bpy.utils.register_class(archipack_furniture_member)
    Object.archipack_furniture_member = CollectionProperty(type=archipack_furniture_member)
    bpy.utils.register_class(archipack_furniture)
    Mesh.archipack_furniture = CollectionProperty(type=archipack_furniture)
    bpy.utils.register_class(ARCHIPACK_PT_furniture)
    bpy.utils.register_class(ARCHIPACK_PT_furniture_member)
    bpy.utils.register_class(ARCHIPACK_OT_furniture)
    
    bpy.utils.register_class(ARCHIPACK_OT_furniture_add)
    bpy.utils.register_class(ARCHIPACK_OT_furniture_remove)
    bpy.utils.register_class(ARCHIPACK_OT_furniture_preset_menu)
    bpy.utils.register_class(ARCHIPACK_OT_furniture_preset_create)
    bpy.utils.register_class(ARCHIPACK_OT_furniture_preset_draw)
    bpy.utils.register_class(ARCHIPACK_OT_furniture_array)
    bpy.utils.register_class(ARCHIPACK_OT_furniture_preset)
    bpy.utils.register_class(ARCHIPACK_OT_furniture_draw)


def unregister():
    bpy.utils.unregister_class(archipack_furniture)
    del Mesh.archipack_furniture
    bpy.utils.unregister_class(archipack_furniture_member)
    del Object.archipack_furniture_member
    
    bpy.utils.unregister_class(ARCHIPACK_PT_furniture)
    bpy.utils.unregister_class(ARCHIPACK_PT_furniture_member)
    bpy.utils.unregister_class(ARCHIPACK_OT_furniture)
    bpy.utils.unregister_class(ARCHIPACK_OT_furniture_add)
    bpy.utils.unregister_class(ARCHIPACK_OT_furniture_remove)
    
    bpy.utils.unregister_class(ARCHIPACK_OT_furniture_preset_menu)
    bpy.utils.unregister_class(ARCHIPACK_OT_furniture_preset_create)
    bpy.utils.unregister_class(ARCHIPACK_OT_furniture_preset_draw)
    bpy.utils.unregister_class(ARCHIPACK_OT_furniture_array)
    bpy.utils.unregister_class(ARCHIPACK_OT_furniture_preset)
    bpy.utils.unregister_class(ARCHIPACK_OT_furniture_draw)
