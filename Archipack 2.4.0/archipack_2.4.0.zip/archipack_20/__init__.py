# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
bl_info = {
    'name': 'Archipack PRO',
    'description': 'Architectural objects and 2d polygons detection from unordered splines',
    'author': 's-leger support@blender-archipack.org',
    'license': 'GPL',
    'deps': '',
    'blender': (2, 80, 0),
    'version': (2, 4, 0),
    'revision': '1a1043d2622d4d93bd83abf4e3eeacfe',
    'location': 'View3D > Tools > Create > Archipack',
    'warning': '',
    'wiki_url': 'https://blender-archipack.gitlab.io/',
    'tracker_url': 'https://github.com/s-leger/archipack/issues/',
    'link': 'https://blender-archipack.org',
    'support': 'COMMUNITY',
    'category': 'Add Mesh'
    }

__version__ = ".".join([str(i) for i in bl_info['version']])


import os
import importlib as imp
from . import addon_updater_ops

submodules = (
    'prefs',
    'logging',
    'iconmanager',
    'material',
    'preset',
    'snap',
    'manipulator',
    'curveman',
    'throttle',
    'segments2',
    'dimension',
    'bendable',
    'reference_point',
    'autoboolean',
    'cutter',
    'handle',
    'door',
    'window',
    'stair',
    'wall',
    'wall2',
    'slab',
    'roof',
    'fence',
    'array',
    'truss',
    'custom',
    'floor',
    'ceiling',
    'blind',
    'kitchen',
    'molding',
    'beam',
    # 'rendering',   # Not needed anymore
    'animation',   # Disabled until context less branch is merged
    'section',
    'hole',
    'io',
    '2d_layout',
    'io_export_svg',
    'io_export_ifc',
    'io_dae',
    'polylines',
    'sun',
    'area',
    'terrain',
    'furniture',
    'assembly',
    'i18n',
    'py_deps_installer',
    'tools',
    'voile'
)

print("\n----------------------------------------------\n")

if "bpy" in locals():
    glob = globals()
    for sub in submodules:
        try:
            imp.reload(glob["archipack_{}".format(sub)])
        except Exception as ex:
            print("{} {}".format(bl_info['name'], __version__),
                  ": error while reloading {}\n{}".format(sub, ex),
                  "\n\n----------------------------------------------\n")
            # import traceback
            # traceback.print_exc()
            raise
    print("{} {}".format(bl_info['name'], __version__), ": reload ready",
          "\n\n----------------------------------------------\n")

else:
    glob = globals()
    for sub in submodules:
        try:
            glob["archipack_{}".format(sub)] = imp.import_module(".archipack_{}".format(sub), __package__)
        except Exception as ex:
            print("{} {}".format(bl_info['name'], __version__),
                  ": error while loading {}\n{}".format(sub, ex),
                  "\n\n----------------------------------------------\n")
            # import traceback
            # traceback.print_exc()
            raise

    print("{} {}".format(bl_info['name'], __version__), ": ready",
          "\n\n----------------------------------------------\n")


# noinspection PyUnresolvedReferences
import bpy
# noinspection PyUnresolvedReferences
from bpy.types import (
    Panel, AddonPreferences, Menu, PropertyGroup, Object, Collection
    )
from bpy.props import (
    StringProperty, BoolProperty, EnumProperty,
    IntProperty, FloatProperty,
    FloatVectorProperty, PointerProperty,
    CollectionProperty
    )
from bpy.utils import register_class, unregister_class
from .archipack_iconmanager import icons


def update_manipulate(self, context):
    """
    if self.auto_manipulate:
        #    bpy.ops.archipack.manipulate('INVOKE_DEFAULT')
        print("prefs.auto_manipulate enable")
    else:
        #    bpy.ops.archipack.disable_manipulate()
        print("prefs.auto_manipulate disable")
    """
    return


def get_matlib_path(self):
    return self.matlib_path


def set_matlib_path(self, value):
    abs_path = bpy.path.abspath(value)
    if os.path.exists(abs_path):
        self.matlib_path = abs_path
    else:
        self.matlib_path = ""
    return None


# ----------------------------------------------------
# Addon preferences
# ----------------------------------------------------

def register_translation(self, context):
    try:
        unregister_class(archipack_i18n.ARCHIPACK_PT_translation)
    except:
        pass
    if context.preferences.addons[__name__].preferences.translate:
        archipack_i18n.ARCHIPACK_PT_translation.bl_category = "Translate Archipack"
        register_class(archipack_i18n.ARCHIPACK_PT_translation)


def update_panel(self, context):
    try:
        unregister_class(TOOLS_PT_Archipack_PolyLib)
        unregister_class(TOOLS_PT_Archipack_Tools)
        unregister_class(TOOLS_PT_Archipack_Create)
        unregister_class(TOOLS_PT_Archipack_Create_2d)
        unregister_class(TOOLS_PT_Archipack_Create_Custom)
        unregister_class(TOOLS_PT_Archipack_About)
    except:
        pass

    prefs = context.preferences.addons[__name__].preferences
    TOOLS_PT_Archipack_Create.bl_category = prefs.create_category
    register_class(TOOLS_PT_Archipack_Create)
    TOOLS_PT_Archipack_Create_2d.bl_category = prefs.create_category
    register_class(TOOLS_PT_Archipack_Create_2d)
    TOOLS_PT_Archipack_Create_Custom.bl_category = prefs.create_category
    register_class(TOOLS_PT_Archipack_Create_Custom)
    TOOLS_PT_Archipack_Tools.bl_category = prefs.tools_category
    register_class(TOOLS_PT_Archipack_Tools)
    TOOLS_PT_Archipack_PolyLib.bl_category = prefs.tools_category
    register_class(TOOLS_PT_Archipack_PolyLib)
    TOOLS_PT_Archipack_About.bl_category = prefs.create_category
    register_class(TOOLS_PT_Archipack_About)

    glob = globals()
    for sub in submodules:
        module = glob["archipack_{}".format(sub)]
        for attr in dir(module):
            if attr.startswith("ARCHIPACK_PT_"):
                panel = getattr(module, attr)
                try:
                    unregister_class(panel)
                except:
                    pass
                panel.bl_category = prefs.objects_category
                register_class(panel)


class archipack_wm(PropertyGroup):
    bl_idname = "archipack.wm"
    bl_label = "Archipack"

    auto_manipulate: BoolProperty(
        name="Auto manipulate",
        description="Auto enable Manipulators on select",
        update=update_manipulate,
        default=True
    )
    update_cursor: BoolProperty(
        name="Update cursor",
        description="Change cursor when updating",
        default=True
    )

    polylib: PointerProperty(type=archipack_polylines.archipack_polylib)
    # sun locations ui list
    sun: PointerProperty(type=archipack_sun.archipack_sun_presets)
    translation: PointerProperty(type=archipack_i18n.archipack_translation)
    # collection boolean
    collection: PointerProperty(type=Collection, name="Collection")
    slice_obj: PointerProperty(type=Object, name="Object")


def update_logger(self, context):
    from .archipack_logging import debug_level
    debug_level(self.debug_level)


class archipack_shortcut(archipack_i18n.Archipacki18n, PropertyGroup):
    name: StringProperty(name="name", default="event")
    label: StringProperty(name="name", default="Event")
    key: StringProperty(name="key", default="")
    alt: BoolProperty(default=False, name="alt")
    shift: BoolProperty(default=False, name="shift")
    ctrl: BoolProperty(default=False, name="ctrl")

    def draw(self, context, layout):
        row=layout.row(align=True)
        self.draw_prop(context, layout, row, self, "label", text="")
        self.draw_prop(context, layout, row, self, "key")
        self.draw_prop(context, layout, row, self, "alt")
        self.draw_prop(context, layout, row, self, "shift")
        self.draw_prop(context, layout, row, self, "ctrl")

    def __str__(self):
        key = ""
        if self.ctrl:
            key += 'CTRL+'
        if self.alt:
            key += 'ALT+'
        if self.shift:
            key += 'SHIFT+'
        return "%s (%s%s)" % (self.label, key, self.key)

    @property
    def event_signature(self):
        key = self.key
        if self.ctrl:
            key += '+CTRL'
        if self.alt:
            key += '+ALT'
        if self.shift:
            key += '+SHIFT'
        return [{'type': key, 'name': self.name, 'event': (self.alt, self.ctrl, self.shift, self.key, "PRESS")}]


class Archipack_Pref(archipack_i18n.Archipacki18n, AddonPreferences):
    bl_idname = __name__

    shortcuts: CollectionProperty(type=archipack_shortcut)

    tools_category: StringProperty(
        name="Tools",
        description="Choose a name for the category of the Tools panel",
        default="Tools",
        update=update_panel
    )
    create_category: StringProperty(
        name="Create",
        description="Choose a name for the category of the Create panel",
        default="Create",
        update=update_panel
    )
    objects_category: StringProperty(
        name="Objects",
        description="Choose a name for the category of Objects paremeters panel",
        default="Archipack",
        update=update_panel
    )
    create_submenu: BoolProperty(
        name="Use Sub-menu",
        description="Put Achipack's object into a sub menu (shift+a)",
        default=True
    )
    max_style_draw_tool: BoolProperty(
        name="Draw tool using click & drag",
        description="Draw tools behavior\n"\
        "When on, use clic & drag + release to create segments, view rotation / manipulate allowed while drawing\n"\
        "When off use continous clicks to create new segment, view rotation / manipulate are not available",
        default=True
    )
    draw_wall_tool_direction: EnumProperty(
        name="Draw wall tool direction",
        description="Draw wall tool direction",
        items=(
            ('CCW', "Couterclockwise", "Draw in Couterclockwise order", 0),
            ('CW', "Clockwise", "Draw in Clockwise order", 1)
        ),
        default='CCW'
    )
    split_path_small_handle: BoolProperty(
        name="Simplify path manipulator display",
        description="Display path manipulator as single small line",
        default=False
    )
    # split_path_shortcut: StringProperty(
    #     name="Split path shortcut",
    #     default="S"
    # )
    # add_path_shortcut: StringProperty(
    #     name="Add segment shortcut",
    #     default="A"
    # )
    enable_vertex_colors: BoolProperty(
        name="Use vertex colors",
        description="When enabled, use vertex colors as random source for materials",
        default=True
    )
    throttle_enable: BoolProperty(
        name="Quick edit",
        description="When enabled, prevent complex objects to update in real time",
        default=True
    )
    throttle_delay: IntProperty(
        name="Delay",
        description="Quick edit, how much time to wait before updating complex objects (seconds)",
        default=1
    )

    draw_tool_ortho: BoolProperty(
        name="Draw tool mode ortho",
        description="Use automatic ortho snap in draw tools",
        default=True
    )
    # Arrow sizes (world units)
    step_angle: EnumProperty(
        name="Draw tool step angle",
        description="Angle steps to snap for draw tool in ortho mode",
        items=(
            ("1", "1 degree", "snap steps of 1 degree"),
            ("5", "5 degree", "snap steps of 5 degree"),
            ("10", "10 degree", "snap steps of 10 degree"),
            ("15", "15 degree", "snap steps of 15 degree"),
            ("30", "30 degree", "snap steps of 30 degree"),
            ("45", "45 degree", "snap steps of 45 degree"),
            ("90", "90 degree", "snap steps of 90 degree"),
        ),
        default="15"
    )
    # Step distance     (size, divider)
    step_dist: EnumProperty(
        name="Draw tool step distance",
        description="Distance steps to snap for draw tool in ortho mode",
        items=(
            ("0.1,10", "Metric 10 / 1 cm", "snap steps of 10 cm / 1 cm"),
            ("0.3048,12", "Imperial 1 foot / 1 inch", "snap steps of 1 foot / 1 inch"),
        ),
        default="0.1,10"
    )
    # Arrow sizes (world units)
    arrow_size: FloatProperty(
        name="Arrow (bu)",
        description="Manipulators global handle size (blender units)",
        default=0.05,
        min=0.001
    )
    # Handle area size (pixels)
    handle_size: IntProperty(
        name="Handle (px)",
        description="Manipulators handle sensitive area size (pixels) and symbol size when constant size is enabled",
        min=2,
        default=10
    )
    symbol_size: IntProperty(
        name="Arrow (px)",
        description="Manipulators handle maximum size when constant (pixels)",
        min=2,
        default=10
    )
    thumbsize: IntProperty(
        name="Preset thumbs",
        description="Preset thumbs size (pixels)",
        min=50,
        default=150
    )
    constant_handle_size: BoolProperty(
        name="Constant handle size",
        description="When checked, handle size on scree remains constant (symbol size pixels)",
        default=True
    )

    text_size: IntProperty(
        name="Text (px)",
        description="Manipulator font size (pixels)",
        min=2,
        default=14
    )
    handle_colour_selected: FloatVectorProperty(
        name="Selected handle colour",
        description="Handle color when selected",
        subtype='COLOR_GAMMA',
        default=(0.0, 0.0, 0.7, 0.75),
        size=4,
        min=0, max=1
    )
    handle_colour_inactive: FloatVectorProperty(
        name="Inactive handle colour",
        description="Handle color when disabled",
        subtype='COLOR_GAMMA',
        default=(0.3, 0.3, 0.3, 0.75),
        size=4,
        min=0, max=1
    )
    handle_colour_normal: FloatVectorProperty(
        name="Handle colour normal",
        description="Base handle color when not selected",
        subtype='COLOR_GAMMA',
        default=(1.0, 1.0, 1.0, 0.75),
        size=4,
        min=0, max=1
    )
    handle_colour_hover: FloatVectorProperty(
        name="Handle colour hover",
        description="Handle color when mouse hover",
        subtype='COLOR_GAMMA',
        default=(1.0, 1.0, 0.0, 0.75),
        size=4,
        min=0, max=1
    )
    handle_colour_active: FloatVectorProperty(
        name="Handle colour active",
        description="Handle colour when moving",
        subtype='COLOR_GAMMA',
        default=(1.0, 0.0, 0.0, 0.75),
        size=4,
        min=0, max=1
    )
    matlib_path: StringProperty(
        name="Folder path",
        description="Absolute path to material library folder",
        default=""
    )
    # Ensure path is absolute whatever user set
    matlib_path_ui: StringProperty(
        name="Folder path",
        subtype="DIR_PATH",
        description="Absolute path to material library folder",
        default="",
        get=get_matlib_path,
        set=set_matlib_path
    )
    debug_level: EnumProperty(
        name="Debug level",
        description="Set debug log level",
        items=(
            ('ERROR', "Error", "Enable error only, this is the less verbose option"),
            ('WARNING', "Warning", "Enable warning log, less verbose than info"),
            ('INFO', 'Info', 'Enable info log, this is default option'),
            ('DEBUG', 'Debug', 'Enable debug log, this is the most verbose option')
        ),
        default='WARNING',
        update=update_logger
    )

    auto_synch: BoolProperty(
        default=False,
        name="Auto synchro",
        description="Synchronize child objects"
    )

    # Font sizes and basic colour scheme
    # kept outside of addon prefs until now
    # as for a generic toolkit it is not appropriate
    # we could provide a template for addon prefs
    # matching those one
    feedback_size_main: IntProperty(
        name="Main",
        description="Main title font size (pixels)",
        min=2,
        default=16
    )
    feedback_size_title: IntProperty(
        name="Title",
        description="Tool name font size (pixels)",
        min=2,
        default=14
    )
    feedback_size_shortcut: IntProperty(
        name="Shortcut",
        description="Shortcuts font size (pixels)",
        min=2,
        default=11
    )
    feedback_shortcut_area: FloatVectorProperty(
        name="Background Shortcut",
        description="Shortcut area background color",
        subtype='COLOR_GAMMA',
        default=(0, 0.4, 0.6, 0.2),
        size=4,
        min=0, max=1
    )
    feedback_title_area: FloatVectorProperty(
        name="Background Main",
        description="Title area background color",
        subtype='COLOR_GAMMA',
        default=(0, 0.4, 0.6, 0.5),
        size=4,
        min=0, max=1
    )
    feedback_colour_main: FloatVectorProperty(
        name="Font Main",
        description="Title color",
        subtype='COLOR_GAMMA',
        default=(0.95, 0.95, 0.95, 1.0),
        size=4,
        min=0, max=1
    )
    feedback_colour_key: FloatVectorProperty(
        name="Font Shortcut key",
        description="KEY label color",
        subtype='COLOR_GAMMA',
        default=(0.67, 0.67, 0.67, 1.0),
        size=4,
        min=0, max=1
    )
    feedback_colour_shortcut: FloatVectorProperty(
        name="Font Shortcut hint",
        description="Shortcuts text color",
        subtype='COLOR_GAMMA',
        default=(0.51, 0.51, 0.51, 1.0),
        size=4,
        min=0, max=1
    )
    experimental_features: BoolProperty(
        name="Experimental features",
        description="Enable experimental features (may be unstable)",
        default=False
    )

    translate: BoolProperty(
        name="Enable translation",
        default=False,
        update=register_translation
    )
    support_animation: BoolProperty(
        name="Support for Animation",
        description="If enabled, provide limited animation support",
        default=False,
    )
    auto_check_update : BoolProperty(
        name="Auto-check for Update",
        description="If enabled, auto-check for updates using an interval",
        default=False,
    )
    updater_intrval_months : IntProperty(
        name='Months',
        description="Number of months between checking for updates",
        default=0,
        min=0
    )
    updater_intrval_days : IntProperty(
        name='Days',
        description="Number of days between checking for updates",
        default=7,
        min=0,
        max=31
    )
    updater_intrval_hours : IntProperty(
        name='Hours',
        description="Number of hours between checking for updates",
        default=0,
        min=0,
        max=23
    )
    updater_intrval_minutes : IntProperty(
        name='Minutes',
        description="Number of minutes between checking for updates",
        default=0,
        min=0,
        max=59
    )


    def draw(self, context):
        layout = self.layout
        self.draw_translate(context, layout)

        box = layout.box()
        self.draw_label(context, layout, box, "Material library:")
        self.draw_prop(context, layout, box, self, "matlib_path_ui")
        # self.draw_op(context, layout, box, "archipack.render_thumbs")
        box = layout.box()
        row = box.row()
        col = row.column()
        self.draw_label(context, layout, col, "Tab Category:")
        self.draw_prop(context, layout, col, self, "tools_category")
        self.draw_prop(context, layout, col, self, "create_category")
        self.draw_prop(context, layout, col, self, "objects_category")
        self.draw_prop(context, layout, col, self, "create_submenu")

        box = layout.box()
        self.draw_label(context, layout, box, "Features")

        row = box.row()
        self.draw_prop(context, layout, row, self,"throttle_enable")
        self.draw_prop(context, layout, row, self,"throttle_delay")
        # self.draw_prop(context, layout, box, self, "auto_save")
        self.draw_prop(context, layout, box, self, "max_style_draw_tool")
        self.draw_prop(context, layout, box, self, "enable_vertex_colors")
        self.draw_prop(context, layout, box, self, "support_animation")

        row = box.row(align=True)
        self.draw_label(context, layout, row, "Draw wall direction")
        self.draw_prop(context, layout, row, self, "draw_wall_tool_direction", text="")

        box = layout.box()
        self.draw_prop(context, layout, box, self, "draw_tool_ortho")
        self.draw_prop(context, layout, box, self, "step_angle")
        self.draw_prop(context, layout, box, self, "step_dist")

        box = layout.box()
        self.draw_label(context, layout, box, "Path manipulator")

        for short in self.shortcuts:
            short.draw(context, box)
        self.draw_prop(context, layout, box, self, "split_path_small_handle")

        # box = layout.box()
        # self.draw_prop(context, layout, box, self, "split_path_shortcut")
        # self.draw_prop(context, layout, box, self, "add_path_shortcut")

        box = layout.box()
        row = box.row(align=True)
        self.draw_label(context, layout, row, "Debug log")
        self.draw_prop(context, layout, row, self, "debug_level", text="")

        box = layout.box()
        self.draw_prop(context, layout, box, self, "experimental_features")

        if self.experimental_features:
            self.draw_label(context, layout, box, "Setup python modules")

            HAS_SCIPY = False
            try:
                import scipy
                HAS_SCIPY = True
            except ImportError:
                pass

            if HAS_SCIPY:
                self.draw_op(context, layout, box,
                            "archipack.uninstall_python_module",
                            text="Uninstall Scipy (boost terrain ~18x faster)"
                            ).module = "scipy"
            else:
                numpy_version = "missing"

                try:
                    import numpy as np
                    numpy_version = np.version.version
                except ImportError:
                    pass

                try:
                    # see https://scipy.scipy.org/past-news.html for matching releases
                    # map numpy -> scipy versions
                    scipy_version = {
                        "1.17.0": "1.2.1",  # blender 2.82+
                        "1.17.5": "1.4.1",  # blender 2.90+
                        "1.19.5": "1.6.1",  # blender 2.93 - 3.0 alpha
                    }[numpy_version]
                    self.draw_op(context, layout, box,
                                "archipack.install_python_module",
                                text="Install Scipy (boost terrain ~18x faster)"
                                ).module = "scipy==%s" % scipy_version
                except KeyError:
                    pass

        box = layout.box()
        self.draw_label(context, layout, box, "Translate archipack on screen")
        self.draw_prop(context, layout, box, self, "translate")
        if self.translate:
            self.draw_op(context, layout, box, "wm.path_open", text="Find translation file"
                         ).filepath="{}".format(os.path.join(os.path.dirname(__file__), "lang"))
            self.draw_op(context, layout, box, "wm.url_open",
                         text="Send translation files to translation@blender-archipack.org"
                         ).url = "mailto:translations@blender-archipack.org?subject=Translation%20{}".format(
                context.preferences.view.language
            )

        box = layout.box()
        row = box.row()
        split = row.split(factor=0.5)
        col = split.column()
        self.draw_label(context, layout, col, "Colors:")
        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"feedback_title_area")
        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"feedback_shortcut_area")
        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"feedback_colour_main")
        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"feedback_colour_key")
        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"feedback_colour_shortcut")

        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"handle_colour_normal")
        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"handle_colour_hover")
        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"handle_colour_active")
        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"handle_colour_selected")
        row = col.row(align=True)
        self.draw_prop(context, layout, row, self,"handle_colour_inactive")

        col = split.column()
        self.draw_label(context, layout, col, "Font size:")
        self.draw_prop(context, layout, col, self, "feedback_size_main")
        self.draw_prop(context, layout, col, self, "feedback_size_title")
        self.draw_prop(context, layout, col, self, "feedback_size_shortcut")
        self.draw_label(context, layout, col, "Manipulators")
        self.draw_prop(context, layout, col, self, "text_size")
        self.draw_prop(context, layout, col, self, "handle_size")
        self.draw_prop(context, layout, col, self, "constant_handle_size")
        self.draw_prop(context, layout, col, self, "symbol_size")
        self.draw_prop(context, layout, col, self, "arrow_size")
        self.draw_prop(context, layout, col, self, "thumbsize")

        addon_updater_ops.update_settings_ui(self, context)
        # addon_updater_ops.update_settings_ui_condensed(self, context, col)


# ----------------------------------------------------
# Archipack panels
# ----------------------------------------------------

class TOOLS_PT_Archipack_PolyLib(archipack_i18n.Archipacki18n, Panel):
    bl_label = "2d to 3d"
    bl_idname = "TOOLS_PT_Archipack_PolyLib"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    bl_category = "Tools"
    bl_context = "objectmode"

    @classmethod
    def poll(cls, context):

        global archipack_polylines
        return ((archipack_polylines.vars_dict['select_polygons'] is not None) or
                (context.object is not None and context.object.type == 'CURVE'))

    def draw(self, context):

        layout = self.layout
        self.draw_translate(context, layout)

        params = context.window_manager.archipack.polylib
        row = layout.row(align=True)
        box = row.box()
        row = box.row(align=True)
        if params.polygonize_expand:
            self.draw_prop(context, layout, row, params, "polygonize_expand", icon='TRIA_DOWN', text="")
        else:
            self.draw_prop(context, layout, row, params, "polygonize_expand", icon='TRIA_RIGHT', text="")

        self.draw_op(context, layout, row,
            "archipack.polylib_polygonize",
            icon_value=icons["detect"].icon_id,
            text='Detect'
            )

        if params.polygonize_expand:
            self.draw_prop(context, layout, box, params, "polygonize_bezier_resolution")
            self.draw_prop(context, layout, box, params, "polygonize_extend")
            self.draw_prop(context, layout, box, params, "polygonize_all_segs")

            self.draw_op(context, layout, box,
                "archipack.polylib_pick_2d_polygons",
                icon_value=icons["selection"].icon_id,
                text='Polygons'
                )

            self.draw_op(context, layout, box,
                "archipack.polylib_pick_2d_lines",
                icon_value=icons["selection"].icon_id,
                text='Lines'
                )

            self.draw_op(context, layout, box,
                "archipack.polylib_pick_2d_points",
                icon_value=icons["selection"].icon_id,
                text='Points'
                )

            self.draw_label(context, layout, box, "Walls")
            self.draw_prop(context, layout, box, params, "polygonize_height")
            self.draw_prop(context, layout, box, params, "polygonize_thickness")

        row = layout.row(align=True)
        box = row.box()
        row = box.row(align=True)
        if params.simplify_expand:
            self.draw_prop(context, layout, row, params, "simplify_expand", icon='TRIA_DOWN', text="")
        else:
            self.draw_prop(context, layout, row, params, "simplify_expand", icon='TRIA_RIGHT', text="")
        self.draw_op(context, layout, row, "archipack.polylib_simplify")
        if params.simplify_expand:
            self.draw_prop(context, layout, box, params, "simplify_bezier_resolution")
            self.draw_prop(context, layout, box, params, "simplify_tolerance")
            self.draw_prop(context, layout, box, params, "simplify_preserve_topology")

        row = layout.row(align=True)
        box = row.box()
        row = box.row(align=True)
        if params.offset_expand:
            self.draw_prop(context, layout, row, params, "offset_expand", icon='TRIA_DOWN', text="")
        else:
            self.draw_prop(context, layout, row, params, "offset_expand", icon='TRIA_RIGHT', text="")
        self.draw_op(context, layout, row, "archipack.polylib_offset")
        if params.offset_expand:
            self.draw_prop(context, layout, box, params, "offset_bezier_resolution")
            self.draw_prop(context, layout, box, params, "offset_distance")
            self.draw_prop(context, layout, box, params, "offset_side")
            self.draw_prop(context, layout, box, params, "offset_resolution")
            self.draw_prop(context, layout, box, params, "offset_join_style")
            self.draw_prop(context, layout, box, params, "offset_mitre_limit")

        row = layout.row(align=True)
        box = row.box()
        row = box.row(align=True)
        if params.buffer_expand:
            self.draw_prop(context, layout, row, params, "buffer_expand", icon='TRIA_DOWN', text="")
        else:
            self.draw_prop(context, layout, row, params, "buffer_expand", icon='TRIA_RIGHT', text="")
        self.draw_op(context, layout, row, "archipack.polylib_buffer")
        if params.buffer_expand:
            self.draw_prop(context, layout, box, params, "buffer_bezier_resolution")
            self.draw_prop(context, layout, box, params, "buffer_distance")
            self.draw_prop(context, layout, box, params, "buffer_side")
            self.draw_prop(context, layout, box, params, "buffer_resolution")
            self.draw_prop(context, layout, box, params, "buffer_join_style")
            self.draw_prop(context, layout, box, params, "buffer_cap_style")
            self.draw_prop(context, layout, box, params, "buffer_mitre_limit")

        row = layout.row(align=True)
        box = row.box()
        row = box.row(align=True)
        if params.boolean_expand:
            self.draw_prop(context, layout, row, params, "boolean_expand", icon='TRIA_DOWN', text="")
        else:
            self.draw_prop(context, layout, row, params, "boolean_expand", icon='TRIA_RIGHT', text="")
        self.draw_label(context, layout, row, "2d Boolean")
        if params.boolean_expand:
            self.draw_op(context, layout, box, "archipack.polylib_boolean", text="Active - Selected").opCode = 'DIFFERENCE'
            self.draw_op(context, layout, box, "archipack.polylib_boolean", text="Selected - Active").opCode = 'REVDIFFERENCE'
            self.draw_op(context, layout, box, "archipack.polylib_boolean", text="Intersection").opCode = 'INTERSECTION'
            self.draw_op(context, layout, box, "archipack.polylib_boolean", text="Union").opCode = 'UNION'
            self.draw_op(context, layout, box, "archipack.polylib_boolean", text="SymDifference").opCode = 'SYMDIFFERENCE'
            self.draw_prop(context, layout, box, params, "boolean_bezier_resolution")


class TOOLS_PT_Archipack_Tools(archipack_i18n.Archipacki18n, Panel):
    bl_label = "Tools"
    bl_idname = "TOOLS_PT_Archipack_Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    bl_category = "Tools"
    bl_context = "objectmode"

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        prefs = context.preferences.addons[__name__].preferences
        layout = self.layout
        self.draw_translate(context, layout)

        box = layout # .box()

        if prefs.support_animation and "archipack_animation" in globals():

            self.draw_label(context, layout, box, "Animation")
            row = box.row(align=True)
            self.draw_op(context, layout, row, "archipack.animation_add", text="", icon="ADD")
            self.draw_op(context, layout, row, "archipack.animation_remove", text="", icon="REMOVE")
            icon = "HIDE_ON"
            if context.scene.archipack_animation:
                icon = "HIDE_OFF"
            self.draw_prop(context, layout, row, context.scene, "archipack_animation", icon=icon)
            self.draw_op(
                context, layout, row, "archipack.animation_render", text="Render animation", icon="RENDER_ANIMATION"
            )

        self.draw_label(context, layout, box, "Auto Boolean")
        self.draw_op(context, layout, box, "archipack.auto_boolean", text="Auto Boolean", icon='AUTO')
        self.draw_label(context, layout, box, "Apply holes")
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.apply_holes", text="selected").selected_only = True
        self.draw_op(context, layout, row, "archipack.apply_holes", text="all").selected_only = False
        self.draw_op(context, layout, box, "archipack.fix_hole_visibility")

        self.draw_label(context, layout, box, "Remove references")
        row = box.row(align=True)
        self.draw_op(
            context, layout, row, "archipack.remove_references", text="selected", icon="ERROR"
        ).selected_only = True
        self.draw_op(
            context, layout, row, "archipack.remove_references", text="all", icon="ERROR"
        ).selected_only = False

        # box = layout.box()
        self.draw_label(context, layout, box, "Kill parameters")
        row = box.row(align=True)
        self.draw_op(
            context, layout, row, "archipack.kill_archipack", text="selected", icon="ERROR"
        ).selected_only = True
        self.draw_op(
            context, layout, row, "archipack.kill_archipack", text="all", icon="ERROR"
        ).selected_only = False

        self.draw_label(context, layout, box, "Triangulate")
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.convert_all_to_tris", icon="MOD_TRIANGULATE")

        self.draw_label(context, layout, box, "Uvs")
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.apply_random_uv", icon="UV")

        self.draw_label(context, layout, box, "Vertex colors")
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.remove_vertex_colors", icon="GROUP_VCOL")

        self.draw_label(context, layout, box, "Custom Utility")
        self.draw_op(context, layout, box, "archipack.center_to_world", text="Center to world")
        self.draw_op(context, layout, box, "archipack.merge_and_dissolve", text="Merge and clean")

        self.draw_label(context, layout, box, "2d Utility")
        self.draw_op(context, layout, box, "archipack.symbol_2d", text="Create 2d symbol")

        try:
            bpy.ops.archipack.ifc_structure.get_rna_type()
            self.draw_label(context, layout, box, "IFC for use with blenderBIM")
            row = box.row(align=True)
            self.draw_op(context, layout, row, "archipack.ifc_structure")
            self.draw_op(context, layout, row, "archipack.ifc_structure_remove")
        except KeyError:
            pass


class TOOLS_PT_Archipack_About(archipack_i18n.Archipacki18n, Panel):
    bl_label = "About"
    bl_idname = "TOOLS_PT_Archipack_About"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    bl_category = "Create"
    bl_context = "objectmode"

    def draw(self, context):

        layout = self.layout
        box = layout.box()
        box.label(text="Archipack {}".format(__version__))
        box.label(text="by Stephen Leger")

        box = layout.box()

        self.draw_op(context, layout, box, "wm.url_open",
                     text="Video tutorial", icon="URL"
                     ).url = "https://youtube.com/stephen_leger/videos"
        self.draw_op(context, layout, box, "wm.url_open",
                     text="Documentation", icon="URL"
                     ).url = "https://blender-archipack.gitlab.io"
        self.draw_op(context, layout, box, "wm.url_open",
                     text="Report a bug", icon="URL"
                     ).url = "blender-archipack.org/archipack-bugreport.php?u=sync@gmail.com"
        self.draw_op(context, layout, box, "wm.url_open",
                     text="Contact support", icon="URL"
                     ).url = "mailto:support@blender-archipack.org?subject=Archipack {} - {}".format(
            __version__, "sync@gmail.com"
        )
        self.draw_op(context, layout, box, "wm.url_open",
                     text="Get update link by e-mail", icon="URL"
                     ).url = "blender-archipack.org/archipack/update?u=sync@gmail.com"
        self.draw_op(context, layout, box, "wm.url_open",
                     text="Get beta link by e-mail", icon="URL"
                     ).url = "blender-archipack.org/archipack/beta?u=sync@gmail.com"

        addon_updater_ops.update_settings_ui_condensed(self, context, box)

        box = layout.box()
        box.label(text="Internationalization")
        row=box.row(align=True)

        # international char support enabled
        # Fix for 2.9x breaking api
        international = True # context.preferences.view.use_international_fonts

        row.label(text="Chinese")
        if international:
            text="只剩一瓶辣椒酱"
        else:
            text="Xiao Cui"
        row.label(text=text)

        row=box.row(align=True)
        row.label(text="French")
        row.label(text="Stephen Leger")

        row = box.row(align=True)
        row.label(text="Spanish (Spain)")
        row.label(text="Sara González")

        row = box.row(align=True)
        row.label(text="Italian")
        row.label(text="Luca Pierantozzi")

        # row = box.row(align=True)
        # row.label(text="Polish")
        # row.label(text="")
        #
        row = box.row(align=True)
        row.label(text="German")
        row.label(text="Martin Bornschein")

        row = box.row(align=True)
        row.label(text="Russian")
        if international:
            text="Демид Волк"
        else:
            text="Demid Wolf"
        row.label(text=text)

        row = box.row(align=True)
        row.label(text="Turkish")
        row.label(text="Erdem Keskin")


class TOOLS_PT_Archipack_Create(archipack_i18n.Archipacki18n, Panel):
    bl_label = "Add Objects"
    bl_idname = "TOOLS_PT_Archipack_Create"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    bl_category = "Create"
    bl_context = "objectmode"

    @classmethod
    def poll(cls, context):
        return hasattr(context.window_manager, "archipack")

    def draw(self, context):
        prefs = context.preferences.addons[__name__].preferences
        wm = context.window_manager.archipack
        # addon_updater_ops.check_for_update_background(context)

        layout = self.layout

        self.draw_translate(context, layout)

        box = layout.box()
        self.draw_prop(context, layout, box, wm, "auto_manipulate", icon="VIEW_PAN")
        # self.draw_prop(context, layout, box, wm, "auto_save", icon="FILE_BACKUP")
        self.draw_prop(context, layout, box, prefs, "throttle_enable", icon="MOD_MULTIRES")
        self.draw_prop(context, layout, box, prefs, "throttle_delay")

        box = layout.column(align=True)
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.reference_point",
                     text="Reference point",
                     icon='EMPTY_ARROWS'
                     )
        row = box.row(align=True)
        # self.draw_op(context, layout, row, "archipack.wall2_draw",
        #            text="Wall",
        #            icon_value=icons["wall"].icon_id
        #            )
        self.draw_op(context, layout, row, "archipack.wall2_preset_draw",
                     text="Wall",
                     icon_value=icons["wall"].icon_id
                     ).preset_operator = "archipack.wall2_draw"
        self.draw_op(context, layout, row, "archipack.wall2_preset_from_curve",
                     text="",
                     icon='CURVE_DATA')

        row = box.row(align=True)
        # col = row.column()
        # subrow = col.row(align=True)
        self.draw_op(context, layout, row, "archipack.window_preset_draw",
                    text="Window",
                    icon_value=icons["window"].icon_id
                    ).preset_operator = "archipack.window_draw"
        self.draw_op(context, layout, row, "archipack.window_preset_create",
                     text="",
                     icon_value=icons["window"].icon_id
                     ).preset_operator = "archipack.window"
        # col = row.column()
        # subrow = col.row(align=True)
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.door_preset_draw",
                    text="Door",
                    icon_value=icons["door"].icon_id
                    ).preset_operator = "archipack.door_draw"
        self.draw_op(context, layout, row, "archipack.door_preset_create",
                     text="",
                     icon_value=icons["door"].icon_id
                     ).preset_operator = "archipack.door"

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.hole_preset_draw",
                     text="Hole",
                     icon_value=icons["hole"].icon_id
                     ).preset_operator = "archipack.hole_draw"
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.stair_preset_create",
                    text="Stairs",
                    icon_value=icons["stair"].icon_id
                    ).preset_operator = "archipack.stair"
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.fence_preset_draw",
                    text="Fence",
                    icon_value=icons["fence"].icon_id
                    ).preset_operator = "archipack.fence_draw"
        self.draw_op(context, layout, row, "archipack.fence_preset_from_curve",
                     text="",
                     icon='CURVE_DATA')

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.slab",
                    icon_value=icons["slab"].icon_id
                    )
        self.draw_op(context, layout, row, "archipack.slab_from_curve",
                    text="", icon='CURVE_DATA'
                    )

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.floor_preset_create",
                    text="Floor",
                    icon_value=icons["floor"].icon_id
                    ).preset_operator = "archipack.floor"
        self.draw_op(context, layout, row, "archipack.floor_preset_from_curve",
                    text="",
                    icon='CURVE_DATA')

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.ceiling_preset_create",
                     text="Ceiling",
                     icon_value=icons["ceiling"].icon_id
                     ).preset_operator = "archipack.ceiling"
        self.draw_op(context, layout, row, "archipack.ceiling_preset_from_curve",
                     text="",
                     icon='CURVE_DATA')

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.molding_preset_draw",
                    text="Molding",
                    icon_value=icons["molding"].icon_id
                    ).preset_operator = "archipack.molding_draw"
        self.draw_op(context, layout, row, "archipack.molding_preset_from_curve",
                    text="",
                    icon='CURVE_DATA')

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.roof_preset_create",
                    text="Roof",
                    icon_value=icons["roof"].icon_id
                    ).preset_operator = "archipack.roof"
        self.draw_op(context, layout, row, "archipack.roof_draft",
                     text="Draft",
                     icon_value=icons["roof"].icon_id
                     )
        # toolkit
        # row = box.row(align=True)
        # self.draw_op(context, layout, row, "archipack.myobject")
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.kitchen_preset_draw",
                    text="Kitchen",
                    icon_value=icons["kitchen"].icon_id
                    ).preset_operator = "archipack.kitchen_draw"
        self.draw_op(context, layout, row, "archipack.kitchen_preset_create",
                     text="",
                     icon_value=icons["kitchen"].icon_id
                     ).preset_operator = "archipack.kitchen"

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.blind_preset_create",
                    text="Blind",
                    icon_value=icons["blind"].icon_id
                    ).preset_operator = "archipack.blind"
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.truss",
                    icon_value=icons["truss"].icon_id
                    )
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.beam",
                     icon_value=icons["beam"].icon_id
                     )
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.sun",
                     icon="LIGHT_SUN"
                     )
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.terrain",
                    icon="RNDCURVE"
                    )

        if bpy.app.version >= (2, 93, 0):
            row = box.row(align=True)
            self.draw_op(context, layout, row, "archipack.section_model",
                     icon="MOD_BOOLEAN"
                    )

        if prefs.experimental_features:
            row = box.row(align=True)
            self.draw_op(context, layout, row, "archipack.array",
                        icon="MOD_ARRAY"
                        )

            row = box.row(align=True)
            self.draw_op(context, layout, row, "archipack.furniture_preset_draw",
                         text="Furniture",
                         icon_value=icons["furniture"].icon_id
                         ).preset_operator = "archipack.furniture_draw"

            self.draw_op(context, layout, row, "archipack.furniture_preset_create",
                         text="",
                         icon_value=icons["furniture"].icon_id
                         ).preset_operator = "archipack.furniture"
            row = box.row(align=True)
            self.draw_op(context, layout, row, "archipack.assembly_preset_draw",
                         text="Assembly",
                         icon_value=icons["assembly"].icon_id
                         ).preset_operator = "archipack.assembly_draw"
            self.draw_op(context, layout, row, "archipack.assembly_preset_create",
                         text="",
                         icon_value=icons["assembly"].icon_id
                         ).preset_operator = "archipack.assembly"

            row = box.row(align=True)
            self.draw_op(context, layout, row, "archipack.custom_preset_draw",
                         text="Custom",
                         icon='MONKEY'
                         ).preset_operator = "archipack.custom_draw"
            self.draw_op(context, layout, row, "archipack.custom_preset_create",
                         text="",
                         icon='MONKEY'
                         ).preset_operator = "archipack.custom"
            row = box.row(align=True)
            self.draw_op(context, layout, row, "archipack.veil",
                         text="Veil",
                         icon="FORCE_DRAG"
                         )


class TOOLS_PT_Archipack_Create_2d(archipack_i18n.Archipacki18n, Panel):
    bl_label = "Add 2d Objects"
    bl_idname = "TOOLS_PT_Archipack_Create_2d"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    bl_category = "Create"
    bl_context = "objectmode"

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        prefs = context.preferences.addons[__name__].preferences

        layout = self.layout

        box = layout
        self.draw_op(context, layout, box, "archipack.dimension_auto",
                    icon_value=icons["dimension_auto"].icon_id
                    )
        self.draw_op(context, layout, box, "archipack.layout",
                    icon_value=icons["layout"].icon_id
                    )
        self.draw_op(context, layout, box, "archipack.section",
                    icon_value=icons["section"].icon_id
                    )
        self.draw_op(context, layout, box, "archipack.section_camera",
                    text="Section cam",
                    icon='CAMERA_DATA'
                    )

        self.draw_op(context, layout, box, "archipack.area",
                    text="Area / Volume",
                    icon="MOD_EDGESPLIT"
                    )
        # self.draw_op(context, layout, box, "archipack.dimension_provider",
        #             text="Measurable",
        #             icon_value=icons["dimension_auto"].icon_id
        #             ).mode = "CREATE"

class TOOLS_PT_Archipack_Create_Custom(archipack_i18n.Archipacki18n, Panel):
    bl_label = "Custom Objects"
    bl_idname = "TOOLS_PT_Archipack_Create_Custom"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    bl_category = "Create"
    bl_context = "objectmode"

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        layout = self.layout
        box = layout
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.furniture",
                     text="New Furniture",
                     icon_value=icons["furniture"].icon_id
                     )

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.assembly",
                     text="New Assembly",
                     icon_value=icons["assembly"].icon_id
                     )

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.custom_wall", text="Custom wall")
        self.draw_op(context, layout, row, "archipack.custom_wall_remove", text="", icon='X')

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.custom_hole", text="Custom hole")
        self.draw_op(context, layout, row, "archipack.custom_hole_remove", text="", icon='X')

        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.make_custom", text="New Custom", icon='MONKEY')
        self.draw_op(context, layout, row, "archipack.custom_manipulators", text="", icon='TOOL_SETTINGS')
        # self.draw_op(context, layout, row, "archipack.custom_draw", text="", icon='GREASEPENCIL')


# ----------------------------------------------------
# ALT + A menu
# ----------------------------------------------------

def draw_menu(self, context):
    layout = self.layout
    layout.operator_context = 'INVOKE_REGION_WIN'
    self.draw_op(context, layout, layout, "archipack.reference_point", text="Reference point",
                 icon='EMPTY_ARROWS')
    self.draw_op(context, layout, layout, "archipack.wall2_preset_menu", text="Wall",
                 icon_value=icons["wall"].icon_id).preset_operator = "archipack.wall2"
    self.draw_op(context, layout, layout, "archipack.wall2_preset_draw", icon='GREASEPENCIL',
                 text="Draw wall").preset_operator = "archipack.wall2_draw"
    self.draw_op(context, layout, layout, "archipack.window_preset_draw", text="Window",
                 icon_value=icons["window"].icon_id).preset_operator = "archipack.window_draw"
    self.draw_op(context, layout, layout, "archipack.door_preset_draw", text="Door",
                 icon_value=icons["door"].icon_id).preset_operator = "archipack.door_draw"
    self.draw_op(context, layout, layout, "archipack.hole_preset_draw", text="Hole",
                 icon_value=icons["hole"].icon_id).preset_operator = "archipack.hole_draw"
    self.draw_op(context, layout, layout, "archipack.stair_preset_menu", text="Stair",
                 icon_value=icons["stair"].icon_id).preset_operator = "archipack.stair"
    self.draw_op(context, layout, layout, "archipack.fence_preset_menu", text="Fence",
                 icon_value=icons["fence"].icon_id).preset_operator = "archipack.fence"
    self.draw_op(context, layout, layout, "archipack.slab", text="Slab", icon_value=icons["slab"].icon_id)
    self.draw_op(context, layout, layout, "archipack.floor_preset_menu", text="Floor",
                 icon_value=icons["floor"].icon_id).preset_operator = "archipack.floor"
    self.draw_op(context, layout, layout, "archipack.ceiling_preset_menu", text="Ceiling",
                 icon_value=icons["ceiling"].icon_id).preset_operator = "archipack.ceiling"
    self.draw_op(context, layout, layout, "archipack.molding_preset_menu", text="Molding",
                 icon_value=icons["molding"].icon_id).preset_operator = "archipack.molding"
    self.draw_op(context, layout, layout, "archipack.roof_preset_menu", text="Roof",
                 icon_value=icons["roof"].icon_id).preset_operator = "archipack.roof"
    self.draw_op(context, layout, layout, "archipack.kitchen_preset_menu", text="Kitchen",
                 icon_value=icons["kitchen"].icon_id).preset_operator = "archipack.kitchen"
    self.draw_op(context, layout, layout, "archipack.blind_preset_menu", text="Blind",
                 icon_value=icons["blind"].icon_id).preset_operator = "archipack.blind"
    self.draw_op(context, layout, layout, "archipack.truss", text="Truss", icon_value=icons["truss"].icon_id)
    self.draw_op(context, layout, layout, "archipack.beam", icon_value=icons["beam"].icon_id)
    self.draw_op(context, layout, layout, "archipack.dimension_auto", icon_value=icons["dimension_auto"].icon_id)
    self.draw_op(context, layout, layout, "archipack.layout", icon_value=icons["layout"].icon_id)
    self.draw_op(context, layout, layout, "archipack.section", icon_value=icons["section"].icon_id)
    self.draw_op(context, layout, layout, "archipack.section_camera", icon='CAMERA_DATA', text="Section cam")
    self.draw_op(context, layout, layout, "archipack.sun", icon="LIGHT_SUN")
    self.draw_op(context, layout, layout, "archipack.terrain", text="Terrain", icon="RNDCURVE")
    self.draw_op(context, layout, layout, "archipack.area", text="Area / Volume", icon="MOD_EDGESPLIT")
    
    self.draw_op(context, layout, layout, "archipack.furniture_preset_menu", text="Furniture",
                icon_value=icons["furniture"].icon_id).preset_operator = "archipack.furniture"

    self.draw_op(context, layout, layout, "archipack.assembly_preset_menu", text="Assembly",
                icon_value=icons["assembly"].icon_id).preset_operator = "archipack.assembly"

    self.draw_op(context, layout, layout, "archipack.custom_preset_menu", text="Custom",
                icon='MONKEY').preset_operator = "archipack.custom"


class ARCHIPACK_MT_create_menu(archipack_i18n.Archipacki18n, Menu):
    bl_label = 'Archipack'
    bl_category = 'Add'
    bl_idname = 'ARCHIPACK_MT_create_menu'

    def draw(self, context):
        draw_menu(self, context)


def menu_func(self, context):
    layout = self.layout
    layout.separator()

    # either draw sub menu or right at end of this one
    if context.preferences.addons[__name__].preferences.create_submenu:
        layout.operator_context = 'INVOKE_REGION_WIN'
        layout.menu("ARCHIPACK_MT_create_menu", icon_value=icons["archipack"].icon_id)
    else:
        draw_menu(self, context)


def init_logger(self, context):
    prefs = context.preferences.addons[__name__].preferences
    update_logger(prefs, context)


def register_shorcut(prefs, name, label, key, alt, ctrl, shift):
    short = prefs.get(name)
    if short is None:
        short = prefs.add()
    else:
        return
    short.name = name
    short.label = label
    short.shift = shift
    short.key = key
    short.alt = alt
    short.ctrl = ctrl


def register_shortcuts(context):
    prefs = context.preferences.addons[__name__].preferences.shortcuts
    register_shorcut(prefs, "SplitPath", "Split", "S", False, False, False)
    register_shorcut(prefs, "AddPath", "Add", "A", False, False, False)


def register():

    addon_updater_ops.register(bl_info)

    glob = globals()
    for sub in submodules:
        module = glob["archipack_{}".format(sub)]
        if hasattr(module, "register"):
            # print("register", sub)
            try:
                module.register()
            except Exception as ex:
                print("{} {} register() error {}\n{}".format(bl_info['name'], __version__, sub, ex))
                raise

    register_class(archipack_shortcut)
    register_class(Archipack_Pref)
    register_shortcuts(bpy.context)

    register_class(archipack_wm)
    bpy.types.WindowManager.archipack = PointerProperty(type=archipack_wm)
    register_class(ARCHIPACK_MT_create_menu)
    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)
    update_panel(None, bpy.context)
    register_translation(None, bpy.context)

    glob['archipack_object'].version = bl_info['version']

    init_logger(None, bpy.context)


def unregister():
    addon_updater_ops.unregister()

    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    unregister_class(ARCHIPACK_MT_create_menu)
    unregister_class(TOOLS_PT_Archipack_PolyLib)
    unregister_class(TOOLS_PT_Archipack_Tools)
    unregister_class(TOOLS_PT_Archipack_Create)
    unregister_class(TOOLS_PT_Archipack_Create_2d)
    unregister_class(TOOLS_PT_Archipack_Create_Custom)
    unregister_class(TOOLS_PT_Archipack_About)
    unregister_class(Archipack_Pref)
    unregister_class(archipack_shortcut)
    del bpy.types.WindowManager.archipack
    unregister_class(archipack_wm)

    # unregister submodules
    glob = globals()
    for sub in reversed(submodules):
        module = glob["archipack_{}".format(sub)]
        if hasattr(module, "unregister"):
            module.unregister()


if __name__ == "__main__":
    register()
