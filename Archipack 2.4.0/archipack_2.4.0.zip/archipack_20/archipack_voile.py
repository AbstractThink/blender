# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
# noinspection PyUnresolvedReferences
import bpy
# noinspection PyUnresolvedReferences
from bpy.types import Operator, PropertyGroup, Mesh, Panel, Object
from bpy.props import (
    FloatProperty, BoolProperty, IntProperty, IntVectorProperty,
    StringProperty, EnumProperty,
    CollectionProperty, FloatVectorProperty, PointerProperty
)
from .bmesh_utils import BmeshEdit as bmed
from random import uniform, randint, seed
import bmesh
import json
import time
from mathutils import Vector, Matrix
from math import sin, cos, pi, atan2, sqrt, tan, atan
from .archipack_manipulator import Manipulable, archipack_manipulator
from .archipack_generator import Line, Generator
from .archipack_preset import ArchipackPreset, PresetMenuOperator
from .archipack_abstraction import (
    context_override, ArchipackObjectsManager, stop_auto_manipulate,
    X_AXIS, Z_AXIS
)
from .archipack_i18n import Archipacki18n
from .archipack_object import (
    ArchipackCreateTool,
    ArchipackObject,
    ArchipackPanel,
    ArchipackGenericOperator,
    update_source
)
from .archipack_cutter import (
    CutAblePolygon, CutAbleGenerator,
    ArchipackCutter, CutterGenerator,
    ArchipackCutterPart
)
from .archipack_polylines import Io, ShapelyOps, CoordSys, Polygonizer, Qtree
from .archipack_curveman import ArchipackUserDefinedPath
from .archipack_dimension import DimensionProvider
from .archipack_material import build_mat_enum
from .archipack_throttle import throttle
from .archipack_terrain import Q_tree
from .polyskel import polyskel
from .archipack_iconmanager import icons
from .pygeos.geom import GeometryFactory
from .archipack_logging import logger

# keep a reference to material enums
material_enums = []
mat_enum, mat_index_getter, mat_index_setter = build_mat_enum('idmat', material_enums)


def update(self, context):
    self.update(context)


def update_manipulators(self, context):
    self.manipulable_refresh = True
    self.update(context)


def update_path(self, context):
    self.update_path(context)


def update_operation(self, context):
    o = self.find_in_selection(context, self.auto_update)
    if o is None:
        return
    g = self.get_generator()
    if g.is_cw != (self.operation == 'INTERSECTION'):
        return
    self.reverse(context, o)

# Use curved boundary in polyskel
USE_BOUNDARY = False
MIN_SLOPE = 0
# Maximum value for an edge to be considered as horizontal / does affect hips in custom shapes
MAX_DELTA_Z_FOR_HORIZONTAL = 0.01


class archipack_veil_segment(ArchipackCutterPart, PropertyGroup):
    side_type: EnumProperty(
        name="Type",
        items=(
            ('SIDE', 'Side', 'Side with bargeboard', 0),
        ),
        default='SIDE',
        update=update
    )

    radius_override: BoolProperty(name="Override", default=False, update=update)

    radius: FloatProperty(
        name="Radius",
        unit='LENGTH', subtype='DISTANCE',
        default=6,
        min=0.1, update=update
    )
    z: FloatProperty(
        name="Pin altitude",
        unit='LENGTH', subtype='DISTANCE',
        default=0,
        update=update
    )
    offset: FloatProperty(
        name="Pin Offset",
        description="Sewing pin points offset",
        unit='LENGTH', subtype='DISTANCE',
        default=0,
        update=update
    )
    manipulators: CollectionProperty(type=archipack_manipulator)

    @property
    def parent_data(self):
        return self.id_data.archipack_veil[0]

    def draw(self, context, layout, index, draw_type=False, closed=True, draw_split=False, type_prop=None):
        icon = "TRIA_RIGHT"
        if self.expand:
           icon = "TRIA_DOWN"
        box = layout  #.box()
        row = box.row(align=True)
        self.draw_prop(context, layout, row, self, 'expand', icon=icon, emboss=True,
                      text="Seg", postfix=str(index + 1))

        if self.expand:
            self.draw_insert(context, layout, index, closed, draw_split)
            self.draw_prop(context, layout, box, self, "length")
            self.draw_prop(context, layout, box, self, "a0")
            row = layout.row(align=True)
            icon = "LOCKED"
            if self.radius_override:
                icon = "UNLOCKED"
            self.draw_prop(context, layout, row, self, 'radius_override', emboss=True, icon=icon)
            if self.radius_override:
                self.draw_prop(context, layout, row, self, 'radius')
            else:
                self.draw_prop(context, layout, row, self.parent_data, 'radius')
            if self.parent_data.use_sewing:
                self.draw_prop(context, layout, box, self, 'z')
                self.draw_prop(context, layout, box, self, 'offset')

class archipack_veil(ArchipackCutter, ArchipackObject, DimensionProvider, PropertyGroup):
    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('MAIN', 'Main', 'Display draft settings', 'NONE', 0),
            ('PARTS', 'Shape', 'Display draft segments settings', 'NONE', 1)
        ),
        default='MAIN',
    )
    parts: CollectionProperty(type=archipack_veil_segment)

    radius: FloatProperty(
        name="Radius",
        unit='LENGTH', subtype='DISTANCE',
        default=5,
        min=0.1,
        update=update
    )

    offset: FloatProperty(
        name="Pin Offset",
        description="Sewing pin points offset",
        unit='LENGTH', subtype='DISTANCE',
        default=0,
        update=update
    )
    subdivision: IntProperty(
        name="Subdivision",
        min=1, max=48, default=12,
        update=update
    )
    use_boundary: BoolProperty(
        name="Use boundary",
        description="Use boundary arcs in order to prevent intersections (slower)",
        default=True,
        update=update
    )
    use_sewing: BoolProperty(
        name="Sewing",
        description="Use sewing to pin corners",
        default=True,
        update=update
    )
    z: FloatProperty(
        name="Pin altitude",
        unit='LENGTH', subtype='DISTANCE',
        default=0,
        update=update
    )

    def draw(self, context, layout, draw_offset=False, draw_type=False):
        self.draw_prop(context, layout, layout, self, "tabs", expand=True)
        global icons
        box = layout.box()
        if self.tabs == 'MAIN':
            self.draw_prop(context, layout, box, self, 'radius')
            self.draw_prop(context, layout, box, self, 'subdivision')
            self.draw_prop(context, layout, box, self, 'use_boundary')
            box = layout.box()
            self.draw_prop(context, layout, box, self, 'use_sewing')
            if self.use_sewing:
                self.draw_prop(context, layout, box, self, 'z')
                self.draw_prop(context, layout, box, self, 'offset')
            box = layout.box()
            box.prop(context.object, "display_type")

        elif self.tabs == 'PARTS':
            self.template_user_path(context, box, focus=False)
            self.template_parts(context, layout, draw_type=False)

    def update_parent(self, context, o):
        return

    def ensure_direction(self, o=None):
        """ Override because operation based direction here doesnt make any sense
        :param o:
        :return:
        """
        g = self.get_generator(o)
        return g

    # def from_spline(self, context, o, curve, ccw=False, cw=False):
    #    ArchipackCutter.from_spline(self, context, o, curve, cw=True)

    def from_points(self, o, pts):
        g = Generator()
        g.from_points(pts, False, True, False, True)
        self.n_parts = len(g.segs)
        # self.update_parts()
        g.update_parts(self)

    def get_centers(self, g, radius):
        centers = []
        h_side = []
        for part, _s, r in zip(self.parts, g.segs, radius):
            # center always lie outside
            #  0___a_1
            #   \ h /
            #    \|/ r
            #     c
            r2 = r * r
            a2 = 0.25 * _s.length_squared
            if a2 < r2:
                h = sqrt(r2 - a2)
            else:
                h = 0.1
            h_side.append(h)
            centers.append(_s.normal(0.5, -h).p1)
        return centers, h_side

    def get_generator(self, o=None):
        g = CutterGenerator(o)
        g.operation = 'DIFFERENCE'
        g.add_parts(self)

        # # get default radius
        # radius = [
        #     part.radius if part.radius_override else self.radius
        #     for part in self.parts
        # ]
        #
        # # get all centers and distance of center from boundary
        # centers, h_side = self.get_centers(g, radius)
        #
        # # check for circle intersections
        # for i, c0 in enumerate(centers):
        #     for j in range(i+1, len(centers)):
        #         r0 = radius[i]
        #         r1 = radius[j]
        #         c1 = centers[j]
        #         dc = (c0 - c1).length
        #         if dc < r0 + r1:
        #             #
        #             #     c0
        #             #     | \h0
        #             #  r0 |  \
        #             #     |
        #             #  r1 |  /
        #             #     | /  h1
        #             #     c1
        #             # increasing r1 will move center along h1 vector
        #
        #             dr = (r0 + r1) - dc
        #             # circle do intersect
        #             # increase smaller radius
        #             # increasing h_side means we decrease radius
        #             if r0 < r1:
        #                 radius[i] += h_side[i] / radius[i] * dr
        #             else:
        #                 radius[j] += h_side[j] / radius[j] * dr

        g.offset_line = g.make_offset(self.offset)

        g.line = Generator(o)

        l2 = Line(g.segs[0].p0)
        g.line.segs.append(l2)
        numsegs = self.subdivision

        for part, _s in zip(self.parts, g.segs):
            # center always lie outside
            #  0___a_1
            #   \ h /
            #    \|/ r
            #     c
            if part.radius_override:
                radius = part.radius
            else:
                radius = self.radius
            r2 = radius * radius
            a2 = 0.25 * _s.length_squared
            if a2 < r2:
                h = sqrt(r2 - a2)
            else:
                h = 0.1
            c = _s.normal(0.5, -h).p1
            l0 = Line(c, _s.p0)
            l1 = Line(c, _s.p1)
            da = Line.signed_angle(l0.v, l1.v) / numsegs
            for i in range(numsegs):
                l0.rotate(da)
                l2 = Line(l0.p1, last=l2)
                g.line.segs.append(l2)

        g.line.segs[-1]._next = g.line.segs[0]
        g.line.segs[0]._last = g.line.segs[-1]
        return g

    def update_points(self, context, o, pts, update_parent=False):
        """
            Create boundary from roof
        """
        self.auto_update = False
        self.manipulable_disable(o)
        self.from_points(o, pts)
        self.auto_update = True

    def update(self, context, update_parent=True):

        o = self.find_in_selection(context, self.auto_update)

        if o is None:
            return

        # clean up manipulators before any data model change
        if self.manipulable_refresh:
            self.manipulable_disable(o)

        # changed = self.update_parts()
        g = self.get_generator()
        g.locate_manipulators(self)

        boundary = []
        raw = []

        g.line.get_pts(boundary)

        if self.use_boundary:
            raw = boundary
        else:
            g.get_pts(raw)

        polygon = [p.to_2d() for p in raw]

        # coordsys = CoordSys([o], itM=g.itM)
        coordsys = CoordSys([o], generator=g, itM=g.itM)
        # 3d vertex tree
        tree = Q_tree(coordsys, max_items=8, max_depth=8)
        # 3d vertex and segments tree for polygonize
        Q_points = Qtree(coordsys)
        Q_segs = Qtree(coordsys)

        io = Io(Q_points=Q_points, Q_segs=Q_segs, coordsys=coordsys)
        b_pts = [Q_points.newPoint(p) for p in boundary]
        b_pts.append(b_pts[0])
        io._add_segs(b_pts)

        gf = GeometryFactory()

        # polygon skeleton
        res = polyskel.skeletonize(polygon, [])

        # logger.debug(res)
        slope = 0.5
        z = 0
        if len(res) > 0:
            z -= slope * max([t.height for t in res])

        if not self.use_boundary:
            # add boundary points in 3d tree
            for p in boundary:
                tree.new_point_maxz(Vector((p.x, p.y, z)), 0.01)

        # Polygonize to detect polygons as contextual create is not 100% reliable for this..

        # fill 2d tree with boundary
        # boundary = []
        # g.line.get_pts(boundary)

        # _io, bounds = Io.generator_to_geom(context, o, g.line, coordsys=coordsys)
        # _io._to_curve(bounds, name="bounds")
        #
        # _io, bounds = Io.generator_to_geom(context, o, g, coordsys=coordsys)
        # _io._to_curve(bounds, name="straight")

        # coords = []
        # for t in res:
        #     p0 = Vector((t.source.x, t.source.y, 0))
        #     for p in t.sinks:
        #         p1 = Vector((p.x, p.y, z))
        #         coords.append([p0, p1])
        #
        # geoms = _io.coords_to_linestring(Matrix(), coords)
        # _io._to_curve(geoms, name="res")

        # fill tree with polyskel sinks, store vertices with altitudes max
        for t in res:
            p0 = Vector((t.source.x, t.source.y, z + slope * abs(t.height)))
            idx = tree.new_point_maxz(p0, 0.01)
            p0 = tree._geoms[idx]
            p0 = Q_points.newPoint(Vector((p0.x, p0.y, 0)))
            for p in t.sinks:
                idx = tree.new_point_maxz(Vector((p.x, p.y, z)), 0.01)
                p1 = tree._geoms[idx]
                p1 = Q_points.newPoint(Vector((p1.x, p1.y, 0)))
                if p0 != p1:
                    Q_segs.newSegment(p0, p1)

        # Polygonize boundary + skeleton

        op = Polygonizer(coordsys)
        merged, polys, dangles, cuts, invalids = op._polygonize(gf, Q_points, Q_segs, extend=0.01, all_segs=True)
        faces = []

        # _io._to_curve(polys, name="polys")

        for poly in polys:
            face = []
            for p in poly.exterior.coords[:-1]:
                # retrieve index of vertex in 3d vertex tree
                count, selection = tree.intersects_co(p.as_tuple(), 0.01)
                if len(selection) > 0:
                    idx = selection.pop()
                    # XXX Bugfix vertex added multiple times ??
                    if idx not in face:
                        face.append(idx)
            if len(face) > 2:
                faces.append(list(reversed(face)))

        bm = bmed.buildmesh(o, tree._geoms, faces, temporary=True, clean=True)
        bmed.ensure_bmesh(bm)
        bmed.scale(bm, Vector((1, 1, 0)), verts=bm.verts)

        raw = []
        g.get_pts(raw)
        vertex_groups = {'pin': {}}

        if self.use_sewing:
            for p, _s, part in zip(raw, g.offset_line.segs, self.parts):

                p0 = _s.p0
                if part.offset != 0:
                    _s0 =_s._last.offset(part.offset)
                    _s1 = _s.offset(part.offset)
                    it, p0, u, v = _s0.intersect_ext(_s1)

                count, selection = tree.intersects_co(p, 0.01)
                for i in selection:
                    v0 = bm.verts[i]
                    j = len(bm.verts)
                    v1 = bm.verts.new((p0.x, p0.y, self.z + part.z))
                    bmed.ensure_bmesh(bm)
                    bm.edges.new((v0, v1))
                    vertex_groups['pin'][j] = 1.0
        else:
            for p in raw:
                count, selection = tree.intersects_co(p, 0.01)
                for i in selection:
                    vertex_groups['pin'][i] = 1.0

        # bmesh.ops.dissolve_limit(
        #     bm,
        #     angle_limit=0.01,
        #     use_dissolve_boundaries=False,
        #     verts=bm.verts,
        #     edges=bm.edges,
        #     delimit={'NORMAL'}
        # )

        bmed._end(bm, o)

        bmed.set_vertex_groups(o, vertex_groups)

        bpy.ops.object.shade_smooth()

        scene = self.get_context_value(context, "scene")
        scene.frame_current = 1

        sub = self.find_modifier_by_type(o, "SUBSURF")
        tri = self.find_modifier_by_type(o, "TRIANGULATE")
        cloth = self.find_modifier_by_type(o, "CLOTH")

        if sub is None:
            m = o.modifiers.new(type="SUBSURF", name="Subsurface")
            m.subdivision_type = "SIMPLE"
            m.levels = 1
            m.render_levels = 1

        if tri is None:
            m = o.modifiers.new(type="TRIANGULATE", name="Triangulate")
            m.quad_method = "BEAUTY"

        if cloth is None:
            cloth = o.modifiers.new(type="CLOTH", name="Cloth")

        cloth.settings.vertex_group_mass = "pin"
        cloth.settings.use_sewing_springs = self.use_sewing

        self.restore_context(context)


class ARCHIPACK_PT_veil(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_veil"
    bl_label = "Veil"

    @classmethod
    def poll(cls, context):
        return archipack_veil.poll(context.active_object)

    def draw(self, context):
        d = archipack_veil.datablock(context.active_object)
        if d is None:
            return
        layout = self.layout

        self.draw_common(context, layout)
        d.draw(context, layout)


# ------------------------------------------------------------------
# Define operator class to create object
# ------------------------------------------------------------------


class ARCHIPACK_OT_veil(ArchipackCreateTool, Operator):
    bl_idname = "archipack.veil"
    bl_label = "Veil"
    bl_description = "Sunshade Veil"

    parent: StringProperty("")
    curve: StringProperty("")

    def create(self, context):
        o, m = self.create_mesh("Veil")
        d = m.archipack_veil.add()

        curve = self.get_scene_object(context, self.curve)
        d.manipulable_selectable = True
        x = 4
        angle_90 = pi / 2
        d.set_parts(4)
        for i, p in enumerate(d.parts):
            p.a0 = angle_90
            p.length = x
        d.parts[0].a0 = - angle_90

        o.location = self.get_cursor_location(context)

        # make manipulators selectable
        d.manipulable_selectable = True
        # Link object into scene
        self.link_object_to_scene(context, o, layer_name="Roofs")

        # select and make active
        self.select_object(context, o, True)
        # o.display_type = 'WIRE'
        # o.hide_render = True
        o.show_all_edges = True
        # o.show_wire = True
        # o.display.show_shadows = False
        o.color = (1, 0, 0, 1)

        # self.add_material(context, o)
        # self.load_preset(d)
        update_operation(d, context)

        d.auto_update = True
        with context_override(context, o, [o]) as ctx:
            d.update(ctx)

        if curve is not None:
            d.user_defined_path = curve.name

        return o

    # -----------------------------------------------------
    # Execute
    # -----------------------------------------------------
    def execute(self, context):
        if context.mode == "OBJECT":
            bpy.ops.object.select_all(action="DESELECT")
            with stop_auto_manipulate(context):
                o = self.create(context)
            # select and make active
            self.add_to_reference(context, o)
            self.select_object(context, o, True)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


# ------------------------------------------------------------------
# Define operator class to create object
# ------------------------------------------------------------------


class ARCHIPACK_OT_roof_preset_create(PresetMenuOperator, Operator):
    bl_description = "Show Roof presets and create object at cursor location"
    bl_idname = "archipack.roof_preset_create"
    bl_label = "Roof Styles"
    preset_subdir = "archipack_roof"


class ARCHIPACK_OT_roof_preset_draft(PresetMenuOperator, Operator):
    bl_description = "Show Roof presets and create object from draft"
    bl_idname = "archipack.roof_preset_draft"
    bl_label = "Roof Styles"
    preset_subdir = "archipack_roof"


class ARCHIPACK_OT_roof_preset_menu(PresetMenuOperator, Operator):
    bl_description = "Show Roof presets"
    bl_idname = "archipack.roof_preset_menu"
    bl_label = "Roof Styles"
    preset_subdir = "archipack_roof"


class ARCHIPACK_OT_roof_preset(ArchipackPreset, Operator):
    bl_description = "Add / remove a Roof Preset"
    bl_idname = "archipack.roof_preset"
    bl_label = "Add Roof Style"
    preset_menu = "ARCHIPACK_OT_roof_preset_menu"

    @property
    def blacklist(self):
        return ['draft', 'z', 'slope_left', 'slope_right', 'width_left', 'width_right', 'parts', 'n_parts',
                't_parent', 't_part', 't_dist_x', 't_dist_y',
                'hole_offset_front', 'hole_offset_left', 'hole_offset_right', 'user_defined_roof'
                ]


def register():
    # bpy.utils.register_class(archipack_roof_material)

    bpy.utils.register_class(archipack_veil_segment)
    bpy.utils.register_class(archipack_veil)
    bpy.utils.register_class(ARCHIPACK_PT_veil)
    bpy.utils.register_class(ARCHIPACK_OT_veil)
    Mesh.archipack_veil = CollectionProperty(type=archipack_veil)

    # bpy.utils.register_class(ARCHIPACK_OT_roof_preset_menu)
    # bpy.utils.register_class(ARCHIPACK_OT_roof_preset_create)
    # bpy.utils.register_class(ARCHIPACK_OT_roof_preset_draft)
    # bpy.utils.register_class(ARCHIPACK_OT_roof_preset)


def unregister():

    bpy.utils.unregister_class(archipack_veil_segment)
    bpy.utils.unregister_class(archipack_veil)
    bpy.utils.unregister_class(ARCHIPACK_PT_veil)
    bpy.utils.unregister_class(ARCHIPACK_OT_veil)
    del Mesh.archipack_veil

    # bpy.utils.unregister_class(ARCHIPACK_OT_roof_preset_menu)
    # bpy.utils.unregister_class(ARCHIPACK_OT_roof_preset_create)
    # bpy.utils.unregister_class(ARCHIPACK_OT_roof_preset_draft)
    # bpy.utils.unregister_class(ARCHIPACK_OT_roof_preset)
