# -*- coding:utf-8 -*-

# #
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# 
# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------

import logging
logger = logging.getLogger(__package__)


try:
    from blenderbim import bl_info as bim_info

    bim_version = bim_info['version']
    print("Archipack ifc export : found blenderbim")

    if bim_version < (0,0,210131):
        from .archipack_io_export_ifc1 import register, unregister

    elif bim_version >=  (0,0,210131):
        from .archipack_io_export_ifc2 import register, unregister

except ImportError as ex:
    print(ex)
    from .archipack_io_export_ifc0 import register, unregister
    print("Archipack ifc export fallback")
    pass

