import json
import inspect
import bpy
from bpy.types import PropertyGroup, Object, Collection


def pointer_objects_to_dict(_d, blacklist):
    """
        :param _d: rna_property
        :param blacklist: set of attributes name to skip
        :return: dict
        """
    objs = set()
    def _walk(value):
        if isinstance(value, PropertyGroup):
            [
            _walk(getattr(value, rna_name))
            for rna_name, rna_prop in value.bl_rna.properties.items()
            if not (rna_name in blacklist or rna_prop.is_hidden or rna_prop.is_skip_save)
            ]
        elif isinstance(value, Object):
            objs.add(value.name)

        elif type(value).__name__ == "bpy_prop_collection_idprop":
            [_walk(prop)
            for prop in value
            if prop.bl_rna.name not in blacklist
            ]
        return
    _walk(_d)
    return objs


def to_dict(_d, blacklist, prefix=""):
    """
    :param _d: rna_property
    :param blacklist: set of attributes name to skip
    :return: dict
    """

    def _walk(value):
        if isinstance(value, PropertyGroup):
            return dict(
                (rna_name, _walk(getattr(value, rna_name)))
                for rna_name, rna_prop in value.bl_rna.properties.items()
                if not (rna_name in blacklist or rna_prop.is_hidden or rna_prop.is_skip_save)
            )
        elif isinstance(value, Object):
            return ('Object', "%s%s"[0:60] % (prefix, value.name))

        elif isinstance(value, Collection):
            # at this time we do not save / reload collections
            return ('Collection', "%s%s"[0:60] % (prefix, value.name))

        elif type(value).__name__ == "bpy_prop_collection_idprop":
            return [_walk(prop)
                    for prop in value
                    if prop.bl_rna.name not in blacklist
                    ]
        else:
            try:
                value = value[:]
            except:
                pass
            return value
    return _walk(_d)


def pointer_objects_from_dict(_d, _dict):
    objs = set()
    def _walk(value):
        if type(value).__name__ == 'dict':
            for attr, sub_value in value.items():

                typ = type(sub_value).__name__

                if typ in ('list') and len(sub_value) == 2 and sub_value[0] == 'Object':

                    if sub_value[1] is not None:
                        objs.add(sub_value[1])

                elif typ in ('dict', 'list'):
                    try:
                        # recursion for nested PropertyGroups / CollectionProperties
                        _walk(sub_value)
                    except:
                        pass

        elif type(value).__name__ == 'list':
            for sub_value in value:
                try:
                    _walk(sub_value)
                except:
                    pass
    _walk(_dict)
    return objs


def from_dict(_d, _dict):

    def _walk(prop, value):
        if isinstance(prop, PropertyGroup):
            for attr, sub_value in value.items():
                typ = type(sub_value).__name__

                if typ == 'list' and len(sub_value) == 2 and sub_value[0] == 'Object':
                    if sub_value[1] is not None:
                        sub_value = bpy.data.objects.get(sub_value[1])

                elif typ in ('dict', 'list'):
                    try:
                        sub_prop = getattr(prop, attr)
                        _walk(sub_prop, sub_value)
                        continue
                    except:
                        pass

                try:
                    # keep old preset almost loadable on data model change
                    setattr(prop, attr, sub_value)
                except:
                    pass

        elif type(prop).__name__ == "bpy_prop_collection_idprop":
            prop.clear()
            for sub_value in value:
                sub_prop = prop.add()
                _walk(sub_prop, sub_value)

    _walk(_d, _dict)


class ArchipackJsonIO:
    @staticmethod
    def to_pointers(obj, key, blacklist):
        """
        :param obj: blender object
        :param key: archipack class name
        :param blacklist: property to ignore
        :return: return set of pointer objects name to save
        """
        bl = set(blacklist)
        bl.update(["version", "name",
                   "dimension_points", "dimension_uid",
                   "manipulators",
                   "closed",
                   "user_defined_path", "user_defined_spline", "user_defined_resolution", "user_defined_reverse"])

        _d = getattr(obj.data, key)[0]
        return pointer_objects_to_dict(_d, bl)

    @staticmethod
    def has_material(obj):
        return "archipack_material" in obj and len(obj.archipack_material) > 0

    @staticmethod
    def from_pointers(obj, _json):
        """
        :param obj: blender object
        :param _json: json string
        :return: set of object's names from dict
        """
        _dict = json.loads(_json)
        for key, value in _dict.items():
            if key not in {"archipack_material", "metadata"}:
                _d = getattr(obj.data, key)[0]
                return pointer_objects_from_dict(_d, value)
        return []

    @staticmethod
    def to_json(obj, key, blacklist, prefix="", metadata=None):
        bl = set(blacklist)
        bl.update(["version", "name",
                   "dimension_points", "dimension_uid",
                   "manipulators",
                   "closed",
                   "user_defined_path", "user_defined_spline", "user_defined_resolution", "user_defined_reverse"])

        _meta =  {}
        if metadata is not None:
            _meta.update(metadata)

        _d = getattr(obj.data, key)[0]
        _dict = {
            key: to_dict(_d, bl, prefix=prefix),
            "metadata":_meta
        }
        if ArchipackJsonIO.has_material(obj):
            _mat = obj.archipack_material[0]
            _dict["archipack_material"] = to_dict(_mat, {'name'})

        return json.dumps(_dict, indent=None, sort_keys=True)

    @staticmethod
    def get_metadata(_json):
        _dict = json.loads(_json)
        if "metadata" in _dict:
            return _dict["metadata"]
        return {}

    @staticmethod
    def from_json(obj, _json):
        _dict = json.loads(_json)
        for key, value in _dict.items():
            if key not in {"archipack_material", "metadata"}:
                _d = getattr(obj.data, key)[0]
                # load_preset() disable auto_update, prevent re-enable while loading
                value['auto_update'] = False
                from_dict(_d, value)
        if ArchipackJsonIO.has_material(obj) and "archipack_material" in _dict:
            _mat = obj.archipack_material[0]
            from_dict(_mat, _dict['archipack_material'])

        if "metadata" in _dict:
            return _dict["metadata"]
        else:
            return {}
