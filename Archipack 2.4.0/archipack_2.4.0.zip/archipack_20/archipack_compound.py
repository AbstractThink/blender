# -*- coding:utf-8 -*-

# #
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# 
# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
from mathutils import Vector, Matrix
from uuid import uuid4
from bpy.props import StringProperty


class CompoundPart:
    part_uid: StringProperty()


class Compound:
    """
    Shared methods for compound objects like furniture and assembly (and maybe doors, windows and kitchen?)
    Basically associate object's parts and children datablock sources through uid

    Child class must implement
    def get_member_datablock(o)

    Child class may implement parts accessors
    @property
    def _member_parts()

    def update_source(context)

    Child class using source pointers must use or override archipack_object update_source
    and call update_source from pointer .update
    update=update_source
    """

    def get_member_datablock(self, o):
        """'virtual method' Return xx_member.datablock(o) from child object"""
        raise NotImplementedError("Compound requires implementation of get_member_datablock(o) method")

    def cleanup_members(self, context, o, filter=None):
        """Remove children without source, return valid members {uid: child}"""
        sources = self._sources_uids
        members = {}
        # Always keep objects unless removed from furniture
        for c in o.children[:]:
            if filter is None or filter(c):
                cd = self.get_member_datablock(c)
                if not cd or cd.part_uid not in sources:
                    self.delete_object(context, c)
                else:
                    members[cd.part_uid] = c
        return members

    def update_sources_uids(self, o):
        """Update uids of all sources"""
        sources = self._sources_uids
        members = {}
        for c in o.children[:]:
            cd = self.get_member_datablock(c)
            if cd and cd.part_uid in sources:
                members[cd.part_uid] = cd
        for p in self._members_parts:
            uid = p.part_uid
            p.uuid = str(uuid4())
            if uid in members:
                members[uid].part_uid = p.part_uid

    def update_source(self, context):
        o = context.active_object
        self.update_sources_uids(o)

    @property
    def _members_parts(self):
        """Returns parts for the object"""
        return self.parts

    @property
    def _sources_uids(self):
        """Return set of uid for parts with valid sources"""
        return {part.part_uid for part in self._members_parts}

    def _members(self, o):
        """Return assoc of {uid: children} for children with valid source"""
        sources = self._sources_uids
        members = {}
        for c in o.children[:]:
            cd = self.get_member_datablock(c)
            if cd and cd.part_uid in sources:
                members[cd.part_uid] = c
        return members

    @property
    def user_defined_objects(self):
        """
        collect source to clean up preset datablocks
        may return duplicate results to allow removal of all users
        """
        return [
            c.source for c in self.parts
            if c.source is not None
        ]

    def bound_box(self, o, space=None):
        """returns mini, maxi, size center of components in local parent object space or in given space"""
        if space is not None:
            itM = space @ o.matrix_world.inverted()
        else:
            itM = o.matrix_world.inverted()
        objs = []
        self.rec_get_childrens(o, objs)
        x, y, z = list(zip(*[itM @ c.matrix_world @ Vector(p) for c in objs for p in c.bound_box]))
        mini, maxi = Vector((min(x), min(y), min(z))), Vector((max(x), max(y), max(z)))
        size = maxi - mini
        center = 0.5 * (mini + maxi)
        return mini, maxi, size, center

    def synch_linked_location(self, context, o):
        """Synch valid linked childs location"""
        linked = self.get_linked_objects(context, o)
        members = self._members(o)
        for c in linked:
            if c.name != o.name:
                dst = self._members(c)
                for uid, src in members.items():
                    if uid in dst:
                        dst[uid].location = src.location.copy()
                        dst[uid].rotation_euler = src.rotation_euler.copy()
                        # Copy euler may screw scale ..
                        self.safe_scale(dst[uid])