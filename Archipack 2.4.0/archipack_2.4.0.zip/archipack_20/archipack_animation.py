# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
import bpy
from bpy.app.handlers import persistent
from bpy.types import (
    Object, Scene, Operator
    )
from bpy.props import (
    EnumProperty, BoolProperty
    )
from .archipack_abstraction import context_override
from .archipack_object import ArchipackObjectsManager
from .archipack_prefs import get_prefs


# Store animated objects for current session
# key: object name, value: datablock name
animated = {}


def archipack_animation_handler_state():
    return archipack_animation_updater in bpy.app.handlers.frame_change_pre


def archipack_animation_handler_remove():
    if archipack_animation_handler_state():
        bpy.app.handlers.frame_change_pre.remove(archipack_animation_updater)


def archipack_animation_handler_add():
    state = archipack_animation_handler_state()
    if not state:
        bpy.app.handlers.frame_change_pre.append(archipack_animation_updater)
    return state


def update_animation_handler_state(self, context):
    if self.archipack_animation:
        archipack_animation_handler_add()
    else:
        archipack_animation_handler_remove()


def update_animation_state(self, context):
    global animated
    o = self.id_data
    if self.archipack_animation:
        if o.data:
            for key in o.data.keys():
                if "archipack_" in key:
                    d = getattr(o.data, key)[0]
                    if hasattr(d, "update"):
                        animated[o.name] = key
    elif o.name in animated:
        del animated[o.name]


@persistent
def archipack_animation_onload(dummy):
    """
      Fill in animated dict and animation handler on file load
    """
    global animated
    for o in bpy.data.objects:
        if "archipack_animation" in o and o.archipack_animation:
            for key in o.data.keys():
                if "archipack_" in key:
                    animated[o.name] = key
    try:
        if bpy.context.scene.archipack_animation:
            archipack_animation_handler_add()
    except:
        pass


@persistent
def archipack_animation_onunload(dummy):
    """
        Cleanup animated dict and handlers on file unload
    """
    global animated
    animated.clear()
    archipack_animation_handler_remove()


def archipack_animation_updater(dummy):
    global animated
    context = bpy.context
    # prevent SEG_FAULT on regular render with limited support for context
    if hasattr(context, "active_object"):
        if len(animated) > 0:
            prefs = get_prefs(context)
            last = prefs.throttle_enable
            prefs.throttle_enable = False
            for name in animated:
                o = context.scene.objects.get(name.strip())
                if o and o.archipack_animation:
                    with context_override(context, o, [o]) as ctx:
                        d = getattr(o.data, animated[name])[0]
                        d.update(ctx)
            prefs.throttle_enable = last


class ARCHIPACK_OT_animation_add(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.animation_add"
    bl_label = "Add"
    bl_description = "Add animation support for selected objects parameters"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return True

    def enable_animation(self, sel):
        """
          Add animation support on selected objects
        """
        for o in sel:
            d = self.archipack_datablock(o)
            if d is not None and hasattr(d, "update"):
                o.archipack_animation = True

    def execute(self, context):

        self.enable_animation(context.selected_objects)
 
        return {'FINISHED'}


# TODO: use shape keys instead
# for each key set a shape key
# update object
"""
context = C

o = context.active_object
dat = o.data
d = dat.archipack_window[0]
1 retrieve keys for this object
bpy.ops.object.shape_key_add()
k = dat.shape_keys.id_data
k.use_relative = False

frames = [0, 10]
for frame in frames:
    context.scene.frame_current = frame
    d.update(context)
    k.eval_time = frame
    bpy.ops.object.shape_key_add()
    s_key = k.key_blocks[-1]
    for i, p in enumerate(o.data.vertices):
          s_key.data[i].co = p.co.copy()

"""

class ARCHIPACK_OT_animation_remove(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.animation_remove"
    bl_label = "Remove"
    bl_description = "Remove animation support for selected objects parameters"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def disable_animation(self, sel):
        """
          Remove animation support on selected objects
        """
        for o in sel:
            if "archipack_animation" in o:
                o.archipack_animation = False

    def execute(self, context):
        sel = context.selected_objects
        self.disable_animation(sel)
        return {'FINISHED'}


class ARCHIPACK_OT_animation_render(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.animation_render"
    bl_label = "Render"
    bl_description = "Render with special animation support"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        state = archipack_animation_handler_add()
        scene = context.scene
        render = scene.render
        fpath = render.filepath
        ext = render.file_extension
        fmt = "{}{:04d}{}"
        # support up to 100k frames
        if (scene.frame_end - scene.frame_start) > 9999:
            fmt = "{}{:05d}{}"
        # scrub "by hand" and render still frame for each step
        for i in range(scene.frame_start, scene.frame_end + 1, scene.frame_step):
            scene.frame_current = i
            archipack_animation_updater(None)
            render.filepath = fmt.format(fpath, i, ext)
            try:
                bpy.ops.render.render(write_still=True)
            except Exception as e:
                # report unsupported format
                self.report({'ERROR'}, str(e))
                break
                pass
        render.filepath = fpath
        if not state:
            archipack_animation_handler_remove()
        return {'FINISHED'}


def register():
    global animated
    animated = {}
    Object.archipack_animation = BoolProperty(
        name="Support for Animation",
        description="Enable support for animation for this object",
        default=False,
        update=update_animation_state
    )
    Scene.archipack_animation = BoolProperty(
        name="Enable on screen",
        description="Display animation on screen - update objects on frame change",
        default=False,
        update=update_animation_handler_state
    )
    bpy.app.handlers.load_pre.append(archipack_animation_onunload)
    bpy.app.handlers.load_post.append(archipack_animation_onload)
    bpy.utils.register_class(ARCHIPACK_OT_animation_add)
    bpy.utils.register_class(ARCHIPACK_OT_animation_remove)
    bpy.utils.register_class(ARCHIPACK_OT_animation_render)


def unregister():
    global animated
    animated.clear()
    bpy.app.handlers.load_pre.remove(archipack_animation_onunload)
    bpy.app.handlers.load_post.remove(archipack_animation_onload)
    bpy.utils.unregister_class(ARCHIPACK_OT_animation_add)
    bpy.utils.unregister_class(ARCHIPACK_OT_animation_remove)
    bpy.utils.unregister_class(ARCHIPACK_OT_animation_render)
    del Scene.archipack_animation
    del Object.archipack_animation
